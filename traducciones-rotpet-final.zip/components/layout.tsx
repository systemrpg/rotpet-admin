"use client"

import { ReactNode } from "react"
import { useSidebar } from "@/contexts/SidebarContext"
import Sidebar from "./sidebar"
import Header from "./header"
import Footer from "./footer"

interface LayoutProps {
  children: ReactNode
}

export default function Layout({ children }: LayoutProps) {
  const { isOpen, setIsOpen } = useSidebar()

  return (
    <div className="layout-wrap">
      <Sidebar isOpen={isOpen} setIsOpen={setIsOpen} />
      <div className="section-content-right">
        <Header isSidebarOpen={isOpen} />
        <main className="main-content">
          {children}
          <Footer />
        </main>
      </div>
    </div>
  )
}
