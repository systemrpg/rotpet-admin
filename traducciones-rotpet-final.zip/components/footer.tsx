"use client"

import { useLanguage } from "@/contexts/LanguageContext"

export default function Footer() {
  const { t } = useLanguage()
  
  return (
    <footer className="border-t border-gray-200 bg-white mt-12">
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between text-sm text-gray-500">
          <p>© 2025 Rot Pet Shop. {t("footer.rights")}</p>
          <p>
            {t("footer.designed")}{' '}
            <a 
              href="https://calupoh.media" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-orange-600 hover:text-orange-700 transition-colors"
            >
              Calupoh Media
            </a>
          </p>
        </div>
      </div>
    </footer>
  )
}