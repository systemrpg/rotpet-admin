"use client"

import Link from "next/link"
import Image from "next/image"
import { useState } from "react"
import { usePathname } from "next/navigation"
import { useLanguage } from "@/contexts/LanguageContext"
import {
  LayoutDashboard,
  Users,
  ShoppingBag,
  Settings,
  LogOut,
  Menu,
  X,
  Shield,
  Tag,
  Ticket,
  Layers,
  FileText,
  UserPlus,
  ImageIcon,
  PieChart,
  MapPin,
  Edit,
  HelpCircle,
  Grid,
  ShoppingCart
} from "lucide-react"

interface SidebarProps {
  isOpen: boolean
  setIsOpen: (isOpen: boolean) => void
}

export default function Sidebar({ isOpen, setIsOpen }: SidebarProps) {
  const pathname = usePathname()
  const { t } = useLanguage()

  const menuItems = [
    {
      heading: t("menu.dashboard"),
      items: [
        {
          label: t("menu.dashboard"),
          icon: Grid,
          href: "/",
        },
      ],
    },
    {
      heading: "Tienda",
      items: [
        {
          label: t("menu.products"),
          icon: ShoppingCart,
          href: "/products",
        },
        {
          label: t("menu.categories"),
          icon: Layers,
          href: "/categories",
        },
        {
          label: t("menu.brands"),
          icon: Tag,
          href: "/brands",
        },
        {
          label: t("menu.coupons"),
          icon: Ticket,
          href: "/coupons",
        },
        {
          label: t("menu.orders"),
          icon: FileText,
          href: "/orders",
        },
      ],
    },
    {
      heading: t("menu.users"),
      items: [
        {
          label: t("menu.users"),
          icon: Users,
          href: "/users",
        },
        {
          label: t("menu.roles"),
          icon: UserPlus,
          href: "/roles",
        },
      ],
    },
    {
      heading: "Contenido",
      items: [
        { label: t("menu.pages"), icon: Edit, href: "/pages" },
        { label: t("menu.gallery"), icon: ImageIcon, href: "/gallery" },
        { label: t("menu.reports"), icon: PieChart, href: "/reports" },
      ],
    },
    {
      heading: t("menu.location"),
      items: [
        { label: t("menu.states"), icon: MapPin, href: "/states" },
        { label: t("menu.countries"), icon: MapPin, href: "/countries" },
      ],
    },
    {
      heading: t("menu.settings"),
      items: [
        { label: t("menu.settings"), icon: Settings, href: "/settings" },
        { label: t("menu.support"), icon: HelpCircle, href: "/support" },
      ],
    },
  ]

  const isActive = (href: string) => {
    if (href === "/") {
      return pathname === "/"
    }
    return pathname.startsWith(href)
  }

  return (
    <div
      className={`${isOpen ? "w-72" : "w-20"} bg-white border-r border-gray-200 transition-all duration-300 flex flex-col`}
    >
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        {isOpen && (
          <Link href="/" className="flex items-center gap-2">
            <Image src="/logo-text.png" alt="Rot Pet Shop" width={240} height={70} className="h-16 w-auto" />
          </Link>
        )}
        <button onClick={() => setIsOpen(!isOpen)} className="text-gray-600 hover:text-gray-900">
          {isOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto">
        {menuItems.map((section) => (
          <div key={section.heading} className="mb-4">
            {isOpen && (
              <div className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                {section.heading}
              </div>
            )}
            <div className="space-y-1">
              {section.items.map((item) => (
                <Link
                  key={item.label}
                  href={item.href}
                  className={`w-full flex items-center gap-3 px-4 py-2 text-sm transition-colors ${
                    isActive(item.href)
                      ? "text-orange-600 bg-orange-50 font-medium"
                      : "text-gray-700 hover:text-orange-600 hover:bg-orange-50"
                  }`}
                >
                  <item.icon size={20} className="flex-shrink-0" />
                  {isOpen && <span className="flex-1">{item.label}</span>}
                </Link>
              ))}
            </div>
          </div>
        ))}
      </nav>
    </div>
  )
}
