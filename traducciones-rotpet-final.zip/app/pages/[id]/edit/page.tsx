"use client"

import Layout from "@/components/layout"
import PageForm from "../../page-form"
import { useParams } from "next/navigation"

export default function EditPagePage() {
  const params = useParams()
  const id = params.id as string

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Editar Página</h1>
        <p className="text-gray-600 mt-1">Modifica el contenido de la página</p>
      </div>

      <PageForm id={id} />
    </Layout>
  )
}
