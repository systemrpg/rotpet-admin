"use client"

import Layout from "@/components/layout"
import PageForm from "../page-form"
import { useLanguage } from "@/contexts/LanguageContext"

export default function NewPagePage() {
  const { t } = useLanguage()
  
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("pages.newPage")}</h1>
        <p className="text-gray-600 mt-1">{t("pages.newPageSubtitle")}</p>
      </div>

      <PageForm />
    </Layout>
  )
}
