"use client"

import Layout from "@/components/layout"
import { Plus, Edit, Trash2, Eye } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import { useLanguage } from "@/contexts/LanguageContext"

interface Page {
  id: number
  title: string
  slug: string
  status: "published" | "draft"
  updatedAt: string
}

export default function PagesManagement() {
  const { t } = useLanguage()
  const [pages, setPages] = useState<Page[]>([
    {
      id: 1,
      title: "Sobre Nosotros",
      slug: "sobre-nosotros",
      status: "published",
      updatedAt: "2025-12-10",
    },
    {
      id: 2,
      title: "Términos y Condiciones",
      slug: "terminos-condiciones",
      status: "published",
      updatedAt: "2025-12-08",
    },
    {
      id: 3,
      title: "Política de Privacidad",
      slug: "politica-privacidad",
      status: "published",
      updatedAt: "2025-12-05",
    },
    {
      id: 4,
      title: "Preguntas Frecuentes",
      slug: "faq",
      status: "draft",
      updatedAt: "2025-12-01",
    },
  ])

  const handleDelete = (id: number) => {
    if (confirm("¿Estás seguro de que deseas eliminar esta página?")) {
      setPages(pages.filter((page) => page.id !== id))
    }
  }

  return (
    <Layout>
      {/* Page Header */}
      <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{t("pages.title")}</h1>
              <p className="text-gray-600 mt-1">{t("pages.subtitle")}</p>
            </div>
            <Link href="/pages/new" className="tf-button flex items-center gap-2">
              <Plus size={20} />
              {t("pages.newPage")}
            </Link>
          </div>

          {/* Pages List */}
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t("common.title")}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t("common.slug")}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t("common.status")}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t("common.updated")}
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      {t("common.actions")}
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {pages.map((page) => (
                    <tr key={page.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">{page.title}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-500">/{page.slug}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                            page.status === "published"
                              ? "bg-green-100 text-green-800"
                              : "bg-yellow-100 text-yellow-800"
                          }`}
                        >
                          {page.status === "published" ? t("pages.published") : t("pages.draft")}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{page.updatedAt}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <div className="flex items-center justify-end gap-2">
                          <Link
                            href={`/p/${page.slug}`}
                            className="text-blue-600 hover:text-blue-900"
                            title="Vista previa"
                            target="_blank"
                          >
                            <Eye size={18} />
                          </Link>
                          <Link
                            href={`/pages/${page.id}/edit`}
                            className="text-orange-600 hover:text-orange-900"
                            title={t("common.edit")}
                          >
                            <Edit size={18} />
                          </Link>
                          <button
                            onClick={() => handleDelete(page.id)}
                            className="text-red-600 hover:text-red-900"
                            title={t("common.delete")}
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {pages.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-500">No hay páginas creadas aún.</p>
              <Link href="/pages/new" className="mt-4 tf-button inline-block">
                Crear primera página
          </Link>
        </div>
      )}
    </Layout>
  )
}
