export const PERMISSIONS = [
    {
        module: "Tablero",
        actions: [
            { code: "dashboard.view", label: "Ver Tablero Principal" },
            { code: "dashboard.stats", label: "Ver Estadísticas Financieras" },
        ],
    },
    {
        module: "Productos",
        actions: [
            { code: "products.read", label: "Ver Productos" },
            { code: "products.create", label: "Crear Productos" },
            { code: "products.update", label: "Editar Productos" },
            { code: "products.delete", label: "Eliminar Productos" },
        ],
    },
    {
        module: "Categorías",
        actions: [
            { code: "categories.read", label: "Ver Categorías" },
            { code: "categories.create", label: "Crear Categorías" },
            { code: "categories.update", label: "Editar Categorías" },
            { code: "categories.delete", label: "Eliminar Categorías" },
        ],
    },
    {
        module: "Pedidos",
        actions: [
            { code: "orders.read", label: "Ver Pedidos" },
            { code: "orders.create", label: "Crear Pedidos" },
            { code: "orders.update", label: "Gestionar Pedidos (Estado)" },
            { code: "orders.delete", label: "Eliminar Pedidos" },
        ],
    },
    {
        module: "Usuarios",
        actions: [
            { code: "users.read", label: "Ver Usuarios" },
            { code: "users.create", label: "Crear Usuarios" },
            { code: "users.update", label: "Editar Usuarios" },
            { code: "users.delete", label: "Eliminar Usuarios" },
        ],
    },
    {
        module: "Roles",
        actions: [
            { code: "roles.read", label: "Ver Roles" },
            { code: "roles.create", label: "Crear Roles" },
            { code: "roles.update", label: "Editar Roles" },
            { code: "roles.delete", label: "Eliminar Roles" },
        ],
    },
]
