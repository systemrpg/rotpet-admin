"use client"

import Layout from "@/components/layout"
import ProductForm from "../../product-form"
import { useLanguage } from "@/contexts/LanguageContext"
import { use } from "react"

export default function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { t } = useLanguage()
  const { id } = use(params)
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("products.editProductTitle")}</h1>
        <p className="text-gray-600 mt-1">{t("products.editProductSubtitle")}</p>
      </div>

      <ProductForm id={id} />
    </Layout>
  )
}
