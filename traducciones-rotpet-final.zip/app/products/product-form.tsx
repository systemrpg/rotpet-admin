"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Save, X, Upload, Loader2 } from "lucide-react"
import { toast } from "sonner"
import { resizeImage } from "@/lib/image-utils"
import { ConfirmModal } from "@/components/confirm-modal"
import { useLanguage } from "@/contexts/LanguageContext"

interface ProductFormProps {
    id?: string // If present, we are editing
}

export default function ProductForm({ id }: ProductFormProps) {
    const { t } = useLanguage()
    const router = useRouter()
    const [loading, setLoading] = useState(false)
    const [categories, setCategories] = useState<any[]>([])
    const [formData, setFormData] = useState({
        name: "",
        sku: "",
        price: "",
        quantity: "",
        status: "active",
        category_id: "",
        image_url: "",
        description: "",
    })

    // Variants State
    const [hasVariants, setHasVariants] = useState(false)
    const [options, setOptions] = useState<{ name: string; values: string[] }[]>([])
    const [variants, setVariants] = useState<any[]>([])
    const [newOptionName, setNewOptionName] = useState("")
    const [newOptionValue, setNewOptionValue] = useState("")

    useEffect(() => {
        fetchCategories()
        if (id) {
            fetchProduct(id)
        }
    }, [id])

    const fetchCategories = async () => {
        try {
            const response = await fetch("http://localhost:3001/api/categories")
            if (response.ok) {
                const data = await response.json()
                setCategories(data)
            }
        } catch (error) {
            console.error("Error fetching categories:", error)
        }
    }

    const fetchProduct = async (productId: string) => {
        try {
            const response = await fetch(`http://localhost:3001/api/products/${productId}`)
            if (response.ok) {
                const data = await response.json()
                setFormData({
                    name: data.name,
                    sku: data.sku,
                    price: data.price,
                    quantity: data.quantity,
                    status: data.status,
                    category_id: data.category_id,
                    image_url: data.image_url || "",
                    description: data.description || "",
                })

                if (data.variants && data.variants.length > 0) {
                    setHasVariants(true)
                    setVariants(data.variants)
                    // Infer options from variants if possible, or just load variants directly
                    // For simplicity, we might not reconstruct the "options" state perfectly from existing variants
                    // without more complex logic, but we can load the variants for editing.
                }
            }
        } catch (error) {
            console.error("Error fetching product:", error)
        }
    }

    const addOption = () => {
        if (!newOptionName) return
        setOptions([...options, { name: newOptionName, values: [] }])
        setNewOptionName("")
    }

    const addValueToOption = (optionIndex: number, value: string) => {
        if (!value) return
        const newOptions = [...options]
        if (!newOptions[optionIndex].values.includes(value)) {
            newOptions[optionIndex].values.push(value)
            setOptions(newOptions)
        }
    }

    const removeOption = (index: number) => {
        const newOptions = [...options]
        newOptions.splice(index, 1)
        setOptions(newOptions)
    }

    const removeValueFromOption = (optionIndex: number, valueIndex: number) => {
        const newOptions = [...options]
        newOptions[optionIndex].values.splice(valueIndex, 1)
        setOptions(newOptions)
    }

    const generateVariants = () => {
        if (options.length === 0) return

        // Cartesian product of options
        const combine = (acc: any[], index: number): any[] => {
            if (index === options.length) return acc

            const option = options[index]
            const newAcc: any[] = []

            if (acc.length === 0) {
                option.values.forEach(val => {
                    newAcc.push({ [option.name]: val })
                })
            } else {
                acc.forEach(existing => {
                    option.values.forEach(val => {
                        newAcc.push({ ...existing, [option.name]: val })
                    })
                })
            }

            return combine(newAcc, index + 1)
        }

        const combinations = combine([], 0)

        const newVariants = combinations.map(combo => {
            // Generate a SKU suffix based on values
            const suffix = Object.values(combo).join("-").toUpperCase()
            return {
                sku: `${formData.sku}-${suffix}`,
                price: formData.price,
                stock: 0,
                attributes: combo,
                status: 'active'
            }
        })

        setVariants(newVariants)
    }

    const updateVariant = (index: number, field: string, value: any) => {
        const newVariants = [...variants]
        newVariants[index] = { ...newVariants[index], [field]: value }
        setVariants(newVariants)
    }

    const [uploading, setUploading] = useState(false)
    const [showSizeError, setShowSizeError] = useState(false)

    const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0]
        if (!file) return

        // Check original file size (e.g. 10MB limit for browser safety)
        if (file.size > 10 * 1024 * 1024) {
            setShowSizeError(true)
            e.target.value = "" // Reset input
            return
        }

        setUploading(true)

        try {
            // Resize image to 800x800 square
            const resizedBlob = await resizeImage(file, 800)

            // Double check resized size (should be small, but just in case)
            if (resizedBlob.size > 5 * 1024 * 1024) {
                setShowSizeError(true)
                setUploading(false)
                return
            }

            const formDataUpload = new FormData()
            formDataUpload.append("file", resizedBlob, file.name)

            const response = await fetch("http://localhost:3001/api/gallery?folder=products", {
                method: "POST",
                body: formDataUpload,
            })

            if (!response.ok) {
                const text = await response.text()
                console.error("Upload failed details:", {
                    status: response.status,
                    statusText: response.statusText,
                    body: text
                })

                try {
                    const errorData = JSON.parse(text)
                    if (errorData.error === "File too large") {
                        setShowSizeError(true)
                        throw new Error("File too large")
                    }
                    throw new Error(errorData.error || `Upload failed: ${response.status} ${response.statusText}`)
                } catch (e) {
                    if ((e as Error).message === "File too large") throw e
                    throw new Error(`Upload failed: ${response.status} ${response.statusText}`)
                }
            }

            const data = await response.json()
            setFormData(prev => ({ ...prev, image_url: data.url }))
            toast.success(t("products.imageUploaded"))
        } catch (error) {
            console.error("Error uploading image:", error)
            if ((error as Error).message !== "File too large") {
                toast.error(error instanceof Error ? error.message : t("products.imageUploadError"))
            }
        } finally {
            setUploading(false)
            e.target.value = "" // Reset input
        }
    }

    const removeVariant = (index: number) => {
        const newVariants = [...variants]
        newVariants.splice(index, 1)
        setVariants(newVariants)
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setLoading(true)

        const payload = {
            ...formData,
            variants: hasVariants ? variants : []
        }

        try {
            const url = id
                ? `http://localhost:3001/api/products/${id}`
                : "http://localhost:3001/api/products"

            const method = id ? "PUT" : "POST"

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            })

            if (response.ok) {
                toast.success(t("messages.success.saved"))
                router.push("/products")
                router.refresh()
            } else {
                toast.error(t("products.productSaveError"))
            }
        } catch (error) {
            console.error("Error saving product:", error)
            toast.error(t("products.productSaveError"))
        } finally {
            setLoading(false)
        }
    }

    return (
        <form onSubmit={handleSubmit} className="space-y-6">
            <div className="bg-white rounded-lg border border-gray-200 p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">{t("products.basicInfo")}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-700">{t("products.productName")}</label>
                        <input
                            type="text"
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            value={formData.name}
                            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        />
                    </div>

                    <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-700">{t("products.baseSku")}</label>
                        <input
                            type="text"
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            value={formData.sku}
                            onChange={(e) => setFormData({ ...formData, sku: e.target.value })}
                        />
                    </div>

                    <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-700">
                            {hasVariants ? t("products.basePrice") : t("products.priceLabel")}
                        </label>
                        <input
                            type="number"
                            step="0.01"
                            required
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 disabled:bg-gray-100 disabled:text-gray-500"
                            value={formData.price}
                            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                        />
                        {hasVariants && <p className="text-xs text-gray-500">{t("products.editPriceNote")}</p>}
                    </div>

                    <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-700">{t("products.totalStock")}</label>
                        <input
                            type="number"
                            required
                            disabled={hasVariants}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 disabled:bg-gray-100"
                            value={hasVariants ? variants.reduce((acc, v) => acc + (parseInt(v.stock) || 0), 0) : formData.quantity}
                            onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                        />
                        {hasVariants && <p className="text-xs text-gray-500">{t("products.autoCalculatedNote")}</p>}
                    </div>

                    <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-700">{t("products.category")}</label>
                        <select
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            value={formData.category_id}
                            onChange={(e) => setFormData({ ...formData, category_id: e.target.value })}
                        >
                            <option value="">{t("products.selectCategory")}</option>
                            {categories.map((cat) => (
                                <option key={cat.id} value={cat.id}>
                                    {cat.name}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div className="space-y-2">
                        <label className="text-sm font-medium text-gray-700">{t("common.status")}</label>
                        <select
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            value={formData.status}
                            onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                        >
                            <option value="active">{t("common.active")}</option>
                            <option value="inactive">{t("common.inactive")}</option>
                        </select>
                    </div>

                    <div className="space-y-2 md:col-span-2">
                        <label className="text-sm font-medium text-gray-700">{t("products.productImage")}</label>

                        {formData.image_url ? (
                            <div className="relative aspect-video w-full max-w-md bg-gray-100 rounded-lg overflow-hidden border border-gray-200 group">
                                <img
                                    src={formData.image_url}
                                    alt="Preview"
                                    className="w-full h-full object-contain"
                                />
                                <button
                                    type="button"
                                    onClick={() => setFormData({ ...formData, image_url: "" })}
                                    className="absolute top-2 right-2 p-1.5 bg-white text-red-600 rounded-full shadow-sm hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-opacity"
                                    title={t("products.removeImage")}
                                >
                                    <X size={16} />
                                </button>
                            </div>
                        ) : (
                            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:bg-gray-50 transition-colors">
                                <input
                                    type="file"
                                    accept="image/*"
                                    className="hidden"
                                    id="product-image-upload"
                                    onChange={handleImageUpload}
                                    disabled={uploading}
                                />
                                <label
                                    htmlFor="product-image-upload"
                                    className="cursor-pointer flex flex-col items-center gap-2"
                                >
                                    <div className="p-3 bg-orange-100 rounded-full text-orange-600">
                                        {uploading ? <Loader2 className="animate-spin" size={24} /> : <Upload size={24} />}
                                    </div>
                                    <div>
                                        <p className="font-medium text-gray-900">
                                            {uploading ? t("products.uploading") : t("products.clickToUpload")}
                                        </p>
                                        <p className="text-xs text-gray-500 mt-1">{t("products.imageFormat")}</p>
                                    </div>
                                </label>
                            </div>
                        )}
                    </div>

                    <div className="space-y-2 md:col-span-2">
                        <label className="text-sm font-medium text-gray-700">{t("products.description")}</label>
                        <textarea
                            rows={3}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            value={formData.description}
                            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        />
                    </div>
                </div>
            </div>

            {/* Variants Section */}
            <div className="bg-white rounded-lg border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-gray-900">{t("products.variants")}</h2>
                    <div className="flex items-center gap-2">
                        <input
                            type="checkbox"
                            id="hasVariants"
                            checked={hasVariants}
                            onChange={(e) => setHasVariants(e.target.checked)}
                            className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300 rounded"
                        />
                        <label htmlFor="hasVariants" className="text-sm text-gray-700">{t("products.hasVariants")}</label>
                    </div>
                </div>

                {hasVariants && (
                    <div className="space-y-6">
                        {/* Option Definition */}
                        <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                            <h3 className="text-sm font-medium text-gray-900 mb-3">{t("products.defineOptions")}</h3>
                            <div className="flex gap-2 mb-4">
                                <input
                                    type="text"
                                    placeholder={t("products.optionName")}
                                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md"
                                    value={newOptionName}
                                    onChange={(e) => setNewOptionName(e.target.value)}
                                />
                                <button
                                    type="button"
                                    onClick={addOption}
                                    className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50"
                                >
                                    {t("products.addOption")}
                                </button>
                            </div>

                            <div className="space-y-4">
                                {options.map((option, idx) => (
                                    <div key={idx} className="bg-white p-3 rounded border border-gray-200">
                                        <div className="flex justify-between items-center mb-2">
                                            <span className="font-medium text-gray-700">{option.name}</span>
                                            <button type="button" onClick={() => removeOption(idx)} className="text-red-500 hover:text-red-700 text-sm">{t("products.remove")}</button>
                                        </div>
                                        <div className="flex flex-wrap gap-2 items-center">
                                            {option.values.map((val, vIdx) => (
                                                <span key={vIdx} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                                    {val}
                                                    <button type="button" onClick={() => removeValueFromOption(idx, vIdx)} className="ml-1 text-orange-600 hover:text-orange-900">×</button>
                                                </span>
                                            ))}
                                            <input
                                                type="text"
                                                placeholder={t("products.newValue")}
                                                className="text-sm border-none focus:ring-0 p-0 w-32"
                                                onKeyDown={(e) => {
                                                    if (e.key === 'Enter') {
                                                        e.preventDefault()
                                                        addValueToOption(idx, e.currentTarget.value)
                                                        e.currentTarget.value = ''
                                                    }
                                                }}
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>

                            {options.length > 0 && (
                                <button
                                    type="button"
                                    onClick={generateVariants}
                                    className="mt-4 w-full py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700"
                                >
                                    {t("products.generateVariants")}
                                </button>
                            )}
                        </div>

                        {/* Variants Table */}
                        {variants.length > 0 && (
                            <div>
                                <h3 className="text-sm font-medium text-gray-900 mb-3">{t("products.editVariants")}</h3>
                                <div className="overflow-x-auto">
                                    <table className="w-full text-sm text-left">
                                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                            <tr>
                                                <th className="px-4 py-3">{t("products.variant")}</th>
                                                <th className="px-4 py-3">{t("products.sku")}</th>
                                                <th className="px-4 py-3">{t("products.price")}</th>
                                                <th className="px-4 py-3">{t("products.stock")}</th>
                                                <th className="px-4 py-3">{t("common.actions")}</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {variants.map((variant, idx) => (
                                                <tr key={idx} className="border-b">
                                                    <td className="px-4 py-3 font-medium text-gray-900">
                                                        {Object.entries(variant.attributes).map(([k, v]) => `${k}: ${v}`).join(", ")}
                                                    </td>
                                                    <td className="px-4 py-3">
                                                        <input
                                                            type="text"
                                                            className="w-full px-2 py-1 border border-gray-300 rounded"
                                                            value={variant.sku}
                                                            onChange={(e) => updateVariant(idx, 'sku', e.target.value)}
                                                        />
                                                    </td>
                                                    <td className="px-4 py-3">
                                                        <input
                                                            type="number"
                                                            step="0.01"
                                                            className="w-24 px-2 py-1 border border-gray-300 rounded"
                                                            value={variant.price}
                                                            onChange={(e) => updateVariant(idx, 'price', e.target.value)}
                                                        />
                                                    </td>
                                                    <td className="px-4 py-3">
                                                        <input
                                                            type="number"
                                                            className="w-20 px-2 py-1 border border-gray-300 rounded"
                                                            value={variant.stock}
                                                            onChange={(e) => updateVariant(idx, 'stock', e.target.value)}
                                                        />
                                                    </td>
                                                    <td className="px-4 py-3">
                                                        <button type="button" onClick={() => removeVariant(idx)} className="text-red-600 hover:text-red-900">
                                                            <X size={16} />
                                                        </button>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>

            <div className="flex justify-end gap-4">
                <button
                    type="button"
                    onClick={() => router.back()}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                >
                    <X size={20} />
                    {t("common.cancel")}
                </button>
                <button
                    type="submit"
                    disabled={loading}
                    className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 flex items-center gap-2 disabled:opacity-50"
                >
                    <Save size={20} />
                    {loading ? t("products.saving") : t("products.saveProduct")}
                </button>
            </div>
            <ConfirmModal
                isOpen={showSizeError}
                onClose={() => setShowSizeError(false)}
                onConfirm={() => setShowSizeError(false)}
                title={t("products.imageTooLarge")}
                description={t("products.imageTooLargeDesc")}
                confirmText={t("products.understood")}
                showCancel={false}
                variant="danger"
            />
        </form>
    )
}
