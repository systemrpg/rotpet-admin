"use client"

import Layout from "@/components/layout"
import ProductForm from "../product-form"
import { useLanguage } from "@/contexts/LanguageContext"

export default function NewProductPage() {
  const { t } = useLanguage()
  
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("products.addProduct")}</h1>
        <p className="text-gray-600 mt-1">{t("products.addProductSubtitle")}</p>
      </div>

      <ProductForm />
    </Layout>
  )
}
