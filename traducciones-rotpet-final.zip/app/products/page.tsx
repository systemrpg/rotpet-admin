"use client"
import Layout from "@/components/layout"
import { Plus } from "lucide-react"
import Link from "next/link"
import ProductList from "./product-list"
import { useLanguage } from "@/contexts/LanguageContext"

export default function ProductsPage() {
  const { t } = useLanguage()
  
  return (
    <Layout>
      {/* Page Header */}
      <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{t("products.title")}</h1>
              <p className="text-gray-600 mt-1">{t("products.subtitle")}</p>
            </div>
            <Link href="/products/new" className="tf-button flex items-center gap-2">
              <Plus size={20} />
              {t("products.addProduct")}
            </Link>
          </div>

      {/* Products List Component */}
      <ProductList />
    </Layout>
  )
}
