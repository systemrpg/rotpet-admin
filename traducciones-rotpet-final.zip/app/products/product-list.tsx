"use client"

import { useState, useEffect } from "react"
import { Edit, Trash2, Plus, Eye } from "lucide-react"
import Link from "next/link"
import { toast } from "sonner"
import { ConfirmModal } from "@/components/confirm-modal"
import { useLanguage } from "@/contexts/LanguageContext"

interface Product {
    id: string
    name: string
    sku: string
    price: number
    quantity: number
    status: string
    category_id: string
    image_url: string
    variants: { count: number }[]
}

export default function ProductList() {
    const { t } = useLanguage()
    const [products, setProducts] = useState<Product[]>([])
    const [loading, setLoading] = useState(true)
    const [deleteId, setDeleteId] = useState<string | null>(null)

    useEffect(() => {
        fetchProducts()
    }, [])

    const fetchProducts = async () => {
        try {
            const response = await fetch("http://localhost:3001/api/products")
            if (!response.ok) throw new Error("Failed to fetch products")
            const data = await response.json()
            setProducts(data)
        } catch (error) {
            console.error("Error fetching products:", error)
            toast.error(t("messages.error.loading"))
        } finally {
            setLoading(false)
        }
    }

    const handleDelete = async () => {
        if (!deleteId) return

        try {
            const response = await fetch(`http://localhost:3001/api/products/${deleteId}`, {
                method: "DELETE",
            })

            if (response.ok) {
                setProducts(products.filter((p) => p.id !== deleteId))
                toast.success(t("messages.success.deleted"))
            } else {
                toast.error(t("messages.error.deleting"))
            }
        } catch (error) {
            console.error("Error deleting product:", error)
            toast.error(t("messages.error.deleting"))
        } finally {
            setDeleteId(null)
        }
    }

    if (loading) {
        return <div className="p-8 text-center">{t("products.loadingProducts")}</div>
    }

    return (
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="overflow-x-auto">
                <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("products.name")}</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("products.sku")}</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("products.price")}</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("products.stock")}</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("common.status")}</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("common.actions")}</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {products.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                                    {t("products.noProducts")}
                                </td>
                            </tr>
                        ) : (
                            products.map((product) => {
                                const variantCount = product.variants?.[0]?.count || 0
                                return (
                                    <tr key={product.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 text-sm text-gray-900 font-medium">{product.name}</td>
                                        <td className="px-6 py-4 text-sm text-gray-600">{product.sku}</td>
                                        <td className="px-6 py-4 text-sm text-gray-900 font-medium">${product.price}</td>
                                        <td className="px-6 py-4 text-sm text-gray-600">
                                            {variantCount > 0 ? (
                                                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                                    {variantCount} {t("products.variantsCount")}
                                                </span>
                                            ) : (
                                                product.quantity
                                            )}
                                        </td>
                                        <td className="px-6 py-4 text-sm">
                                            <span
                                                className={`inline-block px-3 py-1 rounded text-xs font-medium ${product.status === "active" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                                                    }`}
                                            >
                                                {product.status === "active" ? t("products.available") : t("products.notAvailable")}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-sm">
                                            <div className="flex items-center gap-2">
                                                <Link
                                                    href={`/products/${product.id}`}
                                                    className="p-2 hover:bg-blue-50 rounded transition-colors"
                                                    title="Ver Detalles"
                                                >
                                                    <Eye size={16} className="text-blue-600" />
                                                </Link>
                                                <Link
                                                    href={`/products/${product.id}/edit`}
                                                    className="p-2 hover:bg-gray-100 rounded transition-colors"
                                                    title="Editar"
                                                >
                                                    <Edit size={16} className="text-gray-600" />
                                                </Link>
                                                <button
                                                    onClick={() => setDeleteId(product.id)}
                                                    className="p-2 hover:bg-red-50 rounded transition-colors"
                                                    title="Eliminar"
                                                >
                                                    <Trash2 size={16} className="text-red-600" />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                )
                            })
                        )}
                    </tbody>
                </table>
            </div>

            <ConfirmModal
                isOpen={!!deleteId}
                onClose={() => setDeleteId(null)}
                onConfirm={handleDelete}
                title="Eliminar Producto"
                description="¿Estás seguro de que deseas eliminar este producto? Esta acción no se puede deshacer."
                confirmText="Eliminar"
                variant="danger"
            />
        </div>
    )
}
