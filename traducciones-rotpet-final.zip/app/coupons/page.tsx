"use client"
import Layout from "@/components/layout"
import { Plus } from "lucide-react"
import Link from "next/link"
import CouponList from "./coupon-list"
import { useLanguage } from "@/contexts/LanguageContext"

export default function CouponsPage() {
    const { t } = useLanguage()
    
    return (
        <Layout>
            <div className="flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">{t("coupons.title")}</h1>
                    <p className="text-gray-600 mt-1">{t("coupons.subtitle")}</p>
                </div>
                <Link href="/coupons/new" className="tf-button flex items-center gap-2">
                    <Plus size={20} />
                    {t("coupons.newCoupon")}
                </Link>
            </div>

            <CouponList />
        </Layout>
    )
}
