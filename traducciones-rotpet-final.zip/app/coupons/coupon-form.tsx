"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useForm } from "react-hook-form"
import { toast } from "sonner"
import { ArrowLeft, Save, Loader2 } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/contexts/LanguageContext"

interface CouponFormProps {
    couponId?: string
}

interface CouponFormData {
    code: string
    discount_type: 'percentage' | 'fixed'
    discount_value: number
    min_purchase: number
    expiration_date: string
    usage_limit: number
    status: 'active' | 'inactive'
}

export default function CouponForm({ couponId }: CouponFormProps) {
    const { t } = useLanguage()
    const router = useRouter()
    const [loading, setLoading] = useState(false)
    const [initialLoading, setInitialLoading] = useState(!!couponId)
    const { register, handleSubmit, setValue, formState: { errors } } = useForm<CouponFormData>({
        defaultValues: {
            discount_type: 'percentage',
            status: 'active'
        }
    })

    useEffect(() => {
        if (couponId) {
            const fetchCoupon = async () => {
                try {
                    const response = await fetch(`http://localhost:3001/api/coupons/${couponId}`)
                    if (!response.ok) throw new Error("Failed to fetch coupon")
                    const data = await response.json()

                    setValue("code", data.code)
                    setValue("discount_type", data.discount_type)
                    setValue("discount_value", data.discount_value)
                    setValue("min_purchase", data.min_purchase)
                    setValue("usage_limit", data.usage_limit)
                    setValue("status", data.status)

                    if (data.expiration_date) {
                        // Format date for input type="datetime-local"
                        const date = new Date(data.expiration_date)
                        const formattedDate = date.toISOString().slice(0, 16)
                        setValue("expiration_date", formattedDate)
                    }
                } catch (error) {
                    console.error("Error fetching coupon:", error)
                    toast.error("Error al cargar el cupón")
                } finally {
                    setInitialLoading(false)
                }
            }
            fetchCoupon()
        }
    }, [couponId, setValue])

    const onSubmit = async (data: CouponFormData) => {
        setLoading(true)
        try {
            const url = couponId
                ? `http://localhost:3001/api/coupons/${couponId}`
                : "http://localhost:3001/api/coupons"

            const method = couponId ? "PUT" : "POST"

            // Convert empty strings to null for optional fields
            const payload = {
                ...data,
                min_purchase: data.min_purchase || null,
                usage_limit: data.usage_limit || null,
                expiration_date: data.expiration_date || null
            }

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            })

            if (response.ok) {
                toast.success(couponId ? t("coupons.update") + " " + t("common.successfully") : t("coupons.newCoupon") + " " + t("common.successfully"))
                router.push("/coupons")
                router.refresh()
            } else {
                const errorData = await response.json()
                toast.error(t("coupons.errorSaving"), {
                    description: errorData.error || t("common.unknownError")
                })
            }
        } catch (error) {
            console.error("Error saving coupon:", error)
            toast.error(t("coupons.errorSaving"))
        } finally {
            setLoading(false)
        }
    }

    if (initialLoading) {
        return (
            <div className="flex justify-center items-center h-64">
                <Loader2 className="animate-spin text-orange-600" size={32} />
            </div>
        )
    }

    return (
        <div className="max-w-2xl mx-auto">
            <div className="mb-6">
                <Link
                    href="/coupons"
                    className="inline-flex items-center text-gray-600 hover:text-gray-900 transition-colors mb-4"
                >
                    <ArrowLeft size={20} className="mr-2" />
                    Volver a Cupones
                </Link>
                <h1 className="text-2xl font-bold text-gray-900">
                    {couponId ? "Editar Cupón" : "Nuevo Cupón"}
                </h1>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Código del Cupón
                        </label>
                        <input
                            {...register("code", { required: "El código es obligatorio" })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 uppercase"
                            placeholder="Ej: VERANO20"
                        />
                        {errors.code && (
                            <p className="mt-1 text-sm text-red-600">{errors.code.message}</p>
                        )}
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Tipo de Descuento
                        </label>
                        <select
                            {...register("discount_type")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        >
                            <option value="percentage">Porcentaje (%)</option>
                            <option value="fixed">Monto Fijo ($)</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Valor del Descuento
                        </label>
                        <input
                            type="number"
                            step="0.01"
                            {...register("discount_value", { required: "El valor es obligatorio", min: 0 })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            placeholder="0.00"
                        />
                        {errors.discount_value && (
                            <p className="mt-1 text-sm text-red-600">{errors.discount_value.message}</p>
                        )}
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Compra Mínima (Opcional)
                        </label>
                        <input
                            type="number"
                            step="0.01"
                            {...register("min_purchase")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            placeholder="0.00"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Límite de Usos (Opcional)
                        </label>
                        <input
                            type="number"
                            {...register("usage_limit")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            placeholder="Sin límite"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Fecha de Expiración (Opcional)
                        </label>
                        <input
                            type="datetime-local"
                            {...register("expiration_date")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Estado
                        </label>
                        <select
                            {...register("status")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        >
                            <option value="active">Activo</option>
                            <option value="inactive">Inactivo</option>
                        </select>
                    </div>
                </div>

                <div className="flex justify-end pt-4">
                    <button
                        type="submit"
                        disabled={loading}
                        className="inline-flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50"
                    >
                        {loading ? (
                            <Loader2 className="animate-spin mr-2" size={20} />
                        ) : (
                            <Save className="mr-2" size={20} />
                        )}
                        {couponId ? "Actualizar" : "Guardar"}
                    </button>
                </div>
            </form>
        </div>
    )
}
