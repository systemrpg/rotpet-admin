"use client"

import Layout from "@/components/layout"
import CouponForm from "../coupon-form"
import { useLanguage } from "@/contexts/LanguageContext"

export default function NewCouponPage() {
    const { t } = useLanguage()
    
    return (
        <Layout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">{t("coupons.newCoupon")}</h1>
                <p className="text-gray-600 mt-1">{t("coupons.newCouponSubtitle")}</p>
            </div>
            <CouponForm />
        </Layout>
    )
}
