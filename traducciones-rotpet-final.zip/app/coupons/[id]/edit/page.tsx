"use client"

import { use } from "react"
import Layout from "@/components/layout"
import CouponForm from "../../coupon-form"
import { useLanguage } from "@/contexts/LanguageContext"

export default function EditCouponPage({ params }: { params: Promise<{ id: string }> }) {
    const { t } = useLanguage()
    const { id } = use(params)
    return (
        <Layout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">{t("coupons.editCoupon")}</h1>
                <p className="text-gray-600 mt-1">{t("coupons.editCouponSubtitle")}</p>
            </div>
            <CouponForm couponId={id} />
        </Layout>
    )
}
