"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Edit, Trash2, Search, Tag } from "lucide-react"
import { toast } from "sonner"
import { ConfirmModal } from "@/components/confirm-modal"
import { useLanguage } from "@/contexts/LanguageContext"

interface Brand {
    id: string
    name: string
    slug: string
    logo_url: string | null
    description: string | null
    created_at: string
}

export default function BrandList() {
    const { t } = useLanguage()
    const [brands, setBrands] = useState<Brand[]>([])
    const [loading, setLoading] = useState(true)
    const [searchTerm, setSearchTerm] = useState("")
    const [deleteId, setDeleteId] = useState<string | null>(null)

    const fetchBrands = async () => {
        try {
            const response = await fetch("http://localhost:3001/api/brands")
            if (!response.ok) throw new Error("Failed to fetch brands")
            const data = await response.json()
            setBrands(data)
        } catch (error) {
            console.error("Error fetching brands:", error)
            toast.error(t("messages.error.loading"))
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchBrands()
    }, [])

    const handleDelete = async () => {
        if (!deleteId) return

        try {
            const response = await fetch(`http://localhost:3001/api/brands/${deleteId}`, {
                method: "DELETE",
            })

            if (response.ok) {
                toast.success("Marca eliminada correctamente")
                fetchBrands()
            } else {
                const data = await response.json()
                toast.error("Error al eliminar la marca", {
                    description: data.error || "Ocurrió un error inesperado"
                })
            }
        } catch (error) {
            console.error("Error deleting brand:", error)
            toast.error("Error al eliminar la marca")
        } finally {
            setDeleteId(null)
        }
    }

    const filteredBrands = brands.filter((brand) =>
        brand.name.toLowerCase().includes(searchTerm.toLowerCase())
    )

    if (loading) {
        return <div className="p-8 text-center text-gray-500">{t("brands.loadingBrands")}</div>
    }

    return (
        <div className="space-y-6">
            <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <input
                    type="text"
                    placeholder="Buscar marcas..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Logo</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Nombre</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Slug</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Acciones</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {filteredBrands.length === 0 ? (
                                <tr>
                                    <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                                        No se encontraron marcas
                                    </td>
                                </tr>
                            ) : (
                                filteredBrands.map((brand) => (
                                    <tr key={brand.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            {brand.logo_url ? (
                                                <img src={brand.logo_url} alt={brand.name} className="h-10 w-10 object-contain rounded-md border border-gray-200" />
                                            ) : (
                                                <div className="h-10 w-10 bg-gray-100 rounded-md flex items-center justify-center text-gray-400">
                                                    <Tag size={16} />
                                                </div>
                                            )}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                            {brand.name}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                            {brand.slug}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                                            <div className="flex items-center gap-2">
                                                <Link
                                                    href={`/brands/${brand.id}/edit`}
                                                    className="p-2 hover:bg-blue-50 rounded transition-colors"
                                                    title={t("common.edit")}
                                                >
                                                    <Edit size={16} className="text-blue-600" />
                                                </Link>
                                                <button
                                                    onClick={() => setDeleteId(brand.id)}
                                                    className="p-2 hover:bg-red-50 rounded transition-colors"
                                                    title={t("common.delete")}
                                                >
                                                    <Trash2 size={16} className="text-red-600" />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <ConfirmModal
                isOpen={!!deleteId}
                onClose={() => setDeleteId(null)}
                onConfirm={handleDelete}
                title="Eliminar Marca"
                description="¿Estás seguro de que deseas eliminar esta marca? Esta acción no se puede deshacer."
                confirmText="Eliminar"
                variant="danger"
            />
        </div>
    )
}
