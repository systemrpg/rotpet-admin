"use client"

import Layout from "@/components/layout"
import BrandForm from "../brand-form"
import { useLanguage } from "@/contexts/LanguageContext"

export default function NewBrandPage() {
    const { t } = useLanguage()
    
    return (
        <Layout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">{t("brands.newBrand")}</h1>
                <p className="text-gray-600 mt-1">{t("brands.newBrandSubtitle")}</p>
            </div>
            <BrandForm />
        </Layout>
    )
}
