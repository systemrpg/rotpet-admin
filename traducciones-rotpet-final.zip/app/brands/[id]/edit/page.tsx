import { use } from "react"
import Layout from "@/components/layout"
import BrandForm from "../../brand-form"

export default function EditBrandPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = use(params)
    return (
        <Layout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Editar Marca</h1>
                <p className="text-gray-600 mt-1">Modifica los detalles de la marca</p>
            </div>
            <BrandForm brandId={id} />
        </Layout>
    )
}
