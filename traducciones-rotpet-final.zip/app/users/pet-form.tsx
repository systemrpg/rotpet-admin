"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { toast } from "sonner"
import { X, Loader2 } from "lucide-react"

interface Pet {
    id: string
    name: string
    type: 'dog' | 'cat' | 'other'
    breed: string | null
    birth_date: string | null
    gender: 'male' | 'female' | null
    weight: number | null
    allergies: string | null
}

interface PetFormData {
    name: string
    type: 'dog' | 'cat' | 'other'
    breed: string
    birth_date: string
    gender: 'male' | 'female'
    weight: number
    allergies: string
}

interface PetFormProps {
    userId: string
    pet?: Pet
    onClose: () => void
    onSuccess: () => void
}

export default function PetForm({ userId, pet, onClose, onSuccess }: PetFormProps) {
    const [loading, setLoading] = useState(false)
    const { register, handleSubmit, formState: { errors } } = useForm<PetFormData>({
        defaultValues: {
            name: pet?.name || "",
            type: pet?.type || "dog",
            breed: pet?.breed || "",
            birth_date: pet?.birth_date ? new Date(pet.birth_date).toISOString().split('T')[0] : "",
            gender: pet?.gender || "male",
            weight: pet?.weight || undefined,
            allergies: pet?.allergies || ""
        }
    })

    const onSubmit = async (data: PetFormData) => {
        setLoading(true)
        try {
            const url = pet
                ? `http://localhost:3001/api/pets/${pet.id}`
                : "http://localhost:3001/api/pets"

            const method = pet ? "PUT" : "POST"

            const payload = {
                ...data,
                user_id: userId,
                weight: data.weight || null,
                birth_date: data.birth_date || null,
                breed: data.breed || null,
                allergies: data.allergies || null
            }

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            })

            if (response.ok) {
                toast.success(pet ? "Mascota actualizada" : "Mascota añadida")
                onSuccess()
            } else {
                const errorData = await response.json()
                toast.error("Error al guardar", {
                    description: errorData.error || "Error desconocido"
                })
            }
        } catch (error) {
            console.error("Error saving pet:", error)
            toast.error("Error al guardar la mascota")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="p-6">
            <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-gray-900">
                    {pet ? "Editar Mascota" : "Nueva Mascota"}
                </h2>
                <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
                    <X size={24} />
                </button>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nombre</label>
                    <input
                        {...register("name", { required: "El nombre es obligatorio" })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                    {errors.name && <p className="text-xs text-red-600 mt-1">{errors.name.message}</p>}
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tipo</label>
                        <select
                            {...register("type")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        >
                            <option value="dog">Perro</option>
                            <option value="cat">Gato</option>
                            <option value="other">Otro</option>
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Género</label>
                        <select
                            {...register("gender")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        >
                            <option value="male">Macho</option>
                            <option value="female">Hembra</option>
                        </select>
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Raza</label>
                    <input
                        {...register("breed")}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                    />
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Fecha Nacimiento</label>
                        <input
                            type="date"
                            {...register("birth_date")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Peso (kg)</label>
                        <input
                            type="number"
                            step="0.1"
                            {...register("weight")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        />
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Alergias / Notas Médicas</label>
                    <textarea
                        {...register("allergies")}
                        rows={3}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        placeholder="Pollo, Granos, etc."
                    />
                </div>

                <div className="flex justify-end pt-4">
                    <button
                        type="button"
                        onClick={onClose}
                        className="mr-3 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                        Cancelar
                    </button>
                    <button
                        type="submit"
                        disabled={loading}
                        className="inline-flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50"
                    >
                        {loading && <Loader2 className="animate-spin mr-2" size={18} />}
                        Guardar
                    </button>
                </div>
            </form>
        </div>
    )
}
