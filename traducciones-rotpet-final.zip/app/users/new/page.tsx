"use client"

import Layout from "@/components/layout"
import UserForm from "../user-form"
import { useLanguage } from "@/contexts/LanguageContext"

export default function NewUserPage() {
  const { t } = useLanguage()
  
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("users.addUser")}</h1>
        <p className="text-gray-600 mt-1">{t("users.addUserSubtitle")}</p>
      </div>

      <UserForm />
    </Layout>
  )
}
