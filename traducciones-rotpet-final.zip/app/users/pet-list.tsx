"use client"

import { useState, useEffect } from "react"
import { Edit, Trash2, Plus, Dog, Cat, HelpCircle } from "lucide-react"
import { toast } from "sonner"
import { ConfirmModal } from "@/components/confirm-modal"
import PetForm from "./pet-form"

interface Pet {
    id: string
    name: string
    type: 'dog' | 'cat' | 'other'
    breed: string | null
    birth_date: string | null
    gender: 'male' | 'female' | null
    weight: number | null
    allergies: string | null
}

interface PetListProps {
    userId: string
}

export default function PetList({ userId }: PetListProps) {
    const [pets, setPets] = useState<Pet[]>([])
    const [loading, setLoading] = useState(true)
    const [deleteId, setDeleteId] = useState<string | null>(null)
    const [isFormOpen, setIsFormOpen] = useState(false)
    const [editingPet, setEditingPet] = useState<Pet | undefined>(undefined)

    const fetchPets = async () => {
        try {
            const response = await fetch(`http://localhost:3001/api/users/${userId}/pets`)
            if (!response.ok) throw new Error("Failed to fetch pets")
            const data = await response.json()
            setPets(data)
        } catch (error) {
            console.error("Error fetching pets:", error)
            toast.error("Error al cargar las mascotas")
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchPets()
    }, [userId])

    const handleDelete = async () => {
        if (!deleteId) return

        try {
            const response = await fetch(`http://localhost:3001/api/pets/${deleteId}`, {
                method: "DELETE",
            })

            if (response.ok) {
                toast.success("Mascota eliminada correctamente")
                fetchPets()
            } else {
                const data = await response.json()
                toast.error("Error al eliminar la mascota", {
                    description: data.error || "Ocurrió un error inesperado"
                })
            }
        } catch (error) {
            console.error("Error deleting pet:", error)
            toast.error("Error al eliminar la mascota")
        } finally {
            setDeleteId(null)
        }
    }

    const handleEdit = (pet: Pet) => {
        setEditingPet(pet)
        setIsFormOpen(true)
    }



    const handleFormClose = () => {
        setIsFormOpen(false)
        setEditingPet(undefined)
    }

    const handleFormSuccess = () => {
        handleFormClose()
        fetchPets()
    }

    const getIcon = (type: string) => {
        switch (type) {
            case 'dog': return <Dog size={24} className="text-orange-600" />
            case 'cat': return <Cat size={24} className="text-blue-600" />
            default: return <HelpCircle size={24} className="text-gray-600" />
        }
    }

    const getAge = (birthDate: string | null) => {
        if (!birthDate) return "Edad desconocida"
        const today = new Date()
        const birth = new Date(birthDate)
        let age = today.getFullYear() - birth.getFullYear()
        const m = today.getMonth() - birth.getMonth()
        if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) {
            age--
        }
        return `${age} años`
    }

    if (loading) {
        return <div className="p-8 text-center text-gray-500">{t("users.loadingPets")}</div>
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-gray-900">Mascotas</h2>
            </div>

            {pets.length === 0 ? (
                <div className="bg-gray-50 rounded-lg border border-gray-200 p-8 text-center text-gray-500">
                    Este cliente no tiene mascotas registradas.
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {pets.map((pet) => (
                        <div key={pet.id} className="bg-white rounded-lg border border-gray-200 p-4 shadow-sm hover:shadow-md transition-shadow">
                            <div className="flex items-start justify-between mb-4">
                                <div className="p-3 bg-gray-50 rounded-full">
                                    {getIcon(pet.type)}
                                </div>
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => handleEdit(pet)}
                                        className="p-1.5 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                                    >
                                        <Edit size={16} />
                                    </button>
                                    <button
                                        onClick={() => setDeleteId(pet.id)}
                                        className="p-1.5 text-red-600 hover:bg-red-50 rounded transition-colors"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            </div>

                            <h3 className="text-lg font-bold text-gray-900 mb-1">{pet.name}</h3>
                            <p className="text-sm text-gray-500 mb-3">{pet.breed || 'Raza desconocida'}</p>

                            <div className="space-y-1 text-sm text-gray-600">
                                <p>Edad: <span className="font-medium">{getAge(pet.birth_date)}</span></p>
                                <p>Género: <span className="font-medium capitalize">{pet.gender === 'male' ? 'Macho' : pet.gender === 'female' ? 'Hembra' : 'N/A'}</span></p>
                                <p>Peso: <span className="font-medium">{pet.weight ? `${pet.weight} kg` : 'N/A'}</span></p>
                            </div>

                            {pet.allergies && (
                                <div className="mt-3 pt-3 border-t border-gray-100">
                                    <p className="text-xs text-red-600 font-medium">⚠️ Alergias:</p>
                                    <p className="text-xs text-gray-600">{pet.allergies}</p>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}

            {isFormOpen && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto">
                        <PetForm
                            userId={userId}
                            pet={editingPet}
                            onClose={handleFormClose}
                            onSuccess={handleFormSuccess}
                        />
                    </div>
                </div>
            )}

            <ConfirmModal
                isOpen={!!deleteId}
                onClose={() => setDeleteId(null)}
                onConfirm={handleDelete}
                title="Eliminar Mascota"
                description={`¿Estás seguro de que deseas eliminar esta mascota?`}
                confirmText="Eliminar"
                variant="danger"
            />
        </div>
    )
}
