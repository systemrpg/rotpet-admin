"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useLanguage } from "@/contexts/LanguageContext"

interface UserFormProps {
    userId?: string
}

interface Role {
    id: string
    name: string
}

export default function UserForm({ userId }: UserFormProps) {
    const { t } = useLanguage()
    const router = useRouter()
    const [loading, setLoading] = useState(false)
    const [roles, setRoles] = useState<Role[]>([])

    const [formData, setFormData] = useState({
        full_name: "",
        email: "",
        role_id: "",
        status: "active",
    })

    useEffect(() => {
        // Fetch roles for dropdown
        const fetchRoles = async () => {
            try {
                const response = await fetch("http://localhost:3001/api/roles")
                if (response.ok) {
                    const data = await response.json()
                    setRoles(data)
                }
            } catch (error) {
                console.error("Error fetching roles:", error)
            }
        }

        fetchRoles()

        // If editing, fetch user data
        if (userId) {
            const fetchUser = async () => {
                try {
                    const response = await fetch(`http://localhost:3001/api/users/${userId}`)
                    if (response.ok) {
                        const data = await response.json()
                        setFormData({
                            full_name: data.full_name || "",
                            email: data.email || "",
                            role_id: data.role_id || "",
                            status: data.status || "active",
                        })
                    }
                } catch (error) {
                    console.error("Error fetching user:", error)
                }
            }
            fetchUser()
        }
    }, [userId])

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setLoading(true)

        try {
            const url = userId
                ? `http://localhost:3001/api/users/${userId}`
                : "http://localhost:3001/api/users"

            const method = userId ? "PUT" : "POST"

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(formData),
            })

            if (response.ok) {
                router.push("/users")
                router.refresh()
            } else {
                const errorData = await response.json()
                alert(`Error al guardar el usuario: ${errorData.error || "Error desconocido"}`)
            }
        } catch (error) {
            console.error("Error saving user:", error)
            alert("Error al guardar el usuario: Error de red o servidor")
        } finally {
            setLoading(false)
        }
    }

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target
        setFormData((prev) => ({ ...prev, [name]: value }))
    }

    return (
        <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t("users.fullName")}
                    </label>
                    <input
                        type="text"
                        name="full_name"
                        value={formData.full_name}
                        onChange={handleChange}
                        placeholder="Ej: Juan García"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all"
                        required
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t("users.email")}
                    </label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        placeholder="Ej: juan@example.com"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all"
                        required
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t("users.role")}
                    </label>
                    <select
                        name="role_id"
                        value={formData.role_id}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all"
                        required
                    >
                        <option value="">{t("users.selectRole")}</option>
                        {roles.map((role) => (
                            <option key={role.id} value={role.id}>
                                {role.name}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t("common.status")}
                    </label>
                    <select
                        name="status"
                        value={formData.status}
                        onChange={handleChange}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all"
                    >
                        <option value="active">{t("common.active")}</option>
                        <option value="inactive">{t("common.inactive")}</option>
                    </select>
                </div>
            </div>

            <div className="flex items-center gap-4 pt-4 border-t border-gray-100">
                <button
                    type="submit"
                    disabled={loading}
                    className="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium disabled:opacity-50"
                >
                    {loading ? t("users.saving") : t("users.saveUser")}
                </button>
                <Link
                    href="/users"
                    className="px-6 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                >
                    {t("common.cancel")}
                </Link>
            </div>
        </form>
    )
}
