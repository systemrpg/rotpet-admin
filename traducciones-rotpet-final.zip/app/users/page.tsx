"use client"
import Layout from "@/components/layout"
import { Plus } from "lucide-react"
import Link from "next/link"
import UserList from "./user-list"
import { useLanguage } from "@/contexts/LanguageContext"

export default function UsersPage() {
  const { t } = useLanguage()
  
  return (
    <Layout>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{t("users.title")}</h1>
          <p className="text-gray-600 mt-1">{t("users.subtitle")}</p>
        </div>
        <Link href="/users/new" className="tf-button flex items-center gap-2">
          <Plus size={20} />
          {t("users.addUser")}
        </Link>
      </div>

      <UserList />
    </Layout>
  )
}
