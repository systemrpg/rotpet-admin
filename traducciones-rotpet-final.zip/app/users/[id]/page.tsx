"use client"

import { useState, useEffect, use } from "react"
import { useRouter } from "next/navigation"
import Sidebar from "@/components/sidebar"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { ArrowLeft, User, Mail, Calendar, Save, Loader2 } from "lucide-react"
import Link from "next/link"
import { toast } from "sonner"
import PetList from "../pet-list"
import BalanceCard from "../balance-card"

interface UserDetail {
    id: string
    email: string
    full_name: string
    role_id: string
    status: string
    created_at: string
    balance: number
    internal_notes: string | null
}

export default function UserDetailPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = use(params)
    const [user, setUser] = useState<UserDetail | null>(null)
    const [loading, setLoading] = useState(true)
    const [notes, setNotes] = useState("")
    const [savingNotes, setSavingNotes] = useState(false)
    const [activeTab, setActiveTab] = useState<'profile' | 'pets' | 'orders'>('profile')

    const fetchUser = async () => {
        try {
            const response = await fetch(`http://localhost:3001/api/users/${id}`)
            if (!response.ok) throw new Error("Failed to fetch user")
            const data = await response.json()
            setUser(data)
            setNotes(data.internal_notes || "")
        } catch (error) {
            console.error("Error fetching user:", error)
            toast.error("Error al cargar usuario")
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchUser()
    }, [id])

    const handleSaveNotes = async () => {
        setSavingNotes(true)
        try {
            const response = await fetch(`http://localhost:3001/api/users/${id}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ internal_notes: notes }),
            })

            if (response.ok) {
                toast.success("Notas actualizadas")
            } else {
                toast.error("Error al guardar notas")
            }
        } catch (error) {
            console.error("Error saving notes:", error)
            toast.error("Error de conexión")
        } finally {
            setSavingNotes(false)
        }
    }

    if (loading) {
        return (
            <div className="layout-wrap">
                <Sidebar />
                <div className="section-content-right">
                    <Header />
                    <main className="main-content flex justify-center items-center h-64">
                        <Loader2 className="animate-spin text-orange-600" size={32} />
                    </main>
                </div>
            </div>
        )
    }

    if (!user) return null

    return (
        <div className="layout-wrap">
            <Sidebar />
            <div className="section-content-right">
                <Header />
                <main className="main-content">
                    <div className="mb-6">
                        <Link
                            href="/users"
                            className="inline-flex items-center text-gray-600 hover:text-gray-900 transition-colors mb-4"
                        >
                            <ArrowLeft size={20} className="mr-2" />
                            Volver a Usuarios
                        </Link>
                        <div className="flex items-center justify-between">
                            <h1 className="text-3xl font-bold text-gray-900">{user.full_name || "Usuario Sin Nombre"}</h1>
                            <span className={`px-3 py-1 rounded-full text-sm font-medium ${user.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                                }`}>
                                {user.status === 'active' ? 'Activo' : 'Inactivo'}
                            </span>
                        </div>
                        <p className="text-gray-500 flex items-center gap-2 mt-1">
                            <Mail size={16} /> {user.email}
                        </p>
                    </div>

                    {/* Tabs */}
                    <div className="border-b border-gray-200 mb-6">
                        <nav className="-mb-px flex space-x-8">
                            <button
                                onClick={() => setActiveTab('profile')}
                                className={`py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'profile'
                                    ? 'border-orange-500 text-orange-600'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                    }`}
                            >
                                Perfil y Saldo
                            </button>
                            <button
                                onClick={() => setActiveTab('pets')}
                                className={`py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'pets'
                                    ? 'border-orange-500 text-orange-600'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                    }`}
                            >
                                Mascotas
                            </button>
                            <button
                                onClick={() => setActiveTab('orders')}
                                className={`py-4 px-1 border-b-2 font-medium text-sm ${activeTab === 'orders'
                                    ? 'border-orange-500 text-orange-600'
                                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                                    }`}
                            >
                                Historial de Órdenes
                            </button>
                        </nav>
                    </div>

                    {/* Content */}
                    <div className="space-y-6">
                        {activeTab === 'profile' && (
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="md:col-span-2 space-y-6">
                                    <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
                                        <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                                            <User size={20} />
                                            Información Personal
                                        </h3>
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <label className="block text-sm font-medium text-gray-500">ID Usuario</label>
                                                <p className="text-gray-900 font-mono text-sm">{user.id}</p>
                                            </div>
                                            <div>
                                                <label className="block text-sm font-medium text-gray-500">Fecha Registro</label>
                                                <p className="text-gray-900 flex items-center gap-1">
                                                    <Calendar size={14} />
                                                    {new Date(user.created_at).toLocaleDateString()}
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
                                        <div className="flex justify-between items-center mb-4">
                                            <h3 className="text-lg font-semibold text-gray-900">Notas Internas</h3>
                                            <button
                                                onClick={handleSaveNotes}
                                                disabled={savingNotes}
                                                className="text-sm text-orange-600 hover:text-orange-700 flex items-center gap-1"
                                            >
                                                {savingNotes ? <Loader2 className="animate-spin" size={14} /> : <Save size={14} />}
                                                Guardar
                                            </button>
                                        </div>
                                        <textarea
                                            rows={4}
                                            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                                            placeholder="Escribe notas visibles solo para el staff..."
                                            value={notes}
                                            onChange={(e) => setNotes(e.target.value)}
                                        />
                                        <p className="text-xs text-gray-500 mt-2">Estas notas no son visibles para el cliente.</p>
                                    </div>
                                </div>

                                <div>
                                    <BalanceCard
                                        userId={user.id}
                                        currentBalance={user.balance || 0}
                                        onUpdate={fetchUser}
                                    />
                                </div>
                            </div>
                        )}

                        {activeTab === 'pets' && (
                            <PetList userId={user.id} />
                        )}

                        {activeTab === 'orders' && (
                            <div className="bg-gray-50 rounded-lg border border-gray-200 p-8 text-center text-gray-500">
                                Funcionalidad de historial de órdenes en desarrollo...
                            </div>
                        )}
                    </div>

                    <Footer />
                </main>
            </div>
        </div>
    )
}
