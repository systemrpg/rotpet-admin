import Layout from "@/components/layout"
import UserForm from "../../user-form"

export default async function EditUserPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = await params
    return (
        <Layout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Editar Usuario</h1>
                <p className="text-gray-600 mt-1">Modifica los datos del usuario</p>
            </div>

            <UserForm userId={id} />
        </Layout>
    )
}
