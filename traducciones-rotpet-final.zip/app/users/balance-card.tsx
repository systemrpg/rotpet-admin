"use client"

import { useState } from "react"
import { DollarSign, Save, Loader2 } from "lucide-react"
import { toast } from "sonner"

interface BalanceCardProps {
    userId: string
    currentBalance: number
    onUpdate: () => void
}

export default function BalanceCard({ userId, currentBalance, onUpdate }: BalanceCardProps) {
    const [isEditing, setIsEditing] = useState(false)
    const [balance, setBalance] = useState<string | number>(currentBalance)
    const [loading, setLoading] = useState(false)

    const handleSave = async () => {
        setLoading(true)
        try {
            const numericBalance = typeof balance === 'string' ? parseFloat(balance) : balance
            if (isNaN(numericBalance)) {
                toast.error("Por favor ingresa un monto válido")
                setLoading(false)
                return
            }

            const response = await fetch(`http://localhost:3001/api/users/${userId}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ balance: numericBalance }),
            })

            if (response.ok) {
                toast.success("Saldo actualizado")
                setIsEditing(false)
                onUpdate()
            } else {
                toast.error("Error al actualizar saldo")
            }
        } catch (error) {
            console.error("Error updating balance:", error)
            toast.error("Error de conexión")
        } finally {
            setLoading(false)
        }
    }

    return (
        <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                    <DollarSign className="text-green-600" size={20} />
                    Saldo a Favor
                </h3>
                {!isEditing && (
                    <button
                        onClick={() => {
                            setBalance(currentBalance)
                            setIsEditing(true)
                        }}
                        className="text-sm text-blue-600 hover:underline"
                    >
                        Ajustar
                    </button>
                )}
            </div>

            {isEditing ? (
                <div className="flex gap-2">
                    <div className="relative flex-1">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
                        <input
                            type="number"
                            step="0.01"
                            value={balance}
                            onChange={(e) => setBalance(e.target.value)}
                            className="w-full pl-7 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                        />
                    </div>
                    <button
                        onClick={handleSave}
                        disabled={loading}
                        className="p-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50"
                    >
                        {loading ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
                    </button>
                    <button
                        onClick={() => {
                            setIsEditing(false)
                            setBalance(currentBalance)
                        }}
                        className="p-2 text-gray-500 hover:bg-gray-100 rounded-md"
                    >
                        Cancelar
                    </button>
                </div>
            ) : (
                <div className="text-3xl font-bold text-gray-900">
                    ${currentBalance.toFixed(2)}
                </div>
            )}
            <p className="text-sm text-gray-500 mt-2">
                Este saldo puede ser usado por el cliente en futuras compras.
            </p>
        </div>
    )
}
