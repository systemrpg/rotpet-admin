"use client"

import Layout from "@/components/layout"
import { MessageSquare, Mail, Phone, Clock, CheckCircle } from "lucide-react"
import { useState } from "react"
import { useLanguage } from "@/contexts/LanguageContext"

export default function SupportPage() {
  const { t } = useLanguage()
  const [selectedCategory, setSelectedCategory] = useState("general")
  const [message, setMessage] = useState("")
  const [email, setEmail] = useState("")

  const faqItems = [
    {
      id: 1,
      category: "general",
      question: "¿Cómo agregar un nuevo producto?",
      answer:
        "Para agregar un nuevo producto, ve a la sección de Productos y haz clic en 'Agregar Producto'. Completa todos los campos requeridos incluyendo nombre, categoría, precio e imágenes.",
    },
    {
      id: 2,
      category: "general",
      question: "¿Cómo editar un producto existente?",
      answer:
        "En la lista de productos, haz clic en el icono de editar junto al producto que deseas modificar. Podrás actualizar todos sus detalles.",
    },
    {
      id: 3,
      category: "general",
      question: "¿Cómo eliminar un producto?",
      answer:
        "En la lista de productos, haz clic en el icono de papelera roja para eliminar un producto. Esta acción no se puede deshacer.",
    },
    {
      id: 4,
      category: "inventory",
      question: "¿Cómo gestionar el inventario?",
      answer:
        "Puedes actualizar la cantidad en stock desde la página de editar producto. El sistema te alertará cuando el stock sea bajo.",
    },
    {
      id: 5,
      category: "inventory",
      question: "¿Cómo aplicar descuentos?",
      answer:
        "Al editar un producto, encontrarás una sección de descuentos. Puedes aplicar descuentos por porcentaje o valor fijo.",
    },
    {
      id: 6,
      category: "orders",
      question: "¿Cómo ver los detalles de una orden?",
      answer:
        "Ve a Órdenes y haz clic en cualquier orden para ver sus detalles completos incluyendo artículos, cliente y estado.",
    },
  ]

  const supportChannels = [
    {
      icon: Mail,
      title: t("support.email"),
      description: t("support.emailDesc"),
      contact: t("support.contactEmail"),
    },
    {
      icon: Phone,
      title: t("support.phone"),
      description: t("support.phoneDesc"),
      contact: t("support.contactPhone"),
    },
    {
      icon: MessageSquare,
      title: t("support.liveChat"),
      description: t("support.liveChatDesc"),
      contact: t("support.availability"),
    },
    {
      icon: Clock,
      title: t("support.hours"),
      description: t("support.hoursDesc"),
      contact: t("support.schedule"),
    },
  ]

  const filteredFAQ =
    selectedCategory === "all" ? faqItems : faqItems.filter((item) => item.category === selectedCategory)

  return (
    <Layout>
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("support.title")}</h1>
        <p className="text-gray-600 mt-1">{t("support.subtitle")}</p>
      </div>

      {/* Support Channels */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {supportChannels.map((channel) => (
          <div key={channel.title} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
            <channel.icon className="w-8 h-8 text-orange-600 mb-3" />
            <h3 className="font-semibold text-gray-900 mb-2">{channel.title}</h3>
            <p className="text-sm text-gray-600 mb-2">{channel.description}</p>
            <p className="text-sm font-medium text-orange-600">{channel.contact}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* FAQ Section */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">{t("support.faq")}</h2>

            {/* Category Filter */}
            <div className="flex gap-2 mb-6 flex-wrap">
              <button
                onClick={() => setSelectedCategory("all")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  selectedCategory === "all"
                    ? "bg-orange-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {t("support.category.all")}
              </button>
              <button
                onClick={() => setSelectedCategory("general")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  selectedCategory === "general"
                    ? "bg-orange-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {t("support.category.general")}
              </button>
              <button
                onClick={() => setSelectedCategory("inventory")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  selectedCategory === "inventory"
                    ? "bg-orange-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {t("support.category.inventory")}
              </button>
              <button
                onClick={() => setSelectedCategory("orders")}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  selectedCategory === "orders"
                    ? "bg-orange-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {t("support.category.orders")}
              </button>
            </div>

            {/* FAQ List */}
            <div className="space-y-4">
              {filteredFAQ.map((item) => (
                <details key={item.id} className="group border border-gray-200 rounded-lg p-4">
                  <summary className="flex items-center justify-between cursor-pointer">
                    <span className="font-medium text-gray-900 flex items-center gap-2">
                      <CheckCircle size={16} className="text-green-600" />
                      {item.question}
                    </span>
                  </summary>
                  <p className="mt-4 text-gray-600 text-sm">{item.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">{t("support.contact")}</h2>
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">{t("support.email")}</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                  placeholder="tu@email.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">{t("support.message")}</label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  rows={5}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                  placeholder="Describe tu problema o pregunta..."
                />
              </div>
              <button type="submit" className="w-full tf-button">
                {t("support.send")}
              </button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  )
}
