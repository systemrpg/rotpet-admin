"use client"
import Layout from "@/components/layout"
import { useLanguage } from "@/contexts/LanguageContext"

export default function StatesPage() {
  const { t } = useLanguage()
  
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("location.states")}</h1>
        <p className="text-gray-600 mt-1">{t("location.statesSubtitle")}</p>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-8">
        <p className="text-sm text-gray-600">{t("common.statesPlaceholder")}</p>
      </div>
    </Layout>
  )
}
