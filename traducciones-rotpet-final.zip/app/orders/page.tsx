"use client"
import Layout from "@/components/layout"
import { Eye, Download } from "lucide-react"
import Link from "next/link"
import { useLanguage } from "@/contexts/LanguageContext"

const orders = [
  {
    id: 1,
    product: "Alimento Crunchy Premium",
    customer: "Juan García",
    price: "$450",
    date: "20 Nov 2024",
    status: "completed",
  },
  {
    id: 2,
    product: "Golosinas para Perros",
    customer: "María López",
    price: "$85",
    date: "19 Nov 2024",
    status: "pending",
  },
  {
    id: 3,
    product: "Cama para Mascotas",
    customer: "Carlos Rodríguez",
    price: "$250",
    date: "18 Nov 2024",
    status: "completed",
  },
]

export default function OrdersPage() {
  const { t } = useLanguage()

  const getStatusTranslation = (status: string) => {
    const statusMap: Record<string, string> = {
      completed: t("orders.completed"),
      pending: t("orders.pending"),
      processing: t("orders.processing"),
      shipped: t("orders.shipped"),
      delivered: t("orders.delivered"),
      cancelled: t("orders.cancelled"),
    }
    return statusMap[status] || status
  }

  return (
    <Layout>
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("orders.title")}</h1>
        <p className="text-gray-600 mt-1">{t("orders.subtitle")}</p>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("orders.orderId")}</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("orders.product")}</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("orders.customer")}</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("orders.price")}</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("orders.date")}</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("common.status")}</th>
                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">{t("common.actions")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {orders.map((order) => (
                <tr key={order.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-orange-600">#{1000 + order.id}</td>
                  <td className="px-6 py-4 text-sm text-gray-900">{order.product}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{order.customer}</td>
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">{order.price}</td>
                  <td className="px-6 py-4 text-sm text-gray-600">{order.date}</td>
                  <td className="px-6 py-4 text-sm">
                    <span
                      className={`inline-block px-3 py-1 rounded text-xs font-medium ${
                        order.status === "completed"
                          ? "bg-green-100 text-green-700"
                          : "bg-yellow-100 text-yellow-700"
                      }`}
                    >
                      {getStatusTranslation(order.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Link
                        href={`/orders/${order.id}`}
                        className="p-2 hover:bg-gray-100 rounded transition-colors"
                        title={t("common.view")}
                      >
                        <Eye size={16} className="text-gray-600" />
                      </Link>
                      <button className="p-2 hover:bg-gray-100 rounded transition-colors" title={t("common.download")}>
                        <Download size={16} className="text-gray-600" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Layout>
  )
}
