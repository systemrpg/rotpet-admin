"use client"

import Layout from "@/components/layout"
import { TrendingUp, Package, DollarSign, ShoppingCart, Calendar } from "lucide-react"
import { useState } from "react"
import { useLanguage } from "@/contexts/LanguageContext"

export default function ReportsPage() {
  const { t } = useLanguage()
  const [dateRange, setDateRange] = useState("month")

  const stats = [
    {
      icon: DollarSign,
      title: t("reports.revenue"),
      value: "$24,500",
      change: "+12.5%",
      changeType: "positive",
    },
    {
      icon: ShoppingCart,
      title: t("reports.orders"),
      value: "352",
      change: "+8.2%",
      changeType: "positive",
    },
    {
      icon: Package,
      title: t("reports.productsSold"),
      value: "1,248",
      change: "+15.3%",
      changeType: "positive",
    },
    {
      icon: TrendingUp,
      title: t("reports.avgValue"),
      value: "$69.60",
      change: "-2.4%",
      changeType: "negative",
    },
  ]

  const topProducts = [
    { id: 1, name: "Collar Premium para Perro", sales: 145, revenue: "$4,350" },
    { id: 2, name: "Cama Ortopédica para Mascotas", sales: 98, revenue: "$4,900" },
    { id: 3, name: "Juguete Interactivo", sales: 87, revenue: "$2,610" },
    { id: 4, name: "Alimento Premium 15kg", sales: 76, revenue: "$3,800" },
    { id: 5, name: "Transportadora Grande", sales: 54, revenue: "$2,700" },
  ]

  return (
    <Layout>
      {/* Page Header */}
      <div className="mb-8 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">{t("reports.title")}</h1>
          <p className="text-gray-600 mt-1">{t("reports.subtitle")}</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setDateRange("week")}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              dateRange === "week"
                ? "bg-orange-600 text-white"
                : "bg-white border border-gray-300 text-gray-700 hover:bg-gray-50"
            }`}
          >
            {t("common.thisWeek")}
          </button>
          <button
            onClick={() => setDateRange("month")}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              dateRange === "month"
                ? "bg-orange-600 text-white"
                : "bg-white border border-gray-300 text-gray-700 hover:bg-gray-50"
            }`}
          >
            {t("common.thisMonth")}
          </button>
          <button
            onClick={() => setDateRange("year")}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              dateRange === "year"
                ? "bg-orange-600 text-white"
                : "bg-white border border-gray-300 text-gray-700 hover:bg-gray-50"
            }`}
          >
            {t("common.thisYear")}
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat) => (
          <div key={stat.title} className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-2 bg-orange-100 rounded-lg">
                <stat.icon className="w-6 h-6 text-orange-600" />
              </div>
              <span
                className={`text-sm font-medium ${
                  stat.changeType === "positive" ? "text-green-600" : "text-red-600"
                }`}
              >
                {stat.change}
              </span>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</h3>
            <p className="text-sm text-gray-600">{stat.title}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Top Products */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">{t("reports.topProducts")}</h2>
          <div className="space-y-4">
            {topProducts.map((product, index) => (
              <div key={product.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-0">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-orange-600">{index + 1}</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{product.name}</p>
                    <p className="text-sm text-gray-600">{product.sales} {t("common.sales")}</p>
                  </div>
                </div>
                <span className="font-semibold text-gray-900">{product.revenue}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Revenue Chart Placeholder */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">{t("reports.byCategory")}</h2>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Alimentos</span>
                <span className="text-sm font-semibold text-gray-900">$8,500</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-orange-600 h-2 rounded-full" style={{ width: "65%" }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Accesorios</span>
                <span className="text-sm font-semibold text-gray-900">$6,200</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-orange-600 h-2 rounded-full" style={{ width: "48%" }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Juguetes</span>
                <span className="text-sm font-semibold text-gray-900">$4,800</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-orange-600 h-2 rounded-full" style={{ width: "37%" }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2">
                <span className="text-sm font-medium text-gray-700">Cuidado</span>
                <span className="text-sm font-semibold text-gray-900">$5,000</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-orange-600 h-2 rounded-full" style={{ width: "38%" }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  )
}
