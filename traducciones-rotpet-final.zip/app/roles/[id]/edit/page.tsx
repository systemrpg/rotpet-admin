import Layout from "@/components/layout"
import RoleForm from "../../role-form"

export default async function EditRolePage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = await params
    return (
        <Layout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Editar Rol</h1>
                <p className="text-gray-600 mt-1">Modifica los permisos del rol</p>
            </div>

            <RoleForm roleId={id} />
        </Layout>
    )
}
