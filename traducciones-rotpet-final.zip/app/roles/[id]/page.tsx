"use client"

import Sidebar from "@/components/sidebar"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { useEffect, useState } from "react"
import { PERMISSIONS } from "@/app/config/permissions"
import Link from "next/link"
import { ArrowLeft, CheckCircle, XCircle } from "lucide-react"

interface Role {
    id: string
    name: string
    permissions: string[]
}

import { useParams } from "next/navigation"

export default function ViewRolePage() {
    const params = useParams()
    const id = params.id as string
    const [role, setRole] = useState<Role | null>(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        if (!id) return

        const fetchRole = async () => {
            try {
                const response = await fetch(`http://localhost:3001/api/roles/${id}`)
                if (response.ok) {
                    const data = await response.json()
                    setRole(data)
                }
            } catch (error) {
                console.error("Error fetching role:", error)
            } finally {
                setLoading(false)
            }
        }
        fetchRole()
    }, [id])

    if (loading) {
        return (
            <div className="layout-wrap">
                <Sidebar />
                <div className="section-content-right">
                    <Header />
                    <main className="main-content">
                        <div className="p-8 text-center text-gray-500">{t("roles.loadingRoleDetails")}</div>
                    </main>
                </div>
            </div>
        )
    }

    if (!role) {
        return (
            <div className="layout-wrap">
                <Sidebar />
                <div className="section-content-right">
                    <Header />
                    <main className="main-content">
                        <div className="p-8 text-center text-red-500">Rol no encontrado</div>
                    </main>
                </div>
            </div>
        )
    }

    return (
        <div className="layout-wrap">
            <Sidebar />
            <div className="section-content-right">
                <Header />
                <main className="main-content">
                    <div className="flex items-center gap-4 mb-8">
                        <Link href="/roles" className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                            <ArrowLeft size={24} className="text-gray-600" />
                        </Link>
                        <div>
                            <h1 className="text-3xl font-bold text-gray-900">Detalles del Rol</h1>
                            <p className="text-gray-600 mt-1">Visualizando permisos para: <span className="font-semibold text-orange-600">{role.name}</span></p>
                        </div>
                    </div>

                    <div className="bg-white rounded-lg border border-gray-200 p-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {PERMISSIONS.map((module) => {
                                const modulePermissions = module.actions.filter(action => role.permissions.includes(action.code))
                                const hasPermissions = modulePermissions.length > 0

                                return (
                                    <div key={module.module} className={`border rounded-lg p-4 ${hasPermissions ? 'border-orange-200 bg-orange-50/30' : 'border-gray-200 bg-gray-50'}`}>
                                        <h4 className={`font-medium mb-3 pb-2 border-b ${hasPermissions ? 'text-orange-800 border-orange-100' : 'text-gray-500 border-gray-200'}`}>
                                            {module.module}
                                        </h4>
                                        <div className="space-y-2">
                                            {module.actions.map((action) => {
                                                const isEnabled = role.permissions.includes(action.code)
                                                return (
                                                    <div key={action.code} className="flex items-center gap-2">
                                                        {isEnabled ? (
                                                            <CheckCircle size={16} className="text-green-600 flex-shrink-0" />
                                                        ) : (
                                                            <XCircle size={16} className="text-gray-300 flex-shrink-0" />
                                                        )}
                                                        <span className={`text-sm ${isEnabled ? 'text-gray-900 font-medium' : 'text-gray-400'}`}>
                                                            {action.label}
                                                        </span>
                                                    </div>
                                                )
                                            })}
                                        </div>
                                    </div>
                                )
                            })}
                        </div>
                    </div>

                    <Footer />
                </main>
            </div>
        </div>
    )
}
