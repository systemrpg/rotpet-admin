"use client"

import Layout from "@/components/layout"
import RoleForm from "../role-form"
import { useLanguage } from "@/contexts/LanguageContext"

export default function NewRolePage() {
  const { t } = useLanguage()
  
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("roles.createRole")}</h1>
        <p className="text-gray-600 mt-1">{t("roles.createRoleSubtitle")}</p>
      </div>

      <RoleForm />
    </Layout>
  )
}
