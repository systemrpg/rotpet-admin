"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Save, X } from "lucide-react"
import { PERMISSIONS } from "@/app/config/permissions"
import { toast } from "sonner"

interface RoleFormProps {
    roleId?: string
}

export default function RoleForm({ roleId }: RoleFormProps) {
    const router = useRouter()
    const [loading, setLoading] = useState(false)
    const [name, setName] = useState("")
    const [selectedPerms, setSelectedPerms] = useState<string[]>([])

    useEffect(() => {
        if (roleId) {
            const fetchRole = async () => {
                try {
                    const response = await fetch(`http://localhost:3001/api/roles/${roleId}`)
                    if (response.ok) {
                        const data = await response.json()
                        setName(data.name)
                        // Ensure permissions is an array
                        if (Array.isArray(data.permissions)) {
                            setSelectedPerms(data.permissions)
                        }
                    }
                } catch (error) {
                    console.error("Error fetching role:", error)
                }
            }
            fetchRole()
        }
    }, [roleId])

    const togglePermission = (code: string) => {
        setSelectedPerms((prev) =>
            prev.includes(code)
                ? prev.filter((p) => p !== code)
                : [...prev, code]
        )
    }

    const handleSelectAllModule = (moduleActions: { code: string }[]) => {
        const moduleCodes = moduleActions.map((a) => a.code)
        const allSelected = moduleCodes.every((code) => selectedPerms.includes(code))

        if (allSelected) {
            // Deselect all
            setSelectedPerms((prev) => prev.filter((code) => !moduleCodes.includes(code)))
        } else {
            // Select all
            const newPerms = [...selectedPerms]
            moduleCodes.forEach((code) => {
                if (!newPerms.includes(code)) {
                    newPerms.push(code)
                }
            })
            setSelectedPerms(newPerms)
        }
    }



    // ... inside component ...

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setLoading(true)

        try {
            const url = roleId
                ? `http://localhost:3001/api/roles/${roleId}`
                : "http://localhost:3001/api/roles"

            const method = roleId ? "PUT" : "POST"

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    name,
                    permissions: selectedPerms,
                }),
            })

            if (response.ok) {
                toast.success("Rol guardado correctamente")
                router.push("/roles")
                router.refresh()
            } else {
                const errorData = await response.json()
                toast.error("Error al guardar el rol", {
                    description: errorData.error || "Error desconocido"
                })
            }
        } catch (error) {
            console.error("Error saving role:", error)
            toast.error("Error al guardar el rol", {
                description: "Error de red o servidor"
            })
        } finally {
            setLoading(false)
        }
    }

    return (
        <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                    Nombre del Rol
                </label>
                <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ej: Vendedor"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent outline-none transition-all max-w-md"
                    required
                />
            </div>

            <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Permisos</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {PERMISSIONS.map((module) => (
                        <div key={module.module} className="border border-gray-200 rounded-lg p-4">
                            <div className="flex items-center justify-between mb-3 pb-2 border-b border-gray-100">
                                <h4 className="font-medium text-gray-900">{module.module}</h4>
                                <button
                                    type="button"
                                    onClick={() => handleSelectAllModule(module.actions)}
                                    className="text-xs text-orange-600 hover:text-orange-700 font-medium"
                                >
                                    {module.actions.every((a) => selectedPerms.includes(a.code))
                                        ? "Deseleccionar"
                                        : "Seleccionar Todo"}
                                </button>
                            </div>
                            <div className="space-y-2">
                                {module.actions.map((action) => (
                                    <label key={action.code} className="flex items-center gap-2 cursor-pointer group">
                                        <input
                                            type="checkbox"
                                            checked={selectedPerms.includes(action.code)}
                                            onChange={() => togglePermission(action.code)}
                                            className="w-4 h-4 text-orange-600 border-gray-300 rounded focus:ring-orange-500"
                                        />
                                        <span className="text-sm text-gray-600 group-hover:text-gray-900 transition-colors">
                                            {action.label}
                                        </span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            <div className="flex items-center gap-4 pt-4 border-t border-gray-100">
                <button
                    type="submit"
                    disabled={loading}
                    className="flex items-center gap-2 px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-medium disabled:opacity-50"
                >
                    <Save size={20} />
                    {loading ? "Guardando..." : "Guardar Rol"}
                </button>
                <Link
                    href="/roles"
                    className="flex items-center gap-2 px-6 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
                >
                    <X size={20} />
                    Cancelar
                </Link>
            </div>
        </form>
    )
}
