import Layout from "@/components/layout"
import CategoryForm from "../../category-form"

export default async function EditCategoryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Editar Categoría</h1>
        <p className="text-gray-600 mt-1">Modifica los detalles de la categoría</p>
      </div>

      <CategoryForm id={id} />
    </Layout>
  )
}
