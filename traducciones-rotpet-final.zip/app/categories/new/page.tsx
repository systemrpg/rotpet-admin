"use client"

import Layout from "@/components/layout"
import CategoryForm from "../category-form"
import { useLanguage } from "@/contexts/LanguageContext"

export default function NewCategoryPage() {
  const { t } = useLanguage()
  
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("categories.newCategory")}</h1>
        <p className="text-gray-600 mt-1">{t("categories.newCategorySubtitle")}</p>
      </div>

      <CategoryForm />
    </Layout>
  )
}
