"use client"

import Layout from "@/components/layout"
import GalleryComponent from "./gallery-component"
import { useState } from "react"
import { Image as ImageIcon, Plus, Trash2, Edit } from "lucide-react"
import { useLanguage } from "@/contexts/LanguageContext"

export default function GalleryPage() {
  const { t } = useLanguage()
  const [activeTab, setActiveTab] = useState("gallery")

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">{t("gallery.title")}</h1>
        <p className="text-gray-600 mt-1">{t("gallery.subtitle")}</p>
      </div>

      {/* Tabs */}
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="flex gap-8">
            <button
              onClick={() => setActiveTab("gallery")}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === "gallery"
                  ? "border-orange-600 text-orange-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              {t("gallery.images")}
            </button>
            <button
              onClick={() => setActiveTab("carousel")}
              className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                activeTab === "carousel"
                  ? "border-orange-600 text-orange-600"
                  : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
              }`}
            >
              {t("gallery.carousel")}
            </button>
          </nav>
        </div>
      </div>

      {/* Content */}
      {activeTab === "gallery" && <GalleryComponent />}
      {activeTab === "carousel" && <CarouselEditor />}
    </Layout>
  )
}

function CarouselEditor() {
  const [slides, setSlides] = useState([
    {
      id: 1,
      image: "/images/carousel/slide1.jpg",
      title: "Bienvenido a Rotpet",
      description: "Los mejores productos para tus mascotas",
      buttonText: "Ver Productos",
      buttonLink: "/products",
    },
    {
      id: 2,
      image: "/images/carousel/slide2.jpg",
      title: "Nuevos Productos",
      description: "Descubre nuestra última colección",
      buttonText: "Explorar",
      buttonLink: "/new-arrivals",
    },
  ])

  const [editingSlide, setEditingSlide] = useState<number | null>(null)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    buttonText: "",
    buttonLink: "",
    image: "",
  })

  const handleEdit = (slide: any) => {
    setEditingSlide(slide.id)
    setFormData({
      title: slide.title,
      description: slide.description,
      buttonText: slide.buttonText,
      buttonLink: slide.buttonLink,
      image: slide.image,
    })
  }

  const handleSave = () => {
    if (editingSlide) {
      setSlides(slides.map((s) => (s.id === editingSlide ? { ...s, ...formData } : s)))
      setEditingSlide(null)
      setFormData({ title: "", description: "", buttonText: "", buttonLink: "", image: "" })
    }
  }

  const handleAddNew = () => {
    const newSlide = {
      id: Math.max(...slides.map((s) => s.id)) + 1,
      image: "/images/upload/placeholder.jpg",
      title: "Nuevo Slide",
      description: "Descripción del slide",
      buttonText: "Ver Más",
      buttonLink: "/",
    }
    setSlides([...slides, newSlide])
  }

  const handleDelete = (id: number) => {
    if (confirm("¿Estás seguro de eliminar este slide?")) {
      setSlides(slides.filter((s) => s.id !== id))
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Slides List */}
      <div className="lg:col-span-2">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Slides del Carrusel</h2>
            <button onClick={handleAddNew} className="tf-button flex items-center gap-2">
              <Plus size={16} />
              Agregar Slide
            </button>
          </div>

          <div className="space-y-4">
            {slides.map((slide, index) => (
              <div
                key={slide.id}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
              >
                <div className="flex gap-4">
                  {/* Thumbnail */}
                  <div className="flex-shrink-0">
                    <div className="w-32 h-20 bg-gray-100 rounded-lg flex items-center justify-center overflow-hidden">
                      {slide.image ? (
                        <img
                          src={slide.image}
                          alt={slide.title}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            e.currentTarget.style.display = "none"
                            e.currentTarget.parentElement!.innerHTML = `<ImageIcon className="text-gray-400" size={24} />`
                          }}
                        />
                      ) : (
                        <ImageIcon className="text-gray-400" size={24} />
                      )}
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="inline-flex items-center justify-center w-6 h-6 bg-orange-100 text-orange-600 text-xs font-bold rounded">
                            {index + 1}
                          </span>
                          <h3 className="font-semibold text-gray-900">{slide.title}</h3>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{slide.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mt-3">
                      <button
                        onClick={() => handleEdit(slide)}
                        className="text-sm px-3 py-1.5 bg-orange-50 text-orange-600 rounded-lg hover:bg-orange-100 transition-colors flex items-center gap-1"
                      >
                        <Edit size={14} />
                        Editar
                      </button>
                      <button
                        onClick={() => handleDelete(slide.id)}
                        className="text-sm px-3 py-1.5 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors flex items-center gap-1"
                      >
                        <Trash2 size={14} />
                        Eliminar
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {slides.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <ImageIcon size={48} className="mx-auto mb-3 text-gray-300" />
                <p>No hay slides en el carrusel</p>
                <p className="text-sm mt-1">Haz clic en "Agregar Slide" para comenzar</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Edit Form */}
      <div className="lg:col-span-1">
        <div className="bg-white rounded-lg border border-gray-200 p-6 sticky top-6">
          <h3 className="font-semibold text-gray-900 mb-4">
            {editingSlide ? "Editar Slide" : "Selecciona un slide"}
          </h3>

          {editingSlide ? (
            <form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Título</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Descripción</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Texto del Botón
                </label>
                <input
                  type="text"
                  value={formData.buttonText}
                  onChange={(e) => setFormData({ ...formData, buttonText: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Enlace del Botón
                </label>
                <input
                  type="text"
                  value={formData.buttonLink}
                  onChange={(e) => setFormData({ ...formData, buttonLink: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                  placeholder="/ruta"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Imagen del Slide
                </label>
                <input
                  type="file"
                  accept="image/*"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
                <p className="text-xs text-gray-500 mt-1">Tamaño recomendado: 1920x600px</p>
              </div>

              <div className="flex gap-2 pt-4">
                <button
                  type="button"
                  onClick={handleSave}
                  className="flex-1 tf-button"
                >
                  Guardar Cambios
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEditingSlide(null)
                    setFormData({ title: "", description: "", buttonText: "", buttonLink: "", image: "" })
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancelar
                </button>
              </div>
            </form>
          ) : (
            <p className="text-sm text-gray-500 text-center py-8">
              Haz clic en "Editar" en cualquier slide para modificarlo
            </p>
          )}
        </div>
      </div>
    </div>
  )
}

