import Link from "next/link"

export default function Privacidad() {
  return (
    <div className="min-h-screen bg-background py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <Link href="/" className="text-primary hover:underline mb-4 inline-block">
          ← Volver al inicio
        </Link>

        <h1 className="text-4xl font-bold mb-2">Política de Privacidad</h1>
        <p className="text-lg text-muted-foreground mb-8">Última actualización: {new Date().getFullYear()}</p>

        <div className="prose prose-sm max-w-none space-y-6">
          <section>
            <h2 className="text-2xl font-semibold">1. Información que Recopilamos</h2>
            <p className="text-muted-foreground">
              Recopilamos información que proporcionas voluntariamente, como tu nombre, correo electrónico, dirección y
              número de teléfono al realizar una compra o crear una cuenta.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold">2. Cómo Usamos tu Información</h2>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>Para procesar tus pedidos y entregas</li>
              <li>Para enviarte actualizaciones sobre tus órdenes</li>
              <li>Para mejorar nuestros servicios</li>
              <li>Para comunicarnos contigo sobre ofertas especiales (si lo autorizas)</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold">3. Protección de tu Información</h2>
            <p className="text-muted-foreground">
              Utilizamos encriptación SSL y otras medidas de seguridad para proteger tu información personal. Nunca
              compartimos tu información con terceros sin tu consentimiento, excepto cuando sea necesario para procesar
              tus pedidos.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold">4. Tus Derechos</h2>
            <p className="text-muted-foreground">
              Tienes derecho a acceder, actualizar o eliminar tu información personal en cualquier momento. Puedes
              hacerlo desde tu cuenta o contactándonos directamente.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold">5. Contacto</h2>
            <p className="text-muted-foreground">
              Si tienes preguntas sobre nuestra política de privacidad, contáctanos a través de nuestro formulario de
              contacto o por WhatsApp.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}
