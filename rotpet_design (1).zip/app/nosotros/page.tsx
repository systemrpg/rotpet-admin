"use client"

export default function NosotrosPage() {
  return (
    <div className="container px-4 py-12 md:py-16">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Nosotros</h1>

        <div className="prose prose-sm max-w-none space-y-6">
          <section>
            <h2 className="text-2xl font-semibold mb-4">¿Quiénes Somos?</h2>
            <p className="text-muted-foreground">
              ROT PET SHOP es una tienda especializada en productos premium para mascotas. Nos dedicamos a ofrecer lo
              mejor en alimentos, juguetes, accesorios y todo lo que tu mascota necesita para estar feliz y saludable.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Nuestra Misión</h2>
            <p className="text-muted-foreground">
              Proporcionar productos de alta calidad y un servicio excepcional para cuidadores de mascotas que desean lo
              mejor para sus compañeros felinos y caninos.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">¿Por Qué Elegir ROT PET SHOP?</h2>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>Productos de primera calidad y marcas reconocidas</li>
              <li>Precios competitivos y promociones especiales</li>
              <li>Entrega rápida en tu domicilio</li>
              <li>Atención al cliente de excelencia</li>
              <li>Asesoramiento profesional en productos para mascotas</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Contáctanos</h2>
            <p className="text-muted-foreground">
              ¿Preguntas? Estamos aquí para ayudarte. Contáctanos a través de nuestras redes sociales o envía un mensaje
              directo a nuestro equipo.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}
