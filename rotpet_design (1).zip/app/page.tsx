import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Truck, RotateCcw, ShieldCheck, HeadphonesIcon, PawPrint, Cat, Dog } from "lucide-react"
import ProductCard from "@/components/product-card"
import HeroSlider from "@/components/hero-slider"
import NewsletterForm from "@/components/newsletter-form"
import { createClient } from "@/lib/supabase/server"

export const revalidate = 60

export default async function Home() {
  const supabase = await createClient()

  let featuredProducts: any[] = []
  let catProducts: any[] = []
  let dogProducts: any[] = []

  try {
    // Cargar productos destacados
    const { data: featured } = await supabase.from("productos").select("*").eq("destacado", true).limit(8)

    featuredProducts = featured || []

    // Cargar productos para gatos
    const { data: cats } = await supabase.from("productos").select("*").eq("mascota", "gato").limit(4)

    catProducts = cats || []

    // Cargar productos para perros
    const { data: dogs } = await supabase.from("productos").select("*").eq("mascota", "perro").limit(4)

    dogProducts = dogs || []
  } catch (error) {
    console.error("[v0] Error cargando productos:", error)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <HeroSlider
        slides={[
          {
            image: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?q=80&w=1920&auto=format&fit=crop",
            title: "Lo que tu mascota necesita, cuando lo necesita.",
            description: "Productos premium para gatos y perros con entrega el mismo día.",
            buttonText: "Compra Ahora",
            buttonLink: "/tienda",
          },
          {
            image: "https://images.unsplash.com/photo-1591946614720-90a587da4a36?q=80&w=1920&auto=format&fit=crop",
            title: "Alimentos de Calidad Premium",
            description: "Opciones nutritivas para la salud y felicidad de tus mascotas.",
            buttonText: "Ver Alimentos",
            buttonLink: "/tienda?categoria=alimento",
          },
          {
            image: "https://images.unsplash.com/photo-1560743641-3914f2c45636?q=80&w=1920&auto=format&fit=crop",
            title: "Juguetes Divertidos e Interactivos",
            description: "Mantén a tus mascotas activas y entretenidas con nuestra colección.",
            buttonText: "Ver Juguetes",
            buttonLink: "/tienda?categoria=juguetes",
          },
        ]}
      />

      <section className="py-12 bg-muted">
        <div className="container px-4">
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <Card className="bg-white border-none shadow-sm">
              <CardContent className="flex flex-col items-center text-center p-8">
                <div className="p-3 rounded-full bg-primary/10 mb-4">
                  <Truck className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold">Entrega Gratuita el Mismo Día</h3>
                <p className="text-sm text-muted-foreground mt-2">Ordena antes de las 2pm para entrega el mismo día</p>
              </CardContent>
            </Card>

            <Card className="bg-white border-none shadow-sm">
              <CardContent className="flex flex-col items-center text-center p-8">
                <div className="p-3 rounded-full bg-primary/10 mb-4">
                  <RotateCcw className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold">Devoluciones a 30 Días</h3>
                <p className="text-sm text-muted-foreground mt-2">
                  Sin preguntas, política de devolución sin complicaciones
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white border-none shadow-sm">
              <CardContent className="flex flex-col items-center text-center p-8">
                <div className="p-3 rounded-full bg-primary/10 mb-4">
                  <ShieldCheck className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold">Pago Seguro</h3>
                <p className="text-sm text-muted-foreground mt-2">100% procesamiento de pago seguro</p>
              </CardContent>
            </Card>

            <Card className="bg-white border-none shadow-sm">
              <CardContent className="flex flex-col items-center text-center p-8">
                <div className="p-3 rounded-full bg-primary/10 mb-4">
                  <HeadphonesIcon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="font-semibold">Soporte 24/7</h3>
                <p className="text-sm text-muted-foreground mt-2">
                  Atención al cliente disponible en cualquier momento
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Productos Destacados</h2>
              <p className="text-muted-foreground mt-2">Productos seleccionados especialmente para tus mascotas</p>
            </div>
            <Button asChild variant="link" className="text-primary mt-2 md:mt-0">
              <Link href="/tienda">Ver Todos los Productos</Link>
            </Button>
          </div>

          {featuredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No hay productos destacados disponibles</p>
            </div>
          )}
        </div>
      </section>

      <section className="py-16 bg-muted">
        <div className="container px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Productos para Gatos */}
            <div>
              <div className="flex items-center mb-6">
                <Cat className="h-6 w-6 text-primary mr-2" />
                <h2 className="text-2xl font-bold">Productos para Gatos</h2>
              </div>
              {catProducts.length > 0 ? (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {catProducts.map((product) => (
                      <ProductCard key={product.id} product={product} compact />
                    ))}
                  </div>
                  <div className="mt-6 text-center">
                    <Button asChild variant="outline">
                      <Link href="/tienda?mascota=gato">Ver Todos los Productos para Gatos</Link>
                    </Button>
                  </div>
                </>
              ) : (
                <p className="text-muted-foreground">No hay productos para gatos disponibles</p>
              )}
            </div>

            {/* Productos para Perros */}
            <div>
              <div className="flex items-center mb-6">
                <Dog className="h-6 w-6 text-primary mr-2" />
                <h2 className="text-2xl font-bold">Productos para Perros</h2>
              </div>
              {dogProducts.length > 0 ? (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {dogProducts.map((product) => (
                      <ProductCard key={product.id} product={product} compact />
                    ))}
                  </div>
                  <div className="mt-6 text-center">
                    <Button asChild variant="outline">
                      <Link href="/tienda?mascota=perro">Ver Todos los Productos para Perros</Link>
                    </Button>
                  </div>
                </>
              ) : (
                <p className="text-muted-foreground">No hay productos para perros disponibles</p>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-primary text-white">
        <div className="container px-4">
          <div className="max-w-3xl mx-auto text-center">
            <PawPrint className="h-12 w-12 mx-auto mb-4" />
            <h2 className="text-3xl font-bold mb-4">¡Únete a Nuestra Manada!</h2>
            <p className="text-white/90 mb-6">
              Suscríbete a nuestro newsletter para ofertas exclusivas, consejos de cuidado de mascotas y alertas de
              nuevos productos.
            </p>
            <NewsletterForm />
          </div>
        </div>
      </section>
    </div>
  )
}
