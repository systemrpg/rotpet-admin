import type React from "react"
import { redirect } from "next/navigation"

export default function CheckoutLayout({
  children,
}: {
  children: React.ReactNode
}) {
  redirect("/pago")
  return <>{children}</>
}
