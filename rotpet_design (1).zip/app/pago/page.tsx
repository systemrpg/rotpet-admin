"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { useCart } from "@/components/cart-provider"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Truck, ArrowLeft, CheckCircle2, MessageCircle } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { createBrowserClient } from "@/lib/supabase/client"

export default function PagoPage() {
  const { cartItems, clearCart } = useCart()
  const { toast } = useToast()
  const router = useRouter()
  const [orderPlaced, setOrderPlaced] = useState(false)
  const [loading, setLoading] = useState(false)
  const whatsappNumber = "+52 4121342478"

  const subtotal = cartItems.reduce((total, item) => total + (item.price || 0) * item.quantity, 0)
  const shipping = subtotal > 500 ? 0 : 99
  const total = subtotal + shipping

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)

    console.log("[v0] Iniciando proceso de pedido...")

    const formData = new FormData(e.currentTarget)
    const nombre = formData.get("firstName") + " " + formData.get("lastName")
    const email = formData.get("email") as string
    const telefono = formData.get("phone") as string
    const direccion = formData.get("address") as string
    const ciudad = formData.get("city") as string
    const estado = formData.get("state") as string
    const codigoPostal = formData.get("zipCode") as string
    const notas = formData.get("notes") as string

    try {
      const supabase = createBrowserClient()

      const {
        data: { user },
      } = await supabase.auth.getUser()
      console.log("[v0] Usuario:", user ? user.id : "Invitado")

      const direccionCompleta = `${direccion}, ${ciudad}, ${estado}, CP: ${codigoPostal}`

      console.log("[v0] Guardando orden en base de datos...")
      const { data: orden, error: ordenError } = await supabase
        .from("ordenes")
        .insert({
          usuario_id: user?.id || null,
          total: total,
          estado: "pendiente",
          metodo_pago: "whatsapp",
          numero_whatsapp: telefono,
          mensaje_whatsapp: notas || "",
        })
        .select()
        .single()

      if (ordenError) {
        console.error("[v0] Error guardando orden:", ordenError)
        throw new Error("Error al guardar la orden: " + ordenError.message)
      }

      console.log("[v0] Orden guardada con ID:", orden.id)

      console.log("[v0] Guardando items de la orden...")
      const ordenItems = cartItems.map((item) => ({
        orden_id: orden.id,
        producto_id: item.id,
        cantidad: item.quantity,
        precio_unitario: item.price || 0,
      }))

      const { error: itemsError } = await supabase.from("orden_items").insert(ordenItems)

      if (itemsError) {
        console.error("[v0] Error guardando items:", itemsError)
        throw new Error("Error al guardar los items: " + itemsError.message)
      }

      console.log("[v0] Items guardados exitosamente")

      let mensaje = `🛍️ *NUEVO PEDIDO #${orden.id.substring(0, 8).toUpperCase()}*\n\n`
      mensaje += `👤 *Cliente:* ${nombre}\n`
      mensaje += `📧 *Email:* ${email}\n`
      mensaje += `📱 *Teléfono:* ${telefono}\n\n`
      mensaje += `📦 *Productos:*\n`

      cartItems.forEach((item) => {
        mensaje += `• ${item.name} x${item.quantity} - $${((item.price || 0) * item.quantity).toFixed(2)}\n`
      })

      mensaje += `\n💰 *Subtotal:* $${subtotal.toFixed(2)}\n`
      mensaje += `🚚 *Envío:* ${shipping === 0 ? "Gratis" : `$${shipping.toFixed(2)}`}\n`
      mensaje += `💵 *Total:* $${total.toFixed(2)}\n\n`
      mensaje += `📍 *Dirección de Envío:*\n${direccionCompleta}\n`

      if (notas) {
        mensaje += `\n📝 *Notas:* ${notas}\n`
      }

      const whatsappUrl = `https://wa.me/${whatsappNumber.replace(/\D/g, "")}?text=${encodeURIComponent(mensaje)}`

      console.log("[v0] Pedido procesado exitosamente")
      setOrderPlaced(true)
      clearCart()

      toast({
        title: "¡Pedido confirmado!",
        description: "Tu pedido ha sido registrado. Serás redirigido a WhatsApp.",
      })

      if (typeof window !== "undefined" && (window as any).gtag) {
        console.log("[v0] Enviando evento a Google Analytics...")
        ;(window as any).gtag("event", "purchase", {
          transaction_id: orden.id,
          value: total,
          currency: "MXN",
          items: cartItems.map((item) => ({
            item_id: item.id,
            item_name: item.name,
            price: item.price,
            quantity: item.quantity,
          })),
        })
      }

      setTimeout(() => {
        console.log("[v0] Abriendo WhatsApp...")
        window.open(whatsappUrl, "_blank")
        router.push("/")
      }, 2000)
    } catch (error) {
      console.error("[v0] Error procesando pedido:", error)
      toast({
        title: "Error",
        description:
          error instanceof Error
            ? error.message
            : "Hubo un problema al procesar tu pedido. Por favor intenta de nuevo.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (orderPlaced) {
    return (
      <div className="container px-4 py-16 text-center">
        <CheckCircle2 className="h-16 w-16 mx-auto text-green-500" />
        <h1 className="mt-6 text-3xl font-bold">¡Pedido Listo!</h1>
        <p className="mt-2 text-muted-foreground max-w-md mx-auto">
          Serás redirigido a WhatsApp para confirmar los detalles del pago y envío con nosotros.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild>
            <Link href="/tienda">Continuar Comprando</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/">Volver al Inicio</Link>
          </Button>
        </div>
      </div>
    )
  }

  if (cartItems.length === 0) {
    return (
      <div className="container px-4 py-16 text-center">
        <h1 className="text-3xl font-bold">Tu carrito está vacío</h1>
        <p className="mt-2 text-muted-foreground">Agrega algunos artículos a tu carrito antes de proceder al pago.</p>
        <Button asChild className="mt-8">
          <Link href="/tienda">Ir a la Tienda</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container px-4 py-8 md:py-12">
      <div className="mb-8">
        <Link href="/carrito" className="flex items-center text-sm text-primary hover:underline">
          <ArrowLeft className="mr-1 h-4 w-4" />
          Volver al Carrito
        </Link>
      </div>

      <h1 className="text-3xl font-bold mb-8">Finalizar Pedido</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit}>
            <div className="space-y-8">
              {/* Información de Envío */}
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Información de Envío</h2>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">Nombre</Label>
                    <Input id="firstName" name="firstName" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Apellido</Label>
                    <Input id="lastName" name="lastName" required />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Correo Electrónico</Label>
                  <Input id="email" name="email" type="email" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Número de WhatsApp</Label>
                  <Input id="phone" name="phone" type="tel" placeholder="+52 123 456 7890" required />
                  <p className="text-xs text-muted-foreground">
                    Te contactaremos por WhatsApp para confirmar tu pedido
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Dirección</Label>
                  <Input id="address" name="address" required />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">Ciudad</Label>
                    <Input id="city" name="city" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state">Estado</Label>
                    <Input id="state" name="state" defaultValue="Guanajuato" required />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="zipCode">Código Postal</Label>
                  <Input id="zipCode" name="zipCode" required />
                </div>
              </div>

              {/* Información Adicional */}
              <div className="space-y-4">
                <h2 className="text-xl font-semibold">Información Adicional</h2>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notas del Pedido (Opcional)</Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    placeholder="Instrucciones especiales para la entrega, preferencias de pago, etc."
                  />
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
                <MessageCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                <div className="flex-1">
                  <h3 className="font-semibold text-blue-900">Pago por WhatsApp</h3>
                  <p className="text-sm text-blue-700 mt-1">
                    Al confirmar tu pedido, serás redirigido a WhatsApp donde podrás coordinar el método de pago
                    (transferencia, efectivo contra entrega, etc.) directamente con nosotros.
                  </p>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <input type="checkbox" id="terms" className="rounded border-gray-300" required />
                <Label htmlFor="terms" className="text-sm">
                  Acepto los{" "}
                  <Link href="/terminos" className="text-primary hover:underline">
                    Términos y Condiciones
                  </Link>{" "}
                  y la{" "}
                  <Link href="/privacidad" className="text-primary hover:underline">
                    Política de Privacidad
                  </Link>
                </Label>
              </div>

              <Button type="submit" className="w-full" disabled={loading}>
                {loading ? "Preparando..." : "Confirmar Pedido y Contactar por WhatsApp"}
              </Button>
            </div>
          </form>
        </div>

        <div>
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Resumen del Pedido</h2>

            <div className="space-y-4">
              <div className="max-h-80 overflow-y-auto space-y-4 pr-2">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex gap-4">
                    <div className="flex-shrink-0">
                      <Image
                        src={item.image || "/placeholder.svg?height=60&width=60"}
                        alt={item.name}
                        width={60}
                        height={60}
                        className="rounded-md object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-sm font-medium">{item.name}</h3>
                      <p className="text-xs text-muted-foreground">Cant: {item.quantity}</p>
                      <p className="text-sm font-medium mt-1">${((item.price || 0) * item.quantity).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>

              <Separator />

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Envío</span>
                  <span>{shipping === 0 ? "Gratis" : `$${shipping.toFixed(2)}`}</span>
                </div>

                <Separator />

                <div className="flex justify-between font-medium text-lg">
                  <span>Total</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-3 pt-4">
                <div className="flex items-center text-sm">
                  <Truck className="h-4 w-4 text-primary mr-2" />
                  <span>Envío gratis en pedidos mayores a $500</span>
                </div>
                <div className="flex items-center text-sm">
                  <MessageCircle className="h-4 w-4 text-primary mr-2" />
                  <span>Pago flexible por WhatsApp</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
