import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Truck, Clock, MapPin } from "lucide-react"

export default function Envios() {
  return (
    <div className="min-h-screen bg-background py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <Link href="/" className="text-primary hover:underline mb-4 inline-block">
          ← Volver al inicio
        </Link>

        <h1 className="text-4xl font-bold mb-2">Envíos y Entregas</h1>
        <p className="text-lg text-muted-foreground mb-8">Información sobre nuestro servicio de entrega</p>

        <div className="space-y-8">
          <div className="flex gap-4">
            <div className="flex-shrink-0">
              <Truck className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-semibold mb-2">Entrega Express</h2>
              <p className="text-muted-foreground">
                Entrega el mismo día para órdenes realizadas antes de las 5 PM. Disponible en Guanajuato.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0">
              <Clock className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-semibold mb-2">Horario de Entrega</h2>
              <p className="text-muted-foreground">
                Los pedidos se entregan entre las 6 PM y las 11 PM. Recibirás una notificación con la hora estimada de
                llegada.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0">
              <MapPin className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-semibold mb-2">Cobertura</h2>
              <p className="text-muted-foreground">
                Actualmente cubrimos Guanajuato. Pronto estaremos disponibles en otros estados. Contáctanos para
                consultar tu zona.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 p-6 bg-primary/10 rounded-lg">
          <h2 className="text-xl font-semibold mb-2">¿Preguntas sobre Envíos?</h2>
          <Link href="/contacto">
            <Button>Contactar</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
