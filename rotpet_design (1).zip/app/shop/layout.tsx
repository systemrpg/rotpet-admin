import type React from "react"
import { redirect } from "next/navigation"

export default function ShopLayout({
  children,
}: {
  children: React.ReactNode
}) {
  redirect("/tienda")
  return <>{children}</>
}
