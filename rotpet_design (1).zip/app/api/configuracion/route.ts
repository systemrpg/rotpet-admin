import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = createClient()
    const { data, error } = await supabase.from("configuracion_sitio").select("*")

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    return NextResponse.json(data || [])
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { clave, valor } = await request.json()
    const supabase = createClient()

    const { data: existing, error: selectError } = await supabase
      .from("configuracion_sitio")
      .select("id")
      .eq("clave", clave)
      .maybeSingle()

    if (selectError) return NextResponse.json({ error: selectError.message }, { status: 500 })

    const response = existing
      ? await supabase.from("configuracion_sitio").update({ valor }).eq("clave", clave)
      : await supabase.from("configuracion_sitio").insert({ clave, valor })

    if (response.error) return NextResponse.json({ error: response.error.message }, { status: 500 })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}