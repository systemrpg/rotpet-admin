import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export const revalidate = 60

export async function GET(request: Request) {
  try {
    const supabase = createClient()
    const url = new URL(request.url)
    const categoria = url.searchParams.get("categoria")
    const mascota = url.searchParams.get("mascota")
    const busqueda = url.searchParams.get("busqueda")

    let query = supabase.from("productos").select("*")
    if (categoria) query = query.eq("categoria", categoria)
    if (mascota) query = query.eq("mascota", mascota)
    if (busqueda) query = query.or(`nombre.ilike.%${busqueda}%,descripcion.ilike.%${busqueda}%`)

    const { data, error } = await query
    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    return NextResponse.json(data, { headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=120" } })
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}