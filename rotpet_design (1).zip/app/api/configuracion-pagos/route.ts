import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const supabase = createClient()
    const { data, error } = await supabase.from("configuracion_pagos").select("*").maybeSingle()

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    if (!data) {
      return NextResponse.json({
        stripe_habilitado: false,
        whatsapp_habilitado: true,
        mensaje_whatsapp: "Enviaremos los detalles de pago por WhatsApp",
      })
    }

    return NextResponse.json(data)
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}