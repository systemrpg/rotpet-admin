import Link from "next/link"

export default function Terminos() {
  return (
    <div className="min-h-screen bg-background py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <Link href="/" className="text-primary hover:underline mb-4 inline-block">
          ← Volver al inicio
        </Link>

        <h1 className="text-4xl font-bold mb-2">Términos y Condiciones</h1>
        <p className="text-lg text-muted-foreground mb-8">Última actualización: {new Date().getFullYear()}</p>

        <div className="prose prose-sm max-w-none space-y-6">
          <section>
            <h2 className="text-2xl font-semibold">1. Aceptación de Términos</h2>
            <p className="text-muted-foreground">
              Al acceder y utilizar ROT PET SHOP, aceptas estar vinculado por estos términos y condiciones. Si no estás
              de acuerdo con alguna parte, no debes usar este sitio.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold">2. Uso Permitido</h2>
            <p className="text-muted-foreground">
              Aceptas utilizar este sitio solo para propósitos legales y de una manera que no infrinja los derechos de
              otros ni restrinja su disfrute del sitio.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold">3. Productos y Precios</h2>
            <p className="text-muted-foreground">
              Nos reservamos el derecho de cambiar los precios de nuestros productos sin previo aviso. Los precios
              mostrados son válidos al momento de la compra.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold">4. Responsabilidad Limitada</h2>
            <p className="text-muted-foreground">
              ROT PET SHOP no será responsable por daños indirectos, incidentales o consecuentes derivados del uso de
              nuestros servicios.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold">5. Cambios en los Términos</h2>
            <p className="text-muted-foreground">
              Nos reservamos el derecho de modificar estos términos en cualquier momento. Los cambios entrarán en vigor
              una vez publicados.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold">6. Contacto</h2>
            <p className="text-muted-foreground">
              Si tienes preguntas sobre estos términos, contáctanos a través de nuestro formulario de contacto.
            </p>
          </section>
        </div>
      </div>
    </div>
  )
}
