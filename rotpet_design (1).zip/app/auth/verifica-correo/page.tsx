import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function VerificaCorreoPage() {
  return (
    <div className="flex min-h-svh w-full items-center justify-center p-6 md:p-10">
      <div className="w-full max-w-sm">
        <div className="flex flex-col gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">¡Verifica tu correo!</CardTitle>
              <CardDescription>Casi listo para empezar</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Te hemos enviado un enlace de confirmación a tu correo electrónico. Haz clic en el enlace para verificar
                tu cuenta y empezar a comprar en ROT PET SHOP.
              </p>
              <p className="text-sm text-muted-foreground">Si no ves el correo, revisa tu carpeta de spam.</p>
              <Button asChild className="w-full">
                <Link href="/auth/inicia-sesion">Volver al inicio de sesión</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
