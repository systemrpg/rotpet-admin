"use client"

import type React from "react"
import { useEffect, useState, Suspense, useCallback } from "react"
import ProductGrid from "@/components/product-grid"
import { useSearchParams } from "next/navigation"
import { Skeleton } from "@/components/ui/skeleton"
import { Input } from "@/components/ui/input"
import { Search } from "lucide-react"

function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value)

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value)
    }, delay)

    return () => {
      clearTimeout(handler)
    }
  }, [value, delay])

  return debouncedValue
}

function BuscarContent() {
  const [products, setProducts] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const searchParams = useSearchParams()

  const debouncedSearchTerm = useDebounce(searchTerm, 500)

  useEffect(() => {
    const query = searchParams.get("q")
    if (query) {
      setSearchTerm(query)
    }
  }, [searchParams])

  const loadProducts = useCallback(async (query: string) => {
    if (!query || query.trim().length < 2) {
      setProducts([])
      return
    }

    try {
      setLoading(true)
      const response = await fetch(`/api/productos?busqueda=${encodeURIComponent(query)}`)

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`)
      }

      const data = await response.json()
      setProducts(data || [])
    } catch (error: any) {
      console.error("[v0] Error buscando productos:", error?.message)
      setProducts([])
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (debouncedSearchTerm) {
      loadProducts(debouncedSearchTerm)
    } else {
      setProducts([])
    }
  }, [debouncedSearchTerm, loadProducts])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchTerm.trim()) {
      window.history.pushState({}, "", `/buscar?q=${encodeURIComponent(searchTerm)}`)
    }
  }

  const currentQuery = searchParams.get("q") || debouncedSearchTerm

  return (
    <div className="container px-4 py-8 md:py-12">
      <h1 className="text-3xl font-bold mb-8">Buscar Productos</h1>

      <form onSubmit={handleSearch} className="mb-8">
        <div className="relative max-w-2xl">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
          <Input
            type="search"
            placeholder="Buscar productos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 h-12 text-lg"
          />
        </div>
      </form>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array(8)
            .fill(0)
            .map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="h-60 w-full rounded-lg" />
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
        </div>
      ) : products.length > 0 ? (
        <>
          <p className="text-muted-foreground mb-6">
            Se encontraron {products.length} resultado{products.length !== 1 ? "s" : ""} para "{currentQuery}"
          </p>
          <ProductGrid products={products} />
        </>
      ) : currentQuery ? (
        <div className="text-center py-12">
          <p className="text-lg text-muted-foreground">No se encontraron productos para "{currentQuery}"</p>
          <p className="text-sm text-muted-foreground mt-2">Intenta con otros términos de búsqueda</p>
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-lg text-muted-foreground">Escribe algo en el buscador para encontrar productos</p>
        </div>
      )}
    </div>
  )
}

export default function BuscarPage() {
  return (
    <Suspense fallback={<div className="text-center py-12">Cargando...</div>}>
      <BuscarContent />
    </Suspense>
  )
}
