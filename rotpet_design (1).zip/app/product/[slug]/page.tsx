import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { Star, Truck, RotateCcw, ShieldCheck } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { createClient } from "@/lib/supabase/server"
import AddToCartButton from "@/components/add-to-cart-button"
import ProductQuantity from "@/components/product-quantity"
import RelatedProducts from "@/components/related-products"
import { cn } from "@/lib/utils"
import WishlistButton from "@/components/wishlist-button"

interface ProductPageProps {
  params: {
    slug: string
  }
}

export default async function ProductPage({ params }: ProductPageProps) {
  const { slug } = await params
  const supabase = await createClient()

  // Obtener el producto de la base de datos
  const { data: product, error } = await supabase.from("productos").select("*").eq("slug", slug).maybeSingle()

  if (error || !product) {
    notFound()
  }

  // Obtener productos relacionados
  const { data: relatedProducts } = await supabase
    .from("productos")
    .select("*")
    .neq("slug", product.slug)
    .or(`categoria.eq.${product.categoria},mascota.eq.${product.mascota}`)
    .limit(4)

  return (
    <div className="container px-4 py-8 md:py-12">
      <div className="flex flex-col md:flex-row gap-8 lg:gap-16">
        {/* Product Images */}
        <div className="md:w-1/2">
          <div className="sticky top-20">
            <div className="aspect-square overflow-hidden rounded-lg bg-muted">
              <Image
                src={product.imagen_url || "/placeholder.svg?height=600&width=600"}
                alt={product.nombre}
                width={600}
                height={600}
                className="h-full w-full object-cover"
                priority
              />
            </div>
            <div className="mt-4 grid grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((img, i) => (
                <div key={i} className="overflow-hidden rounded-lg bg-muted">
                  <Image
                    src={product.imagen_url || "/placeholder.svg?height=150&width=150"}
                    alt={`Vista del producto ${i}`}
                    width={150}
                    height={150}
                    className="h-full w-full object-cover"
                  />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Product Details */}
        <div className="md:w-1/2">
          <div className="mb-6">
            <Link href="/tienda" className="text-sm text-primary hover:underline">
              Volver a la Tienda
            </Link>
          </div>

          <h1 className="text-3xl font-bold">{product.nombre}</h1>

          <div className="mt-2 flex items-center">
            <div className="flex">
              {Array(5)
                .fill(0)
                .map((_, i) => (
                  <Star
                    key={i}
                    className={cn(
                      "h-5 w-5",
                      i < (product.rating || 4) ? "text-yellow-400 fill-yellow-400" : "text-gray-300",
                    )}
                  />
                ))}
            </div>
            <span className="ml-2 text-sm text-muted-foreground">
              {(product.rating || 4).toFixed(1)} ({product.review_count || 0} reseñas)
            </span>
          </div>

          <div className="mt-6">
            {product.precio_original && product.precio_original > product.precio ? (
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold text-primary">${(product.precio || 0).toFixed(2)}</span>
                <span className="text-lg text-muted-foreground line-through">
                  ${(product.precio_original || 0).toFixed(2)}
                </span>
                <span className="rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-800">
                  Ahorra ${((product.precio_original || 0) - (product.precio || 0)).toFixed(2)}
                </span>
              </div>
            ) : (
              <span className="text-3xl font-bold text-primary">${(product.precio || 0).toFixed(2)}</span>
            )}
          </div>

          <div className="mt-6 space-y-6">
            <p className="text-muted-foreground">{product.descripcion}</p>

            <div className="space-y-2">
              <div className="flex items-center">
                <div
                  className={cn(
                    "h-3 w-3 rounded-full mr-2",
                    (product.stock || 0) > 20
                      ? "bg-green-500"
                      : (product.stock || 0) > 0
                        ? "bg-yellow-500"
                        : "bg-red-500",
                  )}
                />
                <span>
                  {(product.stock || 0) > 20
                    ? "En Stock"
                    : (product.stock || 0) > 0
                      ? `Stock Bajo (${product.stock} disponibles)`
                      : "Agotado"}
                </span>
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <Truck className="mr-2 h-4 w-4" />
                <span>Envío gratis en pedidos mayores a $35</span>
              </div>
            </div>

            <div className="pt-4 space-y-4">
              <ProductQuantity maxQuantity={product.stock || 0} />

              <div className="flex flex-col sm:flex-row gap-3">
                <AddToCartButton
                  product={{
                    id: product.id,
                    name: product.nombre,
                    slug: product.slug,
                    description: product.descripcion,
                    price: product.precio,
                    originalPrice: product.precio_original,
                    image: product.imagen_url,
                    category: product.categoria,
                    pet: product.mascota,
                    rating: product.rating || 4,
                    reviewCount: product.review_count || 0,
                    stock: product.stock || 0,
                    featured: product.destacado || false,
                    isNew: product.nuevo || false,
                    tags: product.tags || [],
                  }}
                  className="flex-1"
                />
                <WishlistButton productId={product.id} variant="outline" size="default" />
              </div>
            </div>

            <div className="border-t border-b py-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="flex items-center">
                <Truck className="h-5 w-5 text-primary mr-2" />
                <div>
                  <p className="text-sm font-medium">Envío Gratis</p>
                  <p className="text-xs text-muted-foreground">Para pedidos mayores a $35</p>
                </div>
              </div>
              <div className="flex items-center">
                <RotateCcw className="h-5 w-5 text-primary mr-2" />
                <div>
                  <p className="text-sm font-medium">Devoluciones a 30 Días</p>
                  <p className="text-xs text-muted-foreground">Sin preguntas</p>
                </div>
              </div>
              <div className="flex items-center">
                <ShieldCheck className="h-5 w-5 text-primary mr-2" />
                <div>
                  <p className="text-sm font-medium">Pago Seguro</p>
                  <p className="text-xs text-muted-foreground">Pagos protegidos</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Tabs */}
      <div className="mt-16">
        <Tabs defaultValue="description">
          <TabsList className="w-full justify-start border-b rounded-none h-auto p-0">
            <TabsTrigger
              value="description"
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary py-3"
            >
              Descripción
            </TabsTrigger>
            <TabsTrigger
              value="details"
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary py-3"
            >
              Información Nutricional
            </TabsTrigger>
            <TabsTrigger
              value="reviews"
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary py-3"
            >
              Reseñas ({product.review_count || 0})
            </TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="pt-6">
            <div className="space-y-4">
              <p>
                {product.descripcion} Nuestra {product.nombre} de calidad premium está diseñada para proporcionar la
                mejor experiencia para tu mascota.
              </p>
              <p>
                Hecha con materiales e ingredientes de alta calidad, este producto es seguro y beneficioso para la salud
                y felicidad de tu mascota.
              </p>
              <ul className="list-disc pl-5 space-y-2">
                <li>Materiales de calidad premium</li>
                <li>Diseñado para comodidad y diversión de la mascota</li>
                <li>Duradero y de larga duración</li>
                <li>Seguro para todas las mascotas</li>
              </ul>
            </div>
          </TabsContent>
          <TabsContent value="details" className="pt-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">Información Nutricional</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium">Ingredientes</h4>
                  <p className="text-sm text-muted-foreground mt-1">
                    Fuentes de proteína premium, granos integrales, vegetales, vitaminas y minerales esenciales.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium">Análisis Garantizado</h4>
                  <ul className="text-sm text-muted-foreground mt-1 space-y-1">
                    <li>Proteína Cruda: 26% mín</li>
                    <li>Grasa Cruda: 15% mín</li>
                    <li>Fibra Cruda: 4% máx</li>
                    <li>Humedad: 10% máx</li>
                  </ul>
                </div>
              </div>
              <div>
                <h4 className="font-medium">Instrucciones de Alimentación</h4>
                <p className="text-sm text-muted-foreground mt-1">
                  Alimenta mascotas adultas 1/2 a 1 taza por cada 10 libras de peso corporal diariamente, dividido en
                  dos comidas. Ajusta según sea necesario para mantener una condición corporal ideal.
                </p>
              </div>
            </div>
          </TabsContent>
          <TabsContent value="reviews" className="pt-6">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium">Reseñas de Clientes</h3>
                  <div className="flex items-center mt-1">
                    <div className="flex">
                      {Array(5)
                        .fill(0)
                        .map((_, i) => (
                          <Star
                            key={i}
                            className={cn(
                              "h-5 w-5",
                              i < (product.rating || 4) ? "text-yellow-400 fill-yellow-400" : "text-gray-300",
                            )}
                          />
                        ))}
                    </div>
                    <span className="ml-2 text-sm text-muted-foreground">
                      Basado en {product.review_count || 0} reseñas
                    </span>
                  </div>
                </div>
                <Button>Escribir una Reseña</Button>
              </div>

              <div className="space-y-6">
                {/* Sample reviews */}
                {[
                  {
                    name: "Alex Johnson",
                    rating: 5,
                    date: "Hace 2 meses",
                    comment: "¡A mi mascota le encanta! Excelente calidad y envío rápido.",
                  },
                  {
                    name: "Sam Wilson",
                    rating: 4,
                    date: "Hace 3 meses",
                    comment: "Buen producto en general. A mi mascota le gusta, pero es un poco caro.",
                  },
                  {
                    name: "Jamie Smith",
                    rating: 5,
                    date: "Hace 4 meses",
                    comment: "¡Excelente calidad! Definitivamente compraré de nuevo.",
                  },
                ].map((review, index) => (
                  <div key={index} className="border-b pb-6 last:border-0">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="font-medium">{review.name}</p>
                        <div className="flex mt-1">
                          {Array(5)
                            .fill(0)
                            .map((_, i) => (
                              <Star
                                key={i}
                                className={cn(
                                  "h-4 w-4",
                                  i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300",
                                )}
                              />
                            ))}
                        </div>
                      </div>
                      <span className="text-sm text-muted-foreground">{review.date}</span>
                    </div>
                    <p className="mt-2">{review.comment}</p>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      {relatedProducts && relatedProducts.length > 0 && (
        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-6">Productos Relacionados</h2>
          <RelatedProducts
            products={relatedProducts.map((p) => ({
              id: p.id,
              name: p.nombre,
              slug: p.slug,
              description: p.descripcion,
              price: p.precio,
              originalPrice: p.precio_original,
              image: p.imagen_url,
              category: p.categoria,
              pet: p.mascota,
              rating: p.rating || 4,
              reviewCount: p.review_count || 0,
              stock: p.stock || 0,
              featured: p.destacado || false,
              isNew: p.nuevo || false,
              tags: p.tags || [],
            }))}
          />
        </div>
      )}
    </div>
  )
}
