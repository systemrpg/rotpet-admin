import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function AcercaDe() {
  return (
    <div className="min-h-screen bg-background py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <Link href="/" className="text-primary hover:underline mb-4 inline-block">
          ← Volver al inicio
        </Link>

        <h1 className="text-4xl font-bold mb-6">Acerca de ROT PET SHOP</h1>

        <div className="prose prose-sm max-w-none space-y-6">
          <p className="text-lg text-muted-foreground">
            En ROT PET SHOP, creemos que tus mascotas merecen los mejores productos y servicios. Somos una tienda
            especializada en ofrecer productos premium para gatos y perros con entrega rápida.
          </p>

          <h2 className="text-2xl font-semibold mt-8">Nuestra Misión</h2>
          <p className="text-muted-foreground">
            Proporcionar a los dueños de mascotas productos de la más alta calidad, con un excelente servicio al cliente
            y entregas rápidas. Nos comprometemos a facilitar la vida de nuestros clientes al ofrecerles lo que sus
            mascotas necesitan, cuando lo necesitan.
          </p>

          <h2 className="text-2xl font-semibold mt-8">¿Por Qué Elegirnos?</h2>
          <ul className="list-disc list-inside space-y-2 text-muted-foreground">
            <li>Productos premium seleccionados especialmente para mascotas</li>
            <li>Entrega el mismo día en la ciudad</li>
            <li>Atención al cliente excepcional</li>
            <li>Precios competitivos y ofertas especiales</li>
            <li>Garantía de satisfacción en todos nuestros productos</li>
          </ul>

          <h2 className="text-2xl font-semibold mt-8">Contáctanos</h2>
          <p className="text-muted-foreground">
            ¿Tienes preguntas? Nos encantaría hablar contigo. Contáctanos a través de nuestras redes sociales o envía un
            mensaje por WhatsApp.
          </p>

          <div className="mt-8">
            <Link href="/contacto">
              <Button>Ir a Contacto</Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
