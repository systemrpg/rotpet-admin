import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Heart } from "lucide-react"
import { createClient } from "@/lib/supabase/server"

export default async function Header() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  return (
    <header className="border-b sticky top-0 bg-white z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2">
            <img
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-text-fapdWSISs6QZa9IFHy4QlLEbREewfX.png"
              alt="ROT PET SHOP"
              className="h-8"
            />
          </Link>

          <nav className="hidden md:flex gap-6">
            <Link href="/tienda" className="hover:text-primary">
              Tienda
            </Link>
            <Link href="/acerca-de" className="hover:text-primary">
              Acerca de
            </Link>
            <Link href="/contacto" className="hover:text-primary">
              Contacto
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            {user ? (
              <>
                <Link href="/cuenta">
                  <Button variant="outline" size="sm">
                    Mi Cuenta
                  </Button>
                </Link>
                {/* Check if user is admin */}
                <a href="/admin">
                  <Button variant="ghost" size="sm" className="hidden md:inline">
                    Admin
                  </Button>
                </a>
              </>
            ) : (
              <Link href="/auth/inicia-sesion">
                <Button size="sm">Inicia Sesión</Button>
              </Link>
            )}
            <Link href="/carrito">
              <Button variant="ghost" size="icon">
                <ShoppingCart className="h-5 w-5" />
              </Button>
            </Link>
            <Link href="/wishlist">
              <Button variant="ghost" size="icon">
                <Heart className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  )
}
