"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar, User } from "lucide-react"

const blogPosts = [
  {
    id: 1,
    title: "Consejos para Cuidar a tu Gato",
    description: "Descubre los mejores consejos para mantener a tu gato saludable y feliz.",
    author: "ROT PET SHOP",
    date: "2024-01-15",
    category: "Cuidados",
  },
  {
    id: 2,
    title: "Alimentación Balanceada para Perros",
    description: "Aprende cuál es la mejor alimentación para tu perro según su edad y tamaño.",
    author: "ROT PET SHOP",
    date: "2024-01-10",
    category: "Nutrición",
  },
  {
    id: 3,
    title: "Juguetes Interactivos para Mascotas",
    description: "Conoce los mejores juguetes para mantener a tus mascotas activas y entretenidas.",
    author: "ROT PET SHOP",
    date: "2024-01-05",
    category: "Entretenimiento",
  },
]

export default function BlogPage() {
  return (
    <main className="min-h-screen bg-muted py-12">
      <div className="container px-4">
        <div className="mb-8">
          <Link href="/" className="text-sm text-primary hover:underline">
            ← Volver al inicio
          </Link>
        </div>

        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Blog de ROT PET SHOP</h1>
          <p className="text-lg text-muted-foreground">Consejos, guías y noticias sobre el cuidado de tus mascotas</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogPosts.map((post) => (
            <Card key={post.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-semibold px-2 py-1 bg-primary/10 text-primary rounded">
                    {post.category}
                  </span>
                </div>
                <CardTitle className="line-clamp-2">{post.title}</CardTitle>
                <CardDescription className="line-clamp-2">{post.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-1" />
                    {post.author}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-1" />
                    {new Date(post.date).toLocaleDateString("es-MX")}
                  </div>
                </div>
                <Button variant="outline" className="w-full bg-transparent" disabled>
                  Leer Más (Próximamente)
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </main>
  )
}
