"use client"

import Link from "next/link"
import Image from "next/image"
import { useCart } from "@/components/cart-provider"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Trash2, ShoppingBag, ArrowRight } from "lucide-react"
import ProductQuantity from "@/components/product-quantity"

export default function CartPage() {
  const { cartItems, removeFromCart, updateQuantity, clearCart } = useCart()

  const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0)
  const shipping = subtotal > 35 ? 0 : 5.99
  const total = subtotal + shipping

  if (cartItems.length === 0) {
    return (
      <div className="container px-4 py-16 text-center">
        <ShoppingBag className="h-16 w-16 mx-auto text-muted-foreground" />
        <h1 className="mt-6 text-3xl font-bold">Tu carrito está vacío</h1>
        <p className="mt-2 text-muted-foreground">Parece que aún no has añadido nada a tu carrito.</p>
        <Button asChild className="mt-8">
          <Link href="/tienda">Continuar Comprando</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container px-4 py-8 md:py-12">
      <h1 className="text-3xl font-bold mb-8">Carrito de Compras</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="rounded-lg border">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">
                  Artículos del Carrito ({cartItems.reduce((total, item) => total + item.quantity, 0)})
                </h2>
                <Button variant="ghost" size="sm" onClick={clearCart}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Vaciar Carrito
                </Button>
              </div>

              <Separator className="my-4" />

              <div className="space-y-6">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-shrink-0">
                      <Image
                        src={item.image || "/placeholder.svg?height=100&width=100"}
                        alt={item.name}
                        width={100}
                        height={100}
                        className="rounded-md object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-col sm:flex-row sm:justify-between">
                        <div>
                          <h3 className="font-medium">{item.name}</h3>
                          <p className="text-sm text-muted-foreground mt-1">${item.price.toFixed(2)}</p>
                        </div>
                        <div className="mt-2 sm:mt-0 flex items-center">
                          <ProductQuantity
                            initialQuantity={item.quantity}
                            maxQuantity={10}
                            onQuantityChange={(quantity) => updateQuantity(item.id, quantity)}
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeFromCart(item.id)}
                            className="ml-2 text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Eliminar artículo</span>
                          </Button>
                        </div>
                      </div>
                      <div className="mt-2 sm:text-right font-medium">${(item.price * item.quantity).toFixed(2)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div>
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Resumen del Pedido</h2>

            <div className="space-y-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Envío</span>
                <span>{shipping === 0 ? "Gratis" : `$${shipping.toFixed(2)}`}</span>
              </div>

              <Separator />

              <div className="flex justify-between font-medium">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>

              {subtotal < 35 && (
                <div className="text-sm text-muted-foreground mt-2">
                  Agrega ${(35 - subtotal).toFixed(2)} más para calificar para envío gratis
                </div>
              )}

              <Button asChild className="w-full mt-4">
                <Link href="/pago">
                  Proceder al Pago
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>

              <div className="text-center text-xs text-muted-foreground mt-4">Pago flexible por WhatsApp</div>
            </div>
          </Card>

          <div className="mt-6">
            <Button asChild variant="outline" className="w-full bg-transparent">
              <Link href="/tienda">Continuar Comprando</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
