import { redirect } from "next/navigation"
import { isUserAdmin } from "@/lib/utils/auth"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import AdminDashboard from "@/components/admin/dashboard"
import GestionProductos from "@/components/admin/gestion-productos"
import GestionOrdenes from "@/components/admin/gestion-ordenes"
import GestionUsuarios from "@/components/admin/gestion-usuarios"
import GestionNewsletter from "@/components/admin/gestion-newsletter"
import GestionBackup from "@/components/admin/gestion-backup"
import GestionRedesSociales from "@/components/admin/gestion-redes-sociales"

export default async function AdminPage() {
  const isAdmin = await isUserAdmin()

  if (!isAdmin) {
    redirect("/")
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Panel de Administración</h1>
        <Button asChild variant="outline">
          <Link href="/">Volver al sitio</Link>
        </Button>
      </div>

      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="productos">Productos</TabsTrigger>
          <TabsTrigger value="ordenes">Órdenes</TabsTrigger>
          <TabsTrigger value="usuarios">Usuarios</TabsTrigger>
          <TabsTrigger value="newsletter">Newsletter</TabsTrigger>
          <TabsTrigger value="redes">Redes Sociales</TabsTrigger>
          <TabsTrigger value="backup">Backup</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="mt-6">
          <AdminDashboard />
        </TabsContent>

        <TabsContent value="productos" className="mt-6">
          <GestionProductos />
        </TabsContent>

        <TabsContent value="ordenes" className="mt-6">
          <GestionOrdenes />
        </TabsContent>

        <TabsContent value="usuarios" className="mt-6">
          <GestionUsuarios />
        </TabsContent>

        <TabsContent value="newsletter" className="mt-6">
          <GestionNewsletter />
        </TabsContent>

        <TabsContent value="redes" className="mt-6">
          <GestionRedesSociales />
        </TabsContent>

        <TabsContent value="backup" className="mt-6">
          <GestionBackup />
        </TabsContent>
      </Tabs>
    </div>
  )
}
