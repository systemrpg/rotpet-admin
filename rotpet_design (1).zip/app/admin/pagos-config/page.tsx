"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { Loader2 } from "lucide-react"

export default function PagosConfigPage() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [config, setConfig] = useState({
    stripe_habilitado: false,
    whatsapp_habilitado: true,
    mensaje_whatsapp: "Enviaremos los detalles de pago por WhatsApp",
  })
  const { toast } = useToast()
  const supabase = createClient()

  useEffect(() => {
    loadConfig()
  }, [])

  const loadConfig = async () => {
    try {
      const { data, error } = await supabase.from("configuracion_pagos").select("*").maybeSingle()

      if (error) throw error

      if (data) {
        setConfig({
          stripe_habilitado: data.stripe_habilitado,
          whatsapp_habilitado: data.whatsapp_habilitado,
          mensaje_whatsapp: data.mensaje_whatsapp,
        })
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: "No se pudo cargar la configuración: " + error.message,
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      // Primero intentar actualizar
      const { error: updateError } = await supabase
        .from("configuracion_pagos")
        .update({
          stripe_habilitado: config.stripe_habilitado,
          whatsapp_habilitado: config.whatsapp_habilitado,
          mensaje_whatsapp: config.mensaje_whatsapp,
          updated_at: new Date().toISOString(),
        })
        .eq("id", (await supabase.from("configuracion_pagos").select("id").maybeSingle()).data?.id)

      if (updateError) throw updateError

      toast({
        title: "Configuración guardada",
        description: "Los cambios se han guardado correctamente",
      })
    } catch (error: any) {
      toast({
        title: "Error",
        description: "No se pudo guardar la configuración: " + error.message,
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="container max-w-4xl py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Configuración de Pagos</h1>
        <p className="text-muted-foreground mt-2">Configura los métodos de pago disponibles para tus clientes</p>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Stripe</CardTitle>
            <CardDescription>Acepta pagos con tarjeta de crédito/débito a través de Stripe</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Label htmlFor="stripe-enabled" className="flex flex-col space-y-1">
                <span>Habilitar pagos con Stripe</span>
                <span className="font-normal text-sm text-muted-foreground">
                  Los clientes podrán pagar directamente en el sitio
                </span>
              </Label>
              <Switch
                id="stripe-enabled"
                checked={config.stripe_habilitado}
                onCheckedChange={(checked) => setConfig({ ...config, stripe_habilitado: checked })}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>WhatsApp</CardTitle>
            <CardDescription>Procesa pagos manualmente a través de WhatsApp</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Label htmlFor="whatsapp-enabled" className="flex flex-col space-y-1">
                <span>Habilitar pagos por WhatsApp</span>
                <span className="font-normal text-sm text-muted-foreground">
                  Los clientes recibirán instrucciones de pago por WhatsApp
                </span>
              </Label>
              <Switch
                id="whatsapp-enabled"
                checked={config.whatsapp_habilitado}
                onCheckedChange={(checked) => setConfig({ ...config, whatsapp_habilitado: checked })}
              />
            </div>

            {config.whatsapp_habilitado && (
              <div className="space-y-2">
                <Label htmlFor="whatsapp-message">Mensaje para clientes</Label>
                <Textarea
                  id="whatsapp-message"
                  value={config.mensaje_whatsapp}
                  onChange={(e) => setConfig({ ...config, mensaje_whatsapp: e.target.value })}
                  placeholder="Mensaje que verán los clientes al elegir pago por WhatsApp"
                  rows={3}
                />
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button onClick={handleSave} disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Guardar Cambios
          </Button>
        </div>
      </div>
    </div>
  )
}
