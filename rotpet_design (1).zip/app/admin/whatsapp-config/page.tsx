"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export default function WhatsAppConfigPage() {
  const [config, setConfig] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    numero_whatsapp: "",
    mensajes_habilitados: false,
    plantilla_mensaje: "",
  })
  const supabase = createClient()

  useEffect(() => {
    const fetchConfig = async () => {
      const { data } = await supabase.from("configuracion_whatsapp").select("*").maybeSingle()

      if (data) {
        setConfig(data)
        setFormData({
          numero_whatsapp: data.numero_whatsapp,
          mensajes_habilitados: data.mensajes_habilitados,
          plantilla_mensaje: data.plantilla_mensaje || "",
        })
      }
      setLoading(false)
    }

    fetchConfig()
  }, [supabase])

  const handleSave = async () => {
    setSaving(true)
    try {
      if (config) {
        const { error } = await supabase
          .from("configuracion_whatsapp")
          .update({
            numero_whatsapp: formData.numero_whatsapp,
            mensajes_habilitados: formData.mensajes_habilitados,
            plantilla_mensaje: formData.plantilla_mensaje,
          })
          .eq("id", config.id)

        if (error) throw error
      } else {
        const { error } = await supabase.from("configuracion_whatsapp").insert({
          numero_whatsapp: formData.numero_whatsapp,
          mensajes_habilitados: formData.mensajes_habilitados,
          plantilla_mensaje: formData.plantilla_mensaje,
        })

        if (error) throw error
      }

      alert("Configuración guardada exitosamente")
    } catch (error) {
      console.error("Error al guardar:", error)
      alert("Error al guardar la configuración")
    } finally {
      setSaving(false)
    }
  }

  if (loading) return <div>Cargando configuración...</div>

  return (
    <Card className="max-w-2xl">
      <CardHeader>
        <CardTitle>Configuración de WhatsApp</CardTitle>
        <CardDescription>Configura el número de WhatsApp y mensajes automáticos</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-2">
          <Label htmlFor="numero">Número de WhatsApp</Label>
          <Input
            id="numero"
            placeholder="+52 1234567890"
            value={formData.numero_whatsapp}
            onChange={(e) => setFormData({ ...formData, numero_whatsapp: e.target.value })}
          />
          <p className="text-xs text-muted-foreground">Incluir código de país (ej: +52 para México)</p>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            id="habilitar"
            checked={formData.mensajes_habilitados}
            onChange={(e) => setFormData({ ...formData, mensajes_habilitados: e.target.checked })}
            className="w-4 h-4"
          />
          <Label htmlFor="habilitar" className="mb-0">
            Habilitar mensajes automáticos
          </Label>
        </div>

        <div className="grid gap-2">
          <Label htmlFor="plantilla">Plantilla de Mensaje Automático</Label>
          <Textarea
            id="plantilla"
            placeholder="Hola, tu pedido #{order_id} ha sido recibido. Total: ${total}. Te contactaremos pronto con los detalles de entrega."
            value={formData.plantilla_mensaje}
            onChange={(e) => setFormData({ ...formData, plantilla_mensaje: e.target.value })}
            className="h-24"
          />
          <p className="text-xs text-muted-foreground">
            Variables disponibles: {"{"}order_id{"}"}, ${"{"}total{"}"}
          </p>
        </div>

        <Button onClick={handleSave} disabled={saving} className="w-full">
          {saving ? "Guardando..." : "Guardar Configuración"}
        </Button>
      </CardContent>
    </Card>
  )
}
