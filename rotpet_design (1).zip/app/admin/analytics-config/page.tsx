"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { useToast } from "@/components/ui/use-toast"
import { createBrowserClient } from "@/lib/supabase/client"
import { Loader2, BarChart3 } from "lucide-react"

export default function AnalyticsConfigPage() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [config, setConfig] = useState({
    google_analytics_id: "",
    habilitado: false,
  })
  const { toast } = useToast()

  useEffect(() => {
    loadConfig()
  }, [])

  const loadConfig = async () => {
    try {
      const supabase = createBrowserClient()
      const { data, error } = await supabase.from("configuracion_analytics").select("*").single()

      if (error) throw error

      if (data) {
        setConfig({
          google_analytics_id: data.google_analytics_id || "",
          habilitado: data.habilitado || false,
        })
      }
    } catch (error) {
      console.error("Error cargando configuración:", error)
      toast({
        title: "Error",
        description: "No se pudo cargar la configuración de Analytics",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const supabase = createBrowserClient()

      // Primero intentar actualizar
      const { error: updateError } = await supabase
        .from("configuracion_analytics")
        .update({
          google_analytics_id: config.google_analytics_id,
          habilitado: config.habilitado,
          updated_at: new Date().toISOString(),
        })
        .eq("id", (await supabase.from("configuracion_analytics").select("id").single()).data?.id)

      if (updateError) {
        // Si falla, intentar insertar
        const { error: insertError } = await supabase.from("configuracion_analytics").insert({
          google_analytics_id: config.google_analytics_id,
          habilitado: config.habilitado,
        })

        if (insertError) throw insertError
      }

      toast({
        title: "Configuración guardada",
        description: "La configuración de Google Analytics se ha actualizado correctamente",
      })

      // Recargar la página para aplicar cambios
      setTimeout(() => {
        window.location.reload()
      }, 1000)
    } catch (error) {
      console.error("Error guardando configuración:", error)
      toast({
        title: "Error",
        description: "No se pudo guardar la configuración",
        variant: "destructive",
      })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="container py-8 flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="container py-8">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Configuración de Google Analytics</h1>
          <p className="text-muted-foreground mt-2">
            Configura Google Analytics para rastrear métricas y conversiones en tu sitio
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Google Analytics
            </CardTitle>
            <CardDescription>
              Habilita Google Analytics para obtener métricas detalladas de tus visitantes y ventas
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="habilitado">Habilitar Google Analytics</Label>
                <p className="text-sm text-muted-foreground">Activa o desactiva el seguimiento de Analytics</p>
              </div>
              <Switch
                id="habilitado"
                checked={config.habilitado}
                onCheckedChange={(checked) => setConfig({ ...config, habilitado: checked })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="ga-id">ID de Google Analytics</Label>
              <Input
                id="ga-id"
                placeholder="G-XXXXXXXXXX"
                value={config.google_analytics_id}
                onChange={(e) => setConfig({ ...config, google_analytics_id: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Ingresa tu ID de medición de Google Analytics (formato: G-XXXXXXXXXX)
              </p>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">¿Cómo obtener tu ID de Google Analytics?</h4>
              <ol className="text-sm text-blue-700 space-y-1 list-decimal list-inside">
                <li>
                  Ve a{" "}
                  <a
                    href="https://analytics.google.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    Google Analytics
                  </a>
                </li>
                <li>Crea una propiedad para tu sitio web</li>
                <li>Copia el ID de medición (comienza con G-)</li>
                <li>Pégalo en el campo de arriba</li>
              </ol>
            </div>

            <Button onClick={handleSave} disabled={saving} className="w-full">
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Guardando...
                </>
              ) : (
                "Guardar Configuración"
              )}
            </Button>
          </CardContent>
        </Card>

        <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-sm text-yellow-800">
            <strong>Nota:</strong> Los cambios en la configuración de Analytics requieren recargar la página para
            aplicarse. La página se recargará automáticamente después de guardar.
          </p>
        </div>
      </div>
    </div>
  )
}
