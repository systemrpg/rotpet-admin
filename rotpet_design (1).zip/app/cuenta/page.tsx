import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import PerfilComponent from "@/components/cuenta/perfil"
import HistorialOrdenesComponent from "@/components/cuenta/historial-ordenes"
import ReseniasComponent from "@/components/cuenta/resenas"

export default async function CuentaPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/inicia-sesion")
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Mi Cuenta</h1>
        <Button asChild variant="outline">
          <Link href="/tienda">Volver a la tienda</Link>
        </Button>
      </div>

      <Tabs defaultValue="perfil" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="perfil">Mi Perfil</TabsTrigger>
          <TabsTrigger value="ordenes">Historial de Órdenes</TabsTrigger>
          <TabsTrigger value="resenas">Mis Reseñas</TabsTrigger>
        </TabsList>

        <TabsContent value="perfil" className="mt-6">
          <PerfilComponent userId={user.id} />
        </TabsContent>

        <TabsContent value="ordenes" className="mt-6">
          <HistorialOrdenesComponent userId={user.id} />
        </TabsContent>

        <TabsContent value="resenas" className="mt-6">
          <ReseniasComponent userId={user.id} />
        </TabsContent>
      </Tabs>
    </div>
  )
}
