"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Heart, ShoppingCart, Trash2 } from "lucide-react"
import { useCart } from "@/components/cart-provider"
import type { Product } from "@/lib/types"

export default function WishlistPage() {
  const [wishlistItems, setWishlistItems] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const { addToCart } = useCart()

  useEffect(() => {
    const loadWishlist = async () => {
      const savedWishlist = localStorage.getItem("wishlist")
      if (!savedWishlist) {
        setLoading(false)
        return
      }

      try {
        const wishlistIds = JSON.parse(savedWishlist) as string[]
        if (wishlistIds.length === 0) {
          setLoading(false)
          return
        }

        // Cargar productos desde la API
        const response = await fetch("/api/productos")
        if (!response.ok) throw new Error("Error cargando productos")

        const allProducts = await response.json()
        const items = allProducts.filter((product: Product) => wishlistIds.includes(product.id))
        setWishlistItems(items)
      } catch (error) {
        console.error("Error cargando wishlist:", error)
      } finally {
        setLoading(false)
      }
    }

    loadWishlist()
  }, [])

  const removeFromWishlist = (productId: string) => {
    const newItems = wishlistItems.filter((item) => item.id !== productId)
    setWishlistItems(newItems)

    // Actualizar localStorage
    const wishlistIds = newItems.map((item) => item.id)
    localStorage.setItem("wishlist", JSON.stringify(wishlistIds))
  }

  const handleAddToCart = (product: Product) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
    })
  }

  if (loading) {
    return (
      <div className="container px-4 py-16 text-center">
        <p className="text-muted-foreground">Cargando lista de deseos...</p>
      </div>
    )
  }

  if (wishlistItems.length === 0) {
    return (
      <div className="container px-4 py-16 text-center">
        <Heart className="h-16 w-16 mx-auto text-muted-foreground" />
        <h1 className="mt-6 text-3xl font-bold">Tu lista de deseos está vacía</h1>
        <p className="mt-2 text-muted-foreground">
          Guarda los artículos que te gustan en tu lista de deseos y visítalos en cualquier momento.
        </p>
        <Button asChild className="mt-8">
          <Link href="/tienda">Continuar Comprando</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="container px-4 py-8 md:py-12">
      <h1 className="text-3xl font-bold mb-8">Mi Lista de Deseos</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {wishlistItems.map((product) => (
          <Card key={product.id} className="overflow-hidden">
            <div className="relative">
              <Link href={`/producto/${product.slug}`}>
                <Image
                  src={product.image || "/placeholder.svg?height=300&width=300"}
                  alt={product.name}
                  width={300}
                  height={300}
                  className="w-full h-60 object-cover"
                />
              </Link>
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2 bg-white/80 hover:bg-white text-primary"
                onClick={() => removeFromWishlist(product.id)}
              >
                <Trash2 className="h-5 w-5" />
                <span className="sr-only">Eliminar de la lista de deseos</span>
              </Button>
            </div>
            <div className="p-4">
              <Link href={`/producto/${product.slug}`} className="hover:underline">
                <h3 className="font-semibold text-lg mb-1">{product.name}</h3>
              </Link>
              <p className="text-muted-foreground text-sm mb-2 line-clamp-2">{product.description}</p>
              <div className="flex justify-between items-center mt-4">
                <span className="font-bold text-primary">${product.price?.toFixed(2) || "0.00"}</span>
                <Button onClick={() => handleAddToCart(product)} size="sm">
                  <ShoppingCart className="h-4 w-4 mr-2" />
                  Agregar
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
