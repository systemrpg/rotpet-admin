import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ChevronDown } from "lucide-react"

export default function Ayuda() {
  const faqs = [
    {
      pregunta: "¿Cuál es el tiempo de entrega?",
      respuesta:
        "Ofrecemos entrega el mismo día en Guanajuato. Las órdenes realizadas antes de las 5 PM se entregan antes de las 11 PM.",
    },
    {
      pregunta: "¿Cómo puedo rastrear mi pedido?",
      respuesta:
        "Recibirás un código de seguimiento por correo electrónico una vez que tu pedido sea procesado. Puedes rastrearlo desde tu cuenta o enviándonos un mensaje por WhatsApp.",
    },
    {
      pregunta: "¿Aceptan devoluciones?",
      respuesta:
        "Sí, aceptamos devoluciones en los primeros 7 días si el producto no ha sido usado. Para más detalles, consulta nuestra política de devoluciones.",
    },
    {
      pregunta: "¿Cuáles son los métodos de pago?",
      respuesta:
        "Aceptamos todas las tarjetas de crédito y débito, transferencias bancarias, y pagos por WhatsApp Pay.",
    },
  ]

  return (
    <div className="min-h-screen bg-background py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <Link href="/" className="text-primary hover:underline mb-4 inline-block">
          ← Volver al inicio
        </Link>

        <h1 className="text-4xl font-bold mb-2">Centro de Ayuda</h1>
        <p className="text-lg text-muted-foreground mb-8">Encuentra respuestas a tus preguntas frecuentes</p>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <details key={index} className="border rounded-lg p-4 bg-card">
              <summary className="cursor-pointer font-semibold flex items-center justify-between">
                {faq.pregunta}
                <ChevronDown className="h-4 w-4" />
              </summary>
              <p className="mt-4 text-muted-foreground">{faq.respuesta}</p>
            </details>
          ))}
        </div>

        <div className="mt-12 p-6 bg-primary/10 rounded-lg">
          <h2 className="text-xl font-semibold mb-2">¿No encontraste lo que buscas?</h2>
          <p className="text-muted-foreground mb-4">Contáctanos directamente por WhatsApp o correo electrónico</p>
          <Link href="/contacto">
            <Button>Contactar Soporte</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
