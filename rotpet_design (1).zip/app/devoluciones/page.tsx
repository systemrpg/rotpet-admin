import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Devoluciones() {
  return (
    <div className="min-h-screen bg-background py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <Link href="/" className="text-primary hover:underline mb-4 inline-block">
          ← Volver al inicio
        </Link>

        <h1 className="text-4xl font-bold mb-2">Devoluciones y Reembolsos</h1>
        <p className="text-lg text-muted-foreground mb-8">Políticas de devolución y satisfacción garantizada</p>

        <div className="space-y-6 prose prose-sm max-w-none">
          <section>
            <h2 className="text-2xl font-semibold">Política de Devoluciones</h2>
            <p className="text-muted-foreground">
              En ROT PET SHOP, queremos que estés 100% satisfecho con tu compra. Si no lo estás, aceptamos devoluciones
              bajo las siguientes condiciones:
            </p>
          </section>

          <section>
            <h3 className="text-xl font-semibold">Condiciones para Devoluciones</h3>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>El producto debe devolverse dentro de 7 días de la compra</li>
              <li>El producto debe estar en perfecto estado y sin usar</li>
              <li>Debe incluir el empaque original y todos los accesorios</li>
              <li>Se reembolsará el 100% del monto pagado</li>
            </ul>
          </section>

          <section>
            <h3 className="text-xl font-semibold">Cómo Solicitar una Devolución</h3>
            <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
              <li>Contacta al equipo de soporte indicando el número de orden</li>
              <li>Recibirás instrucciones para enviar el producto de vuelta</li>
              <li>Una vez recibido y verificado, procesaremos tu reembolso</li>
              <li>El reembolso se realizará en 3-5 días hábiles</li>
            </ol>
          </section>

          <section>
            <h3 className="text-xl font-semibold">Excepciones</h3>
            <p className="text-muted-foreground">
              Los productos personalizados, alimentos abiertos o comida de mascotas no pueden ser devueltos por razones
              de higiene y seguridad.
            </p>
          </section>
        </div>

        <div className="mt-12 p-6 bg-primary/10 rounded-lg">
          <h2 className="text-xl font-semibold mb-2">¿Necesitas Ayuda?</h2>
          <Link href="/contacto">
            <Button>Contactar Soporte</Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
