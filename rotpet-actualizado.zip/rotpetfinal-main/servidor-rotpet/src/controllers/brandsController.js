const supabase = require('../config/supabase');

const getBrands = async (req, res) => {
    const { data, error } = await supabase
        .from('brands')
        .select('*')
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Error fetching brands:', error);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const getBrandById = async (req, res) => {
    const { id } = req.params;
    const { data, error } = await supabase
        .from('brands')
        .select('*')
        .eq('id', id)
        .single();

    if (error) {
        console.error('Error fetching brand:', error);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const createBrand = async (req, res) => {
    const { name, slug, logo_url, description } = req.body;
    const { data, error } = await supabase
        .from('brands')
        .insert([{ name, slug, logo_url, description }])
        .select();

    if (error) {
        console.error('Error creating brand:', error);
        if (error.code === '23505') { // Unique violation
            return res.status(400).json({ error: 'Brand name or slug already exists' });
        }
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json(data[0]);
};

const updateBrand = async (req, res) => {
    const { id } = req.params;
    const { name, slug, logo_url, description } = req.body;
    const { data, error } = await supabase
        .from('brands')
        .update({ name, slug, logo_url, description })
        .eq('id', id)
        .select();

    if (error) {
        console.error('Error updating brand:', error);
        if (error.code === '23505') {
            return res.status(400).json({ error: 'Brand name or slug already exists' });
        }
        return res.status(500).json({ error: error.message });
    }

    if (data.length === 0) {
        return res.status(404).json({ error: 'Brand not found' });
    }

    res.json(data[0]);
};

const deleteBrand = async (req, res) => {
    const { id } = req.params;
    const { error } = await supabase
        .from('brands')
        .delete()
        .eq('id', id);

    if (error) {
        console.error('Error deleting brand:', error);
        return res.status(500).json({ error: error.message });
    }

    res.json({ message: 'Brand deleted successfully' });
};

module.exports = {
    getBrands,
    getBrandById,
    createBrand,
    updateBrand,
    deleteBrand,
};
