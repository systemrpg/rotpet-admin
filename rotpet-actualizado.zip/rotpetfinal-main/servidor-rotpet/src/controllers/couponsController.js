const supabase = require('../config/supabase');

const getCoupons = async (req, res) => {
    const { data, error } = await supabase
        .from('coupons')
        .select('*')
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Error fetching coupons:', error);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const getCouponById = async (req, res) => {
    const { id } = req.params;
    const { data, error } = await supabase
        .from('coupons')
        .select('*')
        .eq('id', id)
        .single();

    if (error) {
        console.error('Error fetching coupon:', error);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const createCoupon = async (req, res) => {
    const { code, discount_type, discount_value, min_purchase, expiration_date, usage_limit, status } = req.body;

    // Force uppercase code
    const upperCode = code.toUpperCase();

    const { data, error } = await supabase
        .from('coupons')
        .insert([{
            code: upperCode,
            discount_type,
            discount_value,
            min_purchase,
            expiration_date,
            usage_limit,
            status
        }])
        .select();

    if (error) {
        console.error('Error creating coupon:', error);
        if (error.code === '23505') { // Unique violation
            return res.status(400).json({ error: 'El código del cupón ya existe' });
        }
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json(data[0]);
};

const updateCoupon = async (req, res) => {
    const { id } = req.params;
    const { code, discount_type, discount_value, min_purchase, expiration_date, usage_limit, status } = req.body;

    const upperCode = code.toUpperCase();

    const { data, error } = await supabase
        .from('coupons')
        .update({
            code: upperCode,
            discount_type,
            discount_value,
            min_purchase,
            expiration_date,
            usage_limit,
            status
        })
        .eq('id', id)
        .select();

    if (error) {
        console.error('Error updating coupon:', error);
        if (error.code === '23505') {
            return res.status(400).json({ error: 'El código del cupón ya existe' });
        }
        return res.status(500).json({ error: error.message });
    }

    if (data.length === 0) {
        return res.status(404).json({ error: 'Cupón no encontrado' });
    }

    res.json(data[0]);
};

const deleteCoupon = async (req, res) => {
    const { id } = req.params;
    const { error } = await supabase
        .from('coupons')
        .delete()
        .eq('id', id);

    if (error) {
        console.error('Error deleting coupon:', error);
        return res.status(500).json({ error: error.message });
    }

    res.json({ message: 'Cupón eliminado correctamente' });
};

const validateCoupon = async (req, res) => {
    const { code, cartTotal } = req.body;

    if (!code) {
        return res.status(400).json({ error: 'Código requerido' });
    }

    const upperCode = code.toUpperCase();

    const { data: coupon, error } = await supabase
        .from('coupons')
        .select('*')
        .eq('code', upperCode)
        .single();

    if (error || !coupon) {
        return res.status(404).json({ error: 'Cupón inválido' });
    }

    // Validations
    if (coupon.status !== 'active') {
        return res.status(400).json({ error: 'Este cupón está inactivo' });
    }

    if (coupon.expiration_date && new Date(coupon.expiration_date) < new Date()) {
        return res.status(400).json({ error: 'Este cupón ha expirado' });
    }

    if (coupon.usage_limit && coupon.used_count >= coupon.usage_limit) {
        return res.status(400).json({ error: 'Este cupón ha agotado sus usos' });
    }

    if (coupon.min_purchase && cartTotal < coupon.min_purchase) {
        return res.status(400).json({ error: `La compra mínima para este cupón es de $${coupon.min_purchase}` });
    }

    // Calculate discount
    let discountAmount = 0;
    if (coupon.discount_type === 'percentage') {
        discountAmount = (cartTotal * coupon.discount_value) / 100;
    } else {
        discountAmount = coupon.discount_value;
    }

    // Ensure discount doesn't exceed total
    if (discountAmount > cartTotal) {
        discountAmount = cartTotal;
    }

    res.json({
        valid: true,
        coupon_code: coupon.code,
        discount_type: coupon.discount_type,
        discount_value: coupon.discount_value,
        discount_amount: discountAmount,
        final_total: cartTotal - discountAmount
    });
};

module.exports = {
    getCoupons,
    getCouponById,
    createCoupon,
    updateCoupon,
    deleteCoupon,
    validateCoupon
};
