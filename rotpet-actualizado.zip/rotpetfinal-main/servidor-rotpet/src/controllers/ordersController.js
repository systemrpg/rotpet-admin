const supabase = require('../config/supabase');

const getOrders = async (req, res) => {
    const { data, error } = await supabase
        .from('orders')
        .select('*, users(full_name, email), order_items(product_id, quantity, unit_price, products(name))');

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const createOrder = async (req, res) => {
    const { user_id, total_amount, items } = req.body;

    // Start a transaction-like flow (Supabase doesn't support transactions in JS client directly easily without RPC, 
    // but we will do best effort or assume RPC usage in production. For now, sequential inserts).

    const { data: order, error: orderError } = await supabase
        .from('orders')
        .insert([{ user_id, total_amount }])
        .select()
        .single();

    if (orderError) {
        return res.status(500).json({ error: orderError.message });
    }

    const orderItems = items.map(item => ({
        order_id: order.id,
        product_id: item.product_id,
        quantity: item.quantity,
        unit_price: item.unit_price
    }));

    const { error: itemsError } = await supabase
        .from('order_items')
        .insert(orderItems);

    if (itemsError) {
        // In a real app, we should rollback the order here
        return res.status(500).json({ error: itemsError.message });
    }

    res.status(201).json(order);
};

const getOrderById = async (req, res) => {
    const { id } = req.params;
    const { data, error } = await supabase
        .from('orders')
        .select('*, users(full_name, email), order_items(product_id, quantity, unit_price, products(name))')
        .eq('id', id)
        .single();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const updateOrder = async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const { data, error } = await supabase
        .from('orders')
        .update({ status, updated_at: new Date() })
        .eq('id', id)
        .select();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data[0]);
};

module.exports = {
    getOrders,
    createOrder,
    getOrderById,
    updateOrder
};
