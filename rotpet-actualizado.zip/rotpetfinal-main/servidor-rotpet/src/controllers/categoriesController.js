const supabase = require('../config/supabase');

const getCategories = async (req, res) => {
    const { data, error } = await supabase
        .from('categories')
        .select('*, products(count)');

    if (error) {
        console.error('Error in getCategories:', error);
        return res.status(500).json({ error: error.message });
    }

    // Transform data to include product_count as a number
    const categories = data.map(cat => ({
        ...cat,
        product_count: cat.products ? cat.products[0]?.count || 0 : 0
    }));

    res.json(categories);
};

const createCategory = async (req, res) => {
    const { name, slug, image_url, status } = req.body;
    const { data, error } = await supabase
        .from('categories')
        .insert([{ name, slug, image_url, status }])
        .select();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json(data[0]);
};

const getCategoryById = async (req, res) => {
    const { id } = req.params;
    const { data, error } = await supabase
        .from('categories')
        .select('*')
        .eq('id', id)
        .single();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const updateCategory = async (req, res) => {
    const { id } = req.params;
    const { name, slug, image_url, status } = req.body;
    const { data, error } = await supabase
        .from('categories')
        .update({ name, slug, image_url, status })
        .eq('id', id)
        .select();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data[0]);
};

const deleteCategory = async (req, res) => {
    const { id } = req.params;
    const { error } = await supabase
        .from('categories')
        .delete()
        .eq('id', id);

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.status(204).send();
};

module.exports = {
    getCategories,
    createCategory,
    getCategoryById,
    updateCategory,
    deleteCategory
};
