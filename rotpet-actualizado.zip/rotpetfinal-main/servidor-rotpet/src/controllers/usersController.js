const supabase = require('../config/supabase');

const getUsers = async (req, res) => {
    const { data, error } = await supabase
        .from('users')
        .select('*, roles(name)')
        .neq('status', 'inactive');

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const createUser = async (req, res) => {
    const { email, full_name, role_id, status } = req.body;
    const { data, error } = await supabase
        .from('users')
        .insert([{ email, full_name, role_id, status }])
        .select();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json(data[0]);
};

const getUserById = async (req, res) => {
    const { id } = req.params;
    const { data, error } = await supabase
        .from('users')
        .select('*, roles(name)')
        .eq('id', id)
        .single();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const updateUser = async (req, res) => {
    const { id } = req.params;
    const { email, full_name, role_id, status, balance, internal_notes } = req.body;

    const updateData = { email, full_name, role_id, status };
    if (balance !== undefined) updateData.balance = balance;
    if (internal_notes !== undefined) updateData.internal_notes = internal_notes;

    const { data, error } = await supabase
        .from('users')
        .update(updateData)
        .eq('id', id)
        .select();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data[0]);
};

const deleteUser = async (req, res) => {
    const { id } = req.params;
    const { error } = await supabase
        .from('users')
        .update({ status: 'inactive' })
        .eq('id', id);

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.status(204).send();
};

module.exports = {
    getUsers,
    createUser,
    getUserById,
    updateUser,
    deleteUser
};
