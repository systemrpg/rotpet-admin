const supabase = require('../config/supabase');

const getCountries = async (req, res) => {
    const { data, error } = await supabase
        .from('countries')
        .select('*');

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const getStates = async (req, res) => {
    const { country_id } = req.query;
    let query = supabase.from('states').select('*');

    if (country_id) {
        query = query.eq('country_id', country_id);
    }

    const { data, error } = await query;

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

module.exports = {
    getCountries,
    getStates
};
