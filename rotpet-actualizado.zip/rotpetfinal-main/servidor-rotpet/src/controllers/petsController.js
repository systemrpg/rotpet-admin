const supabase = require('../config/supabase');

const getPetsByUserId = async (req, res) => {
    const { userId } = req.params;
    const { data, error } = await supabase
        .from('pets')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Error fetching pets:', error);
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const createPet = async (req, res) => {
    const { user_id, name, type, breed, birth_date, gender, weight, allergies } = req.body;

    const { data, error } = await supabase
        .from('pets')
        .insert([{
            user_id,
            name,
            type,
            breed,
            birth_date,
            gender,
            weight,
            allergies
        }])
        .select();

    if (error) {
        console.error('Error creating pet:', error);
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json(data[0]);
};

const updatePet = async (req, res) => {
    const { id } = req.params;
    const { name, type, breed, birth_date, gender, weight, allergies } = req.body;

    const { data, error } = await supabase
        .from('pets')
        .update({
            name,
            type,
            breed,
            birth_date,
            gender,
            weight,
            allergies
        })
        .eq('id', id)
        .select();

    if (error) {
        console.error('Error updating pet:', error);
        return res.status(500).json({ error: error.message });
    }

    if (data.length === 0) {
        return res.status(404).json({ error: 'Mascota no encontrada' });
    }

    res.json(data[0]);
};

const deletePet = async (req, res) => {
    const { id } = req.params;
    const { error } = await supabase
        .from('pets')
        .delete()
        .eq('id', id);

    if (error) {
        console.error('Error deleting pet:', error);
        return res.status(500).json({ error: error.message });
    }

    res.json({ message: 'Mascota eliminada correctamente' });
};

module.exports = {
    getPetsByUserId,
    createPet,
    updatePet,
    deletePet
};
