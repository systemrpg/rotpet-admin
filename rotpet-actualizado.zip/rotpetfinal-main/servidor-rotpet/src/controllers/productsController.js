const supabase = require('../config/supabase');

const getProducts = async (req, res) => {
    try {
        // Fetch products
        const { data: products, error: productsError } = await supabase
            .from('products')
            .select(`
                *,
                category:categories(name)
            `)
            .order('created_at', { ascending: false });

        if (productsError) throw productsError;

        let productsWithVariants = products;

        try {
            // Fetch variant counts manually
            const { data: variants, error: variantsError } = await supabase
                .from('product_variants')
                .select('product_id');

            if (!variantsError && variants) {
                // Map variants to products
                productsWithVariants = products.map(product => {
                    const productVariants = variants.filter(v => v.product_id === product.id);
                    return {
                        ...product,
                        variants: [{ count: productVariants.length }]
                    };
                });
            }
        } catch (variantError) {
            console.warn("Could not fetch variants (likely schema cache issue), returning products without variant counts:", variantError.message);
            // Continue with products as is, just without variant counts
        }

        res.json(productsWithVariants);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const createProduct = async (req, res) => {
    const { name, sku, price, quantity, category_id, image_url, description, status, variants } = req.body;

    try {
        // Start a "transaction" by creating product first
        const { data: product, error: productError } = await supabase
            .from('products')
            .insert([{ name, sku, price, quantity, category_id, image_url, description, status }])
            .select()
            .single();

        if (productError) throw productError;

        // If there are variants, insert them
        if (variants && variants.length > 0) {
            const variantsToInsert = variants.map(v => ({
                product_id: product.id,
                sku: v.sku,
                price: v.price || null,
                stock: v.stock || 0,
                attributes: v.attributes,
                status: v.status || 'active'
            }));

            const { error: variantsError } = await supabase
                .from('product_variants')
                .insert(variantsToInsert);

            if (variantsError) {
                console.error("Error creating variants:", variantsError);
            }
        }

        res.status(201).json(product);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const getProductById = async (req, res) => {
    const { id } = req.params;
    try {
        const { data: product, error: productError } = await supabase
            .from('products')
            .select(`
                *,
                category:categories(id, name)
            `)
            .eq('id', id)
            .single();

        if (productError) throw productError;
        if (!product) return res.status(404).json({ error: 'Product not found' });

        // Fetch variants manually
        const { data: variants, error: variantsError } = await supabase
            .from('product_variants')
            .select('*')
            .eq('product_id', id);

        if (variantsError) throw variantsError;

        const productWithVariants = {
            ...product,
            variants: variants || []
        };

        res.json(productWithVariants);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const updateProduct = async (req, res) => {
    const { id } = req.params;
    const { name, sku, price, quantity, category_id, image_url, description, status, variants } = req.body;

    try {
        // Update product base info
        const { data: product, error: productError } = await supabase
            .from('products')
            .update({ name, sku, price, quantity, category_id, image_url, description, status })
            .eq('id', id)
            .select()
            .single();

        if (productError) throw productError;

        // Handle variants update
        if (variants) {
            // Delete existing
            await supabase.from('product_variants').delete().eq('product_id', id);

            if (variants.length > 0) {
                const variantsToInsert = variants.map(v => ({
                    product_id: id,
                    sku: v.sku,
                    price: v.price || null,
                    stock: v.stock || 0,
                    attributes: v.attributes,
                    status: v.status || 'active'
                }));

                const { error: variantsError } = await supabase
                    .from('product_variants')
                    .insert(variantsToInsert);

                if (variantsError) throw variantsError;
            }
        }

        res.json(product);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

const deleteProduct = async (req, res) => {
    const { id } = req.params;
    const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.status(204).send();
};

module.exports = {
    getProducts,
    createProduct,
    getProductById,
    updateProduct,
    deleteProduct
};
