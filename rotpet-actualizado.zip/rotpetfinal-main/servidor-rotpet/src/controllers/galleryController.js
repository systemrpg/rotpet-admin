const fs = require('fs');
const path = require('path');
const multer = require('multer');

// Configure Multer storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const folder = req.query.folder === 'products' ? 'products' : 'gallery';
        const uploadPath = path.join(__dirname, `../../public/uploads/${folder}`);
        // Ensure directory exists
        if (!fs.existsSync(uploadPath)) {
            fs.mkdirSync(uploadPath, { recursive: true });
        }
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        // Sanitize filename
        const sanitizedName = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, uniqueSuffix + '-' + sanitizedName);
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        } else {
            cb(new Error('Only images are allowed'));
        }
    }
}).single('file'); // Expect field name 'file'

const uploadImage = (req, res) => {
    upload(req, res, (err) => {
        if (err) {
            return res.status(400).json({ error: err.message });
        }
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        const folder = req.query.folder === 'products' ? 'products' : 'gallery';
        const protocol = req.protocol;
        const host = req.get('host');
        const publicUrl = `${protocol}://${host}/uploads/${folder}/${req.file.filename}`;

        res.status(201).json({
            name: req.file.filename,
            url: publicUrl,
            created_at: new Date().toISOString()
        });
    });
};

const getImages = (req, res) => {
    // Only list gallery images by default, or specific folder if requested (but mainly gallery)
    const folder = 'gallery';
    const uploadPath = path.join(__dirname, `../../public/uploads/${folder}`);

    if (!fs.existsSync(uploadPath)) {
        return res.json([]);
    }

    fs.readdir(uploadPath, (err, files) => {
        if (err) {
            return res.status(500).json({ error: 'Unable to scan directory' });
        }

        const protocol = req.protocol;
        const host = req.get('host');

        const images = files.map(file => {
            const filePath = path.join(uploadPath, file);
            const stats = fs.statSync(filePath);
            return {
                name: file,
                url: `${protocol}://${host}/uploads/${folder}/${file}`,
                created_at: stats.birthtime.toISOString()
            };
        });

        // Sort by newest first
        images.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

        res.json(images);
    });
};

const deleteImage = (req, res) => {
    const { filename } = req.params;
    // Default to gallery for deletion via this endpoint
    const folder = 'gallery';
    const filePath = path.join(__dirname, `../../public/uploads/${folder}`, filename);

    if (fs.existsSync(filePath)) {
        fs.unlink(filePath, (err) => {
            if (err) {
                return res.status(500).json({ error: 'Error deleting file' });
            }
            res.status(204).send();
        });
    } else {
        res.status(404).json({ error: 'File not found' });
    }
};

module.exports = {
    uploadImage,
    getImages,
    deleteImage
};
