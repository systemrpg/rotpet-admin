const supabase = require('../config/supabase');

const getRoles = async (req, res) => {
    const { data, error } = await supabase
        .from('roles')
        .select('*');

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const getRoleById = async (req, res) => {
    const { id } = req.params;
    const { data, error } = await supabase
        .from('roles')
        .select('*')
        .eq('id', id)
        .single();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data);
};

const createRole = async (req, res) => {
    const { name, permissions } = req.body;
    const { data, error } = await supabase
        .from('roles')
        .insert([{ name, permissions }])
        .select();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.status(201).json(data[0]);
};

const updateRole = async (req, res) => {
    const { id } = req.params;
    const { name, permissions } = req.body;
    const { data, error } = await supabase
        .from('roles')
        .update({ name, permissions })
        .eq('id', id)
        .select();

    if (error) {
        return res.status(500).json({ error: error.message });
    }

    res.json(data[0]);
};

const deleteRole = async (req, res) => {
    const { id } = req.params;
    const { error } = await supabase
        .from('roles')
        .delete()
        .eq('id', id);

    if (error) {
        // Check for foreign key violation (Postgres code 23503)
        if (error.code === '23503') {
            return res.status(409).json({ error: "No se puede eliminar el rol porque hay usuarios asignados a él." });
        }
        return res.status(500).json({ error: error.message });
    }

    res.status(204).send();
};

module.exports = {
    getRoles,
    getRoleById,
    createRole,
    updateRole,
    deleteRole
};
