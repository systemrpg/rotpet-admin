const express = require('express');
const router = express.Router();
const rolesController = require('../controllers/rolesController');
const usersController = require('../controllers/usersController');
const categoriesController = require('../controllers/categoriesController');
const productsController = require('../controllers/productsController');
const ordersController = require('../controllers/ordersController');
const locationsController = require('../controllers/locationsController');

// Roles
router.get('/roles', rolesController.getRoles);
router.get('/roles/:id', rolesController.getRoleById);
router.post('/roles', rolesController.createRole);
router.put('/roles/:id', rolesController.updateRole);
router.delete('/roles/:id', rolesController.deleteRole);

// Users
router.get('/users', usersController.getUsers);
router.post('/users', usersController.createUser);
router.get('/users/:id', usersController.getUserById);
router.put('/users/:id', usersController.updateUser);
router.delete('/users/:id', usersController.deleteUser);

// Categories
router.get('/categories', categoriesController.getCategories);
router.post('/categories', categoriesController.createCategory);
router.get('/categories/:id', categoriesController.getCategoryById);
router.put('/categories/:id', categoriesController.updateCategory);
router.delete('/categories/:id', categoriesController.deleteCategory);

// Products
router.get('/products', productsController.getProducts);
router.post('/products', productsController.createProduct);
router.get('/products/:id', productsController.getProductById);
router.put('/products/:id', productsController.updateProduct);
router.delete('/products/:id', productsController.deleteProduct);

// Orders
router.get('/orders', ordersController.getOrders);
router.post('/orders', ordersController.createOrder);
router.get('/orders/:id', ordersController.getOrderById);
router.put('/orders/:id', ordersController.updateOrder);

// Locations
router.get('/countries', locationsController.getCountries);
router.get('/states', locationsController.getStates);

const galleryController = require('../controllers/galleryController');
const brandsController = require('../controllers/brandsController');
const couponsController = require('../controllers/couponsController');
const petsController = require('../controllers/petsController');


// ... existing routes ...

// GALLERY ROUTES
router.get('/gallery', galleryController.getImages);
router.post('/gallery', galleryController.uploadImage);
router.delete('/gallery/:filename', galleryController.deleteImage);

// Brands routes
router.get('/brands', brandsController.getBrands);
router.get('/brands/:id', brandsController.getBrandById);
router.post('/brands', brandsController.createBrand);
router.put('/brands/:id', brandsController.updateBrand);
router.delete('/brands/:id', brandsController.deleteBrand);

// Coupons routes
router.get('/coupons', couponsController.getCoupons);
router.get('/coupons/:id', couponsController.getCouponById);
router.post('/coupons', couponsController.createCoupon);
router.put('/coupons/:id', couponsController.updateCoupon);
router.delete('/coupons/:id', couponsController.deleteCoupon);
router.post('/coupons/validate', couponsController.validateCoupon);

// Pets routes
router.get('/users/:userId/pets', petsController.getPetsByUserId);
router.post('/pets', petsController.createPet);
router.put('/pets/:id', petsController.updatePet);
router.delete('/pets/:id', petsController.deletePet);



module.exports = router;
