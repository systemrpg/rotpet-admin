const fs = require('fs');
const path = require('path');

async function testUpload() {
    const formData = new FormData();
    const filePath = path.join(__dirname, 'test-image.png');

    // Create a dummy image file if it doesn't exist
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, 'fake image content');
    }

    const fileBlob = new Blob([fs.readFileSync(filePath)], { type: 'image/png' });
    formData.append('file', fileBlob, 'test-image.png');

    try {
        console.log('Attempting upload to http://localhost:3001/api/gallery...');
        const response = await fetch('http://localhost:3001/api/gallery', {
            method: 'POST',
            body: formData
        });

        console.log('Status:', response.status);
        const text = await response.text();
        console.log('Response:', text);

        if (!response.ok) {
            console.error('Upload failed!');
        } else {
            console.log('Upload successful!');
        }
    } catch (error) {
        console.error('Network error:', error);
    }
}

testUpload();
