-- ============================================
-- ROTPET - SCRIPT COMPLETO DE CONFIGURACIÓN
-- ============================================
-- Ejecuta este script en Supabase SQL Editor:
-- https://supabase.com/dashboard/project/tltirpvrthluiewrkjys/sql/new
-- ============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- TABLAS PRINCIPALES
-- ============================================

-- ROLES
CREATE TABLE IF NOT EXISTS public.roles (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  permissions JSONB DEFAULT '[]'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- USERS
CREATE TABLE IF NOT EXISTS public.users (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT,
  role_id UUID REFERENCES public.roles(id),
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  balance DECIMAL(10,2) DEFAULT 0.00,
  internal_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- CATEGORIES
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  image_url TEXT,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- BRANDS
CREATE TABLE IF NOT EXISTS public.brands (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  logo_url TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- PRODUCTS
CREATE TABLE IF NOT EXISTS public.products (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  sku TEXT NOT NULL UNIQUE,
  price DECIMAL(10,2) NOT NULL,
  quantity INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  category_id UUID REFERENCES public.categories(id),
  brand_id UUID REFERENCES public.brands(id),
  image_url TEXT,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- PRODUCT VARIANTS
CREATE TABLE IF NOT EXISTS public.product_variants (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  sku TEXT NOT NULL UNIQUE,
  price DECIMAL(10,2) NOT NULL,
  quantity INTEGER DEFAULT 0,
  attributes JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- COUNTRIES
CREATE TABLE IF NOT EXISTS public.countries (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  name TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE
);

-- STATES
CREATE TABLE IF NOT EXISTS public.states (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  country_id UUID REFERENCES public.countries(id),
  name TEXT NOT NULL
);

-- ORDERS
CREATE TABLE IF NOT EXISTS public.orders (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES public.users(id),
  total_amount DECIMAL(10,2) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'cancelled')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- ORDER ITEMS
CREATE TABLE IF NOT EXISTS public.order_items (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  order_id UUID REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES public.products(id),
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL
);

-- COUPONS
CREATE TABLE IF NOT EXISTS public.coupons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code TEXT UNIQUE NOT NULL,
  discount_type TEXT NOT NULL CHECK (discount_type IN ('percentage', 'fixed')),
  discount_value DECIMAL(10,2) NOT NULL,
  min_purchase DECIMAL(10,2),
  expiration_date TIMESTAMP WITH TIME ZONE,
  usage_limit INTEGER,
  used_count INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- PETS
CREATE TABLE IF NOT EXISTS public.pets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('dog', 'cat', 'other')),
  breed TEXT,
  birth_date DATE,
  gender TEXT CHECK (gender IN ('male', 'female')),
  weight DECIMAL(5,2),
  allergies TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- ============================================
-- HABILITAR ROW LEVEL SECURITY
-- ============================================

ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_variants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.countries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.states ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pets ENABLE ROW LEVEL SECURITY;

-- ============================================
-- POLÍTICAS DE ACCESO (Acceso público simplificado para backoffice)
-- ============================================

CREATE POLICY "Allow public access to roles" ON public.roles FOR ALL USING (true);
CREATE POLICY "Allow public access to users" ON public.users FOR ALL USING (true);
CREATE POLICY "Allow public access to categories" ON public.categories FOR ALL USING (true);
CREATE POLICY "Allow public access to brands" ON public.brands FOR ALL USING (true);
CREATE POLICY "Allow public access to products" ON public.products FOR ALL USING (true);
CREATE POLICY "Allow public access to product_variants" ON public.product_variants FOR ALL USING (true);
CREATE POLICY "Allow public access to countries" ON public.countries FOR ALL USING (true);
CREATE POLICY "Allow public access to states" ON public.states FOR ALL USING (true);
CREATE POLICY "Allow public access to orders" ON public.orders FOR ALL USING (true);
CREATE POLICY "Allow public access to order_items" ON public.order_items FOR ALL USING (true);
CREATE POLICY "Allow public access to coupons" ON public.coupons FOR ALL USING (true);
CREATE POLICY "Allow public access to pets" ON public.pets FOR ALL USING (true);

-- ============================================
-- DATOS DE PRUEBA
-- ============================================

-- Roles
INSERT INTO public.roles (name, permissions) VALUES 
('admin', '["all"]'::jsonb), 
('staff', '["read_products", "write_products", "read_orders"]'::jsonb), 
('user', '["read_products", "create_orders"]'::jsonb)
ON CONFLICT (name) DO NOTHING;

-- Categorías
INSERT INTO public.categories (name, slug, status) VALUES 
('Alimentos Secos', 'alimentos-secos', 'active'),
('Alimentos Húmedos', 'alimentos-humedos', 'active'),
('Juguetes', 'juguetes', 'active'),
('Accesorios', 'accesorios', 'active'),
('Higiene', 'higiene', 'active')
ON CONFLICT (slug) DO NOTHING;

-- Marcas
INSERT INTO public.brands (name, slug, description) VALUES 
('Royal Canin', 'royal-canin', 'Nutrición especializada para mascotas'),
('Pedigree', 'pedigree', 'Alimento de calidad para perros'),
('Whiskas', 'whiskas', 'Nutrición completa para gatos'),
('Kong', 'kong', 'Juguetes resistentes para mascotas')
ON CONFLICT (slug) DO NOTHING;

-- Países
INSERT INTO public.countries (name, code) VALUES 
('México', 'MX'),
('Estados Unidos', 'US'),
('Colombia', 'CO'),
('Argentina', 'AR')
ON CONFLICT (code) DO NOTHING;

-- Estados de México
INSERT INTO public.states (country_id, name) 
SELECT id, state FROM public.countries, 
(VALUES 
  ('Ciudad de México'),
  ('Jalisco'),
  ('Nuevo León'),
  ('Puebla'),
  ('Guanajuato')
) AS states(state)
WHERE code = 'MX'
ON CONFLICT DO NOTHING;

-- ============================================
-- FIN DEL SCRIPT
-- ============================================
