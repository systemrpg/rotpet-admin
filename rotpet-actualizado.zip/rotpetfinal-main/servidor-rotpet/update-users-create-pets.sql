-- Actualizar tabla users
ALTER TABLE public.users 
ADD COLUMN IF NOT EXISTS balance DECIMAL(10,2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS internal_notes TEXT;

-- Crear tabla pets
CREATE TABLE IF NOT EXISTS public.pets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('dog', 'cat', 'other')),
    breed TEXT,
    birth_date DATE,
    gender TEXT CHECK (gender IN ('male', 'female')),
    weight DECIMAL(5,2),
    allergies TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Habilitar RLS para pets
ALTER TABLE public.pets ENABLE ROW LEVEL SECURITY;

-- Crear política de acceso público (para este backoffice simplificado)
CREATE POLICY "Allow public access to pets" ON public.pets
FOR ALL USING (true);
