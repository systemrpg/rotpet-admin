const { Client } = require('pg');

async function testPostgresConnection() {
    // Intentar con la primera contraseña
    const client1 = new Client({
        connectionString: 'postgresql://postgres:x9ke#jamoV@db.tltirpvrthluiewrkjys.supabase.co:5432/postgres',
        ssl: { rejectUnauthorized: false }
    });

    try {
        console.log('Probando conexión con contraseña 1 (x9ke#jamoV)...');
        await client1.connect();
        const res = await client1.query('SELECT version()');
        console.log('✅ Conexión exitosa!');
        console.log('PostgreSQL version:', res.rows[0].version);
        await client1.end();
        return true;
    } catch (err) {
        console.log('❌ Falló con contraseña 1:', err.message);

        // Intentar con la segunda contraseña
        const client2 = new Client({
            connectionString: 'postgresql://postgres:x9ke#jamoB@db.tltirpvrthluiewrkjys.supabase.co:5432/postgres',
            ssl: { rejectUnauthorized: false }
        });

        try {
            console.log('\nProbando conexión con contraseña 2 (x9ke#jamoB)...');
            await client2.connect();
            const res = await client2.query('SELECT version()');
            console.log('✅ Conexión exitosa!');
            console.log('PostgreSQL version:', res.rows[0].version);
            await client2.end();
            return true;
        } catch (err2) {
            console.log('❌ Falló con contraseña 2:', err2.message);
            return false;
        }
    }
}

testPostgresConnection();
