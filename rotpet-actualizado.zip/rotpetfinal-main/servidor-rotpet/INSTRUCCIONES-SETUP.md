# 🚀 CONFIGURACIÓN COMPLETA DEL BACKEND ROTPET

## 📋 Pasos para configurar la base de datos

### 1. Abrir Supabase SQL Editor

Abre este enlace en tu navegador:
```
https://supabase.com/dashboard/project/tltirpvrthluiewrkjys/sql/new
```

### 2. Copiar y ejecutar el SQL

1. Abre el archivo `SETUP-COMPLETE.sql` en este directorio
2. Copia TODO el contenido (Ctrl+A, Ctrl+C)
3. Pégalo en el SQL Editor de Supabase
4. Haz clic en **"Run"** o presiona `Ctrl+Enter`

### 3. Verificar que se crearon las tablas

Después de ejecutar el script, ve a **Table Editor** en Supabase:
```
https://supabase.com/dashboard/project/tltirpvrthluiewrkjys/editor
```

Deberías ver estas tablas:
- ✅ roles
- ✅ users
- ✅ categories
- ✅ brands
- ✅ products
- ✅ product_variants
- ✅ countries
- ✅ states
- ✅ orders
- ✅ order_items
- ✅ coupons
- ✅ pets

### 4. Configurar Storage para imágenes

1. Ve a **Storage** en Supabase:
   ```
   https://supabase.com/dashboard/project/tltirpvrthluiewrkjys/storage/buckets
   ```

2. Crea un nuevo bucket llamado `rotpet-images`

3. Configura el bucket como **público**

4. En las políticas (Policies), agrega:
   - **INSERT**: Allow public uploads
   - **SELECT**: Allow public reads
   - **DELETE**: Allow public deletes

## 🧪 Verificar que todo funciona

Ejecuta este comando en la terminal:

```bash
cd /workspaces/rotpet/rotpetfinal-main/servidor-rotpet
node -e "
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient('https://tltirpvrthluiewrkjys.supabase.co', 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsdGlycHZydGhsdWlld3JranlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIwMzEyNDksImV4cCI6MjA3NzYwNzI0OX0.O1d-R7oqkUsa8x06628GESa3z7rlQZt1X38_m2mI7OE');

async function test() {
  const { data, error } = await supabase.from('roles').select('*');
  if (error) {
    console.log('❌ Error:', error.message);
  } else {
    console.log('✅ Conexión exitosa!');
    console.log('Roles encontrados:', data.length);
    console.log(data);
  }
}

test();
"
```

Si ves "✅ Conexión exitosa!" y los 3 roles (admin, staff, user), ¡todo está funcionando!

## 🚀 Ejecutar el backend

```bash
npm run dev
```

El servidor estará en: http://localhost:3001

## 📡 Probar los endpoints

```bash
# Ver todos los roles
curl http://localhost:3001/api/roles

# Ver todas las categorías
curl http://localhost:3001/api/categories

# Ver todas las marcas
curl http://localhost:3001/api/brands

# Ver todos los productos
curl http://localhost:3001/api/products
```

## ⚙️ Configuración del Frontend

El frontend ya está configurado. Solo asegúrate de que esté corriendo:

```bash
cd /workspaces/rotpet/rotpetfinal-main
pnpm dev
```

Frontend: http://localhost:3000
Backend: http://localhost:3001

## 🔧 Solución de problemas

### Error: "relation does not exist"
- Ejecuta el script SQL completo en Supabase

### Error: "fetch failed"
- Verifica que el SUPABASE_URL y SUPABASE_KEY sean correctos en `.env`

### Error: Storage
- Crea el bucket `rotpet-images` en Supabase Storage
- Configúralo como público

