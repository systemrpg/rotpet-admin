// Using global fetch available in Node 18+ 
// Since node 18+ has fetch, we can try using global fetch.

async function testCreateProduct() {
    const productData = {
        name: "Test Product Variant " + Date.now(),
        sku: "TEST-VAR-" + Date.now(),
        price: 100,
        quantity: 10,
        category_id: null, // Assuming optional or we need a valid one. Let's try null first.
        image_url: "",
        description: "Test description",
        status: "active",
        variants: [
            {
                sku: "TEST-VAR-" + Date.now() + "-S",
                price: 100,
                stock: 5,
                attributes: { "Size": "S" },
                status: "active"
            },
            {
                sku: "TEST-VAR-" + Date.now() + "-M",
                price: 110,
                stock: 5,
                attributes: { "Size": "M" },
                status: "active"
            }
        ]
    };

    console.log("Sending payload:", JSON.stringify(productData, null, 2));

    try {
        const response = await fetch('http://localhost:3001/api/products', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(productData)
        });

        const text = await response.text();
        console.log("Response status:", response.status);
        console.log("Response body:", text);
    } catch (error) {
        console.error("Error:", error);
    }
}

testCreateProduct();
