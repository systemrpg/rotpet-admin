const supabase = require('./src/config/supabase');

async function testCategories() {
    console.log('--- Testing getCategories with count ---');
    const { data: listData, error: listError } = await supabase
        .from('categories')
        .select('*, products(count)');

    if (listError) {
        console.error('❌ getCategories failed:', listError.message);
    } else {
        console.log('✅ getCategories success. Count:', listData.length);
        if (listData.length > 0) {
            console.log('Sample category:', JSON.stringify(listData[0], null, 2));
        }
    }

    console.log('\n--- Testing createCategory ---');
    const newCategory = {
        name: `Test Category ${Date.now()}`,
        slug: `test-category-${Date.now()}`,
        status: 'active'
    };

    const { data: createData, error: createError } = await supabase
        .from('categories')
        .insert([newCategory])
        .select();

    if (createError) {
        console.error('❌ createCategory failed:', createError.message);
    } else {
        console.log('✅ createCategory success:', createData[0]);

        // Cleanup
        await supabase.from('categories').delete().eq('id', createData[0].id);
    }
}

testCategories();
