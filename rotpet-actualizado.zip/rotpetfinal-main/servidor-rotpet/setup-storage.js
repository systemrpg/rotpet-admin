const { createClient } = require('@supabase/supabase-js');
const dotenv = require('dotenv');
const path = require('path');

// Load env from parent directory
dotenv.config({ path: path.join(__dirname, '.env') });

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY; // Should be service_role key for admin tasks, but trying with available key

if (!supabaseUrl || !supabaseKey) {
    console.error('Missing Supabase URL or Key');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function setupStorage() {
    console.log('Checking storage buckets...');

    try {
        const { data: buckets, error } = await supabase.storage.listBuckets();

        if (error) {
            console.error('Error listing buckets:', error.message);
            return;
        }

        const galleryBucket = buckets.find(b => b.name === 'gallery');

        if (galleryBucket) {
            console.log('Bucket "gallery" already exists.');
        } else {
            console.log('Bucket "gallery" not found. Attempting to create...');
            const { data, error: createError } = await supabase.storage.createBucket('gallery', {
                public: true,
                fileSizeLimit: 5242880, // 5MB
                allowedMimeTypes: ['image/png', 'image/jpeg', 'image/gif', 'image/webp']
            });

            if (createError) {
                console.error('Error creating bucket:', createError.message);
                console.log('NOTE: If this fails, you may need to create the "gallery" public bucket manually in the Supabase dashboard.');
            } else {
                console.log('Bucket "gallery" created successfully.');
            }
        }
    } catch (err) {
        console.error('Unexpected error:', err);
    }
}

setupStorage();
