const http = require('http');

function testEndpoint(method, path, body = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3001,
            path: path,
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
        };

        const req = http.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            res.on('end', () => {
                console.log(`[${method} ${path}] Status: ${res.statusCode}`);
                if (data) {
                    try {
                        const json = JSON.parse(data);
                        console.log(`Response:`, JSON.stringify(json).substring(0, 100) + '...');
                        resolve(json);
                    } catch (e) {
                        console.log(`Response: ${data.substring(0, 100)}...`);
                        resolve(data);
                    }
                } else {
                    console.log('Response: (empty)');
                    resolve(null);
                }
            });
        });

        req.on('error', (e) => {
            console.error(`[${method} ${path}] Error: ${e.message}`);
            reject(e);
        });

        if (body) {
            req.write(JSON.stringify(body));
        }
        req.end();
    });
}

async function runTests() {
    console.log('Testing User CRUD...');

    try {
        // 1. Get Roles to pick one
        console.log('\n--- Fetching Roles ---');
        const roles = await testEndpoint('GET', '/api/roles');
        if (!roles || roles.length === 0) throw new Error('No roles found');
        const roleId = roles[0].id;
        console.log(`Using Role ID: ${roleId}`);

        // 2. Create User
        console.log('\n--- Creating User ---');
        const newUser = {
            full_name: `Test User ${Date.now()}`,
            email: `testuser${Date.now()}@example.com`,
            role_id: roleId,
            status: 'active'
        };
        const createdUser = await testEndpoint('POST', '/api/users', newUser);
        if (!createdUser || !createdUser.id) throw new Error('Failed to create user');
        const userId = createdUser.id;
        console.log(`Created User ID: ${userId}`);

        // 3. Get User
        console.log('\n--- Getting User ---');
        await testEndpoint('GET', `/api/users/${userId}`);

        // 4. Update User
        console.log('\n--- Updating User ---');
        const updateData = {
            full_name: `Updated User ${Date.now()}`,
            email: newUser.email,
            role_id: roleId,
            status: 'active'
        };
        await testEndpoint('PUT', `/api/users/${userId}`, updateData);

        // 5. Soft Delete User
        console.log('\n--- Soft Deleting User ---');
        await testEndpoint('DELETE', `/api/users/${userId}`);

        // 6. Verify Soft Delete (Get User again)
        console.log('\n--- Verifying Soft Delete ---');
        try {
            const deletedUser = await testEndpoint('GET', `/api/users/${userId}`);
            if (deletedUser && deletedUser.status === 'inactive') {
                console.log('SUCCESS: User status is inactive.');
            } else {
                console.error('FAILURE: User status is NOT inactive:', deletedUser ? deletedUser.status : 'null');
            }
        } catch (e) {
            console.log('GET by ID failed as expected (if 404/500), checking list...');
        }

        // 7. List all users to see if it exists (Should NOT exist now)
        console.log('\n--- Listing All Users ---');
        const allUsers = await testEndpoint('GET', '/api/users');
        const found = allUsers.find(u => u.id === userId);
        if (!found) {
            console.log('SUCCESS: User NOT found in list (correctly filtered).');
        } else {
            console.log('FAILURE: User FOUND in list (should be hidden). Status:', found.status);
        }

        // 8. Test Create Inactive User
        console.log('\n--- Creating Inactive User ---');
        const inactiveUser = {
            full_name: `Inactive User ${Date.now()}`,
            email: `inactive${Date.now()}@example.com`,
            role_id: roleId,
            status: 'inactive'
        };
        const createdInactive = await testEndpoint('POST', '/api/users', inactiveUser);
        if (createdInactive && createdInactive.id) {
            console.log(`Created Inactive User ID: ${createdInactive.id}`);
            // Try to get it
            const fetchedInactive = await testEndpoint('GET', `/api/users/${createdInactive.id}`);
            if (fetchedInactive && fetchedInactive.id) {
                console.log('SUCCESS: Inactive user is visible.');
            } else {
                console.error('FAILURE: Inactive user is NOT visible immediately after creation.');
            }
        } else {
            console.error('Failed to create inactive user');
        }

    } catch (err) {
        console.error('Test failed:', err);
    }
}

runTests();
