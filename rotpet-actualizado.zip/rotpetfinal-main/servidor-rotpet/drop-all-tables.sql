-- Script para eliminar todas las tablas del schema
-- Ejecutar en el SQL Editor de Supabase

-- Eliminar tablas en orden correcto (por dependencias)
DROP TABLE IF EXISTS public.order_items CASCADE;
DROP TABLE IF EXISTS public.orders CASCADE;
DROP TABLE IF EXISTS public.products CASCADE;
DROP TABLE IF EXISTS public.categories CASCADE;
DROP TABLE IF EXISTS public.states CASCADE;
DROP TABLE IF EXISTS public.countries CASCADE;
DROP TABLE IF EXISTS public.users CASCADE;
DROP TABLE IF EXISTS public.roles CASCADE;

-- Verificar que se eliminaron
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public';
