const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://tltirpvrthluiewrkjys.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsdGlycHZydGhsdWlld3JranlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIwMzEyNDksImV4cCI6MjA3NzYwNzI0OX0.O1d-R7oqkUsa8x06628GESa3z7rlQZt1X38_m2mI7OE';

const supabase = createClient(supabaseUrl, supabaseKey);

async function setupDatabase() {
    console.log('Configurando base de datos...\n');

    try {
        // Crear tabla roles
        console.log('Creando tabla roles...');
        const { error: rolesError } = await supabase.rpc('exec_sql', {
            sql: `
        CREATE TABLE IF NOT EXISTS public.roles (
          id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
          name text NOT NULL UNIQUE,
          permissions jsonb DEFAULT '[]'::jsonb,
          created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
        );
      `
        });

        if (rolesError) {
            console.log('Nota: No se puede usar RPC con anon key.');
            console.log('Por favor, ejecuta el schema.sql manualmente en el SQL Editor de Supabase:');
            console.log('https://supabase.com/dashboard/project/tltirpvrthluiewrkjys/editor\n');
            return;
        }

        console.log('Tablas creadas exitosamente!');

    } catch (err) {
        console.error('Error:', err.message);
    }
}

setupDatabase();
