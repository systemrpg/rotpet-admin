require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function verifyAccess() {
    console.log('--- STARTING ACCESS VERIFICATION ---');

    // Test 1: HEAD (Count)
    console.log('\nTest 1: HEAD Request (Count)');
    const { count, error: headError } = await supabase
        .from('product_variants')
        .select('*', { count: 'exact', head: true });

    if (headError) {
        console.error('FAILED:', headError.message);
    } else {
        console.log('SUCCESS. Count:', count);
    }

    // Test 2: SELECT * (Limit 1)
    console.log('\nTest 2: SELECT * (Limit 1)');
    const { data: selectData, error: selectError } = await supabase
        .from('product_variants')
        .select('*')
        .limit(1);

    if (selectError) {
        console.error('FAILED:', selectError.message);
    } else {
        console.log('SUCCESS. Data:', JSON.stringify(selectData));
    }

    // Test 3: SELECT specific columns
    console.log('\nTest 3: SELECT specific columns (id, sku)');
    const { data: colData, error: colError } = await supabase
        .from('product_variants')
        .select('id, sku')
        .limit(1);

    if (colError) {
        console.error('FAILED:', colError.message);
    } else {
        console.log('SUCCESS. Data:', JSON.stringify(colData));
    }

    console.log('\n--- VERIFICATION COMPLETE ---');
}

verifyAccess();
