-- Create product_variants table
create table if not exists public.product_variants (
  id uuid default uuid_generate_v4() primary key,
  product_id uuid references public.products(id) on delete cascade,
  sku text, -- Can be null if auto-generated or not used, but usually unique
  price decimal(10,2), -- Optional override of base product price
  stock integer default 0,
  attributes jsonb not null default '{}'::jsonb, -- e.g. {"Color": "Red", "Size": "M"}
  status text default 'active' check (status in ('active', 'inactive')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique(product_id, sku) -- Ensure unique SKU per product if provided
);

-- Enable RLS
alter table public.product_variants enable row level security;

-- Create policies for public access (simplified for backoffice)
create policy "Enable read access for all users" on public.product_variants for select using (true);
create policy "Enable insert access for all users" on public.product_variants for insert with check (true);
create policy "Enable update access for all users" on public.product_variants for update using (true);
create policy "Enable delete access for all users" on public.product_variants for delete using (true);
