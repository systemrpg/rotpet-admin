require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('Missing SUPABASE_URL or SUPABASE_KEY');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function inspectVariants() {
    console.log('Inspecting product_variants table...');
    const { data, error } = await supabase
        .from('product_variants')
        .select('*');

    if (error) {
        console.error('Error fetching variants:', error);
    } else {
        console.log(`Found ${data.length} variants.`);
        if (data.length > 0) {
            console.log('First 5 variants:', JSON.stringify(data.slice(0, 5), null, 2));
        }
    }
}

inspectVariants();
