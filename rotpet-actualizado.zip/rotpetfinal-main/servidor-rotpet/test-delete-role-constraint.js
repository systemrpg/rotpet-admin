const http = require('http');

function request(method, path, body = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3001,
            path: path,
            method: method,
            headers: { 'Content-Type': 'application/json' },
        };

        const req = http.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                try {
                    resolve({ status: res.statusCode, body: data ? JSON.parse(data) : null });
                } catch (e) {
                    resolve({ status: res.statusCode, body: data });
                }
            });
        });

        req.on('error', reject);
        if (body) req.write(JSON.stringify(body));
        req.end();
    });
}

async function run() {
    try {
        console.log('--- Reproducing Role Deletion Error ---');

        // 1. Create Role
        const roleRes = await request('POST', '/api/roles', { name: `RoleToDelete ${Date.now()}`, permissions: [] });
        const roleId = roleRes.body.id;
        console.log('Created Role:', roleId);

        // 2. Create User with this Role
        const userRes = await request('POST', '/api/users', {
            email: `user${Date.now()}@test.com`,
            full_name: 'Test User',
            role_id: roleId,
            status: 'active'
        });
        const userId = userRes.body.id;
        console.log('Created User linked to Role:', userId);

        // 3. Try to Delete Role
        console.log('Attempting to delete role...');
        const deleteRes = await request('DELETE', `/api/roles/${roleId}`);
        console.log('Delete Response Status:', deleteRes.status);
        console.log('Delete Response Body:', deleteRes.body);

        // Cleanup (Delete user then role to keep DB clean)
        if (userId) await request('DELETE', `/api/users/${userId}`);
        if (roleId) await request('DELETE', `/api/roles/${roleId}`);

    } catch (err) {
        console.error('Error:', err);
    }
}

run();
