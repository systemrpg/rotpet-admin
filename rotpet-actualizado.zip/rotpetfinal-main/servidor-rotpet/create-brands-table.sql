-- Crear tabla de Marcas
CREATE TABLE IF NOT EXISTS public.brands (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT UNIQUE NOT NULL,
    slug TEXT UNIQUE NOT NULL,
    logo_url TEXT,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Habilitar RLS (Opcional, pero recomendado si usas Supabase Auth en el futuro)
ALTER TABLE public.brands ENABLE ROW LEVEL SECURITY;

-- Crear política de acceso público (para este backoffice simplificado)
CREATE POLICY "Allow public access to brands" ON public.brands
FOR ALL USING (true);
