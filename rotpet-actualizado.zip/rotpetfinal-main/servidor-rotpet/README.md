# Servidor Rot Pet - Backend API

Backend Node.js + Express + Supabase para el backoffice de Rot Pet.

## 🚀 Configuración Rápida

### 1. Crear las tablas en Supabase

1. Ve a: https://supabase.com/dashboard/project/tltirpvrthluiewrkjys/editor
2. Haz clic en **SQL Editor** (icono de terminal en el menú lateral)
3. Copia TODO el contenido del archivo `schema.sql`
4. Pégalo en el editor y haz clic en **Run** (o presiona Cmd+Enter)

Esto creará todas las tablas: `roles`, `users`, `products`, `categories`, `orders`, `order_items`, `countries`, `states`.

### 2. Verificar que las tablas se crearon

Después de ejecutar el SQL, ve a **Table Editor** y deberías ver todas las tablas listadas.

### 3. Ejecutar el servidor

```bash
npm run dev
```

El servidor estará corriendo en `http://localhost:3001`

## 📡 Endpoints Disponibles

- **GET** `/api/roles` - Listar roles
- **POST** `/api/roles` - Crear rol
- **GET** `/api/users` - Listar usuarios
- **POST** `/api/users` - Crear usuario
- **GET** `/api/categories` - Listar categorías
- **POST** `/api/categories` - Crear categoría
- **GET** `/api/products` - Listar productos
- **POST** `/api/products` - Crear producto
- **GET** `/api/orders` - Listar órdenes
- **POST** `/api/orders` - Crear orden
- **GET** `/api/countries` - Listar países
- **GET** `/api/states?country_id=xxx` - Listar estados

## ✅ Probar la conexión

```bash
node test-connection.js
```

Si todo está bien configurado, deberías ver: `Connection successful!`
