const { Client } = require('pg');
const fs = require('fs');
const path = require('path');

async function resetDatabase() {
    const client = new Client({
        host: 'db.tltirpvrthluiewrkjys.supabase.co',
        port: 5432,
        database: 'postgres',
        user: 'postgres',
        password: 'x9ke#jamoB',
        ssl: { rejectUnauthorized: false }
    });

    try {
        await client.connect();
        console.log('Conectado a PostgreSQL');

        // Eliminar tablas existentes en orden correcto (por dependencias)
        console.log('\nEliminando tablas existentes...');

        const dropTables = [
            'DROP TABLE IF EXISTS public.order_items CASCADE;',
            'DROP TABLE IF EXISTS public.orders CASCADE;',
            'DROP TABLE IF EXISTS public.products CASCADE;',
            'DROP TABLE IF EXISTS public.categories CASCADE;',
            'DROP TABLE IF EXISTS public.states CASCADE;',
            'DROP TABLE IF EXISTS public.countries CASCADE;',
            'DROP TABLE IF EXISTS public.users CASCADE;',
            'DROP TABLE IF EXISTS public.roles CASCADE;'
        ];

        for (const dropSQL of dropTables) {
            await client.query(dropSQL);
            const tableName = dropSQL.split(' ')[5];
            console.log('  - Eliminada: ' + tableName);
        }

        // Leer y ejecutar schema.sql
        console.log('\nEjecutando schema.sql...');
        const schemaPath = path.join(__dirname, 'schema.sql');
        const schemaSql = fs.readFileSync(schemaPath, 'utf8');

        await client.query(schemaSql);
        console.log('  - Schema ejecutado correctamente');

        // Verificar tablas creadas
        console.log('\nVerificando tablas creadas:');
        const result = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      ORDER BY table_name;
    `);

        result.rows.forEach(row => {
            console.log('  - ' + row.table_name);
        });

        console.log('\nBase de datos configurada exitosamente!');

    } catch (err) {
        console.error('Error:', err.message);
    } finally {
        await client.end();
    }
}

resetDatabase();
