const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://tltirpvrthluiewrkjys.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsdGlycHZydGhsdWlld3JranlzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIwMzEyNDksImV4cCI6MjA3NzYwNzI0OX0.O1d-R7oqkUsa8x06628GESa3z7rlQZt1X38_m2mI7OE';

const supabase = createClient(supabaseUrl, supabaseKey);

async function testConnection() {
    console.log('Testing connection to Supabase...');

    const { data, error } = await supabase
        .from('roles')
        .select('*')
        .limit(1);

    if (error) {
        console.error('Connection failed:', error.message);
    } else {
        console.log('Connection successful!');
        console.log('Data:', data);
    }
}

testConnection();
