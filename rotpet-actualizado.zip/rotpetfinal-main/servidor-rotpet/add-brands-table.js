require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
    host: 'db.tltirpvrthluiewrkjys.supabase.co',
    port: 5432,
    database: 'postgres',
    user: 'postgres',
    password: 'x9ke#jamoB',
    ssl: { rejectUnauthorized: false }
});

async function addBrandsTable() {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS brands (
                id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                name TEXT UNIQUE NOT NULL,
                slug TEXT UNIQUE NOT NULL,
                logo_url TEXT,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        `);
        console.log('Brands table created successfully');
    } catch (error) {
        console.error('Error creating brands table:', error);
    } finally {
        await pool.end();
    }
}

addBrandsTable();
