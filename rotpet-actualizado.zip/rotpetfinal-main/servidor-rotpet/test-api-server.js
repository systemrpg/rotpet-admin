const http = require('http');

function testEndpoint(method, path, body = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3001,
            path: path,
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
        };

        const req = http.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            res.on('end', () => {
                console.log(`[${method} ${path}] Status: ${res.statusCode}`);
                console.log(`Response: ${data.substring(0, 100)}...`); // Log first 100 chars
                resolve();
            });
        });

        req.on('error', (e) => {
            console.error(`[${method} ${path}] Error: ${e.message}`);
            reject(e);
        });

        if (body) {
            req.write(JSON.stringify(body));
        }
        req.end();
    });
}

async function runTests() {
    console.log('Testing API Server Connectivity...');

    try {
        // Test 1: GET Root
        await testEndpoint('GET', '/');

        // Test 2: GET Categories
        await testEndpoint('GET', '/api/categories');

        // Test 3: POST Category (Test)
        const newCat = {
            name: `API Test ${Date.now()}`,
            slug: `api-test-${Date.now()}`,
            status: 'active'
        };
        await testEndpoint('POST', '/api/categories', newCat);

    } catch (err) {
        console.error('Test failed');
    }
}

runTests();
