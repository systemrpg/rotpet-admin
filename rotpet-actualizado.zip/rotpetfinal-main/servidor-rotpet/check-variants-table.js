require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_KEY;

if (!supabaseUrl || !supabaseKey) {
    console.error('Missing SUPABASE_URL or SUPABASE_KEY');
    process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkTable() {
    console.log('Checking for product_variants table...');
    const { data, error } = await supabase
        .from('product_variants')
        .select('count', { count: 'exact', head: true });

    if (error) {
        console.error('Error connecting to product_variants table:');
        console.error(error.message);
        if (error.code === '42P01') { // undefined_table
            console.error('\nCONFIRMED: The table "product_variants" DOES NOT EXIST.');
        }
    } else {
        console.log('SUCCESS: Table "product_variants" exists and is accessible.');
    }
}

checkTable();
