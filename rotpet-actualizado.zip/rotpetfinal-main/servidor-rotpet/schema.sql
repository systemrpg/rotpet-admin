-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- ROLES
create table public.roles (
  id uuid default uuid_generate_v4() primary key,
  name text not null unique,
  permissions jsonb default '[]'::jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- USERS (Extends Supabase Auth or Standalone)
-- Note: If using Supabase Auth, we usually trigger a profile creation. 
-- For this backoffice, we'll assume a public.users table that links to auth.users or is standalone for simplicity as per requirements.
create table public.users (
  id uuid default uuid_generate_v4() primary key,
  email text not null unique,
  full_name text,
  role_id uuid references public.roles(id),
  status text default 'active' check (status in ('active', 'inactive')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- CATEGORIES
create table public.categories (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  slug text not null unique,
  image_url text,
  status text default 'active' check (status in ('active', 'inactive')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- BRANDS
create table public.brands (
  id uuid default uuid_generate_v4() primary key,
  name text not null unique,
  slug text not null unique,
  logo_url text,
  description text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- PRODUCTS
create table public.products (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  sku text not null unique,
  price decimal(10,2) not null,
  quantity integer default 0,
  status text default 'active' check (status in ('active', 'inactive')),
  category_id uuid references public.categories(id),
  image_url text,
  description text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- COUNTRIES
create table public.countries (
  id uuid default uuid_generate_v4() primary key,
  name text not null,
  code text not null unique
);

-- STATES
create table public.states (
  id uuid default uuid_generate_v4() primary key,
  country_id uuid references public.countries(id),
  name text not null
);

-- ORDERS
create table public.orders (
  id uuid default uuid_generate_v4() primary key,
  user_id uuid references public.users(id),
  total_amount decimal(10,2) not null,
  status text default 'pending' check (status in ('pending', 'processing', 'completed', 'cancelled')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- ORDER ITEMS
create table public.order_items (
  id uuid default uuid_generate_v4() primary key,
  order_id uuid references public.orders(id) on delete cascade,
  product_id uuid references public.products(id),
  quantity integer not null,
  unit_price decimal(10,2) not null
);

-- SEED DATA (Optional - for testing)
insert into public.roles (name, permissions) values 
('admin', '["all"]'), 
('staff', '["read_products", "write_products", "read_orders"]'), 
('user', '["read_products", "create_orders"]');

insert into public.categories (name, slug, status) values 
('Alimentos Secos', 'alimentos-secos', 'active'),
('Juguetes', 'juguetes', 'active');
