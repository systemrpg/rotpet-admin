const http = require('http');

function testEndpoint(method, path, body = null) {
    return new Promise((resolve, reject) => {
        const options = {
            hostname: 'localhost',
            port: 3001,
            path: path,
            method: method,
            headers: {
                'Content-Type': 'application/json',
            },
        };

        const req = http.request(options, (res) => {
            let data = '';
            res.on('data', (chunk) => {
                data += chunk;
            });
            res.on('end', () => {
                console.log(`[${method} ${path}] Status: ${res.statusCode}`);
                if (data) {
                    try {
                        const json = JSON.parse(data);
                        console.log(`Response:`, JSON.stringify(json).substring(0, 100) + '...');
                        resolve(json);
                    } catch (e) {
                        console.log(`Response: ${data.substring(0, 100)}...`);
                        resolve(data);
                    }
                } else {
                    console.log('Response: (empty)');
                    resolve(null);
                }
            });
        });

        req.on('error', (e) => {
            console.error(`[${method} ${path}] Error: ${e.message}`);
            reject(e);
        });

        if (body) {
            req.write(JSON.stringify(body));
        }
        req.end();
    });
}

async function runTests() {
    console.log('Testing Roles CRUD with Permissions...');

    try {
        // 1. Create Role with Permissions
        console.log('\n--- Creating Role (Vendedor) ---');
        const newRole = {
            name: `Vendedor ${Date.now()}`,
            permissions: ['products.read', 'orders.read', 'orders.update']
        };
        const createdRole = await testEndpoint('POST', '/api/roles', newRole);
        if (!createdRole || !createdRole.id) throw new Error('Failed to create role');
        const roleId = createdRole.id;
        console.log(`Created Role ID: ${roleId}`);

        // 2. Get Role and Verify Permissions
        console.log('\n--- Getting Role ---');
        const fetchedRole = await testEndpoint('GET', `/api/roles/${roleId}`);
        if (Array.isArray(fetchedRole.permissions) && fetchedRole.permissions.includes('products.read')) {
            console.log('SUCCESS: Permissions saved correctly.');
        } else {
            console.error('FAILURE: Permissions mismatch:', fetchedRole.permissions);
        }

        // 3. Update Role Permissions
        console.log('\n--- Updating Role Permissions ---');
        const updateData = {
            name: fetchedRole.name,
            permissions: ['products.read', 'orders.read', 'orders.update', 'users.read']
        };
        const updatedRole = await testEndpoint('PUT', `/api/roles/${roleId}`, updateData);
        if (updatedRole.permissions.includes('users.read')) {
            console.log('SUCCESS: Permissions updated correctly.');
        } else {
            console.error('FAILURE: Permissions update failed:', updatedRole.permissions);
        }

        // 4. Delete Role
        console.log('\n--- Deleting Role ---');
        await testEndpoint('DELETE', `/api/roles/${roleId}`);

    } catch (err) {
        console.error('Test failed:', err);
    }
}

runTests();
