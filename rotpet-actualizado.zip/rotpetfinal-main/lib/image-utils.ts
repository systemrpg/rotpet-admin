/**
 * Resizes and crops an image to a square of the specified size.
 * @param file The input image file
 * @param size The target width/height (default 800px)
 * @returns A Promise that resolves to a Blob
 */
export const resizeImage = (file: File, size: number = 800): Promise<Blob> => {
    return new Promise((resolve, reject) => {
        const img = new Image();
        const url = URL.createObjectURL(file);

        img.onload = () => {
            URL.revokeObjectURL(url);
            const canvas = document.createElement('canvas');
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext('2d');

            if (!ctx) {
                reject(new Error("Could not get canvas context"));
                return;
            }

            // Calculate crop
            let sourceX = 0;
            let sourceY = 0;
            let sourceWidth = img.width;
            let sourceHeight = img.height;

            if (img.width > img.height) {
                sourceWidth = img.height;
                sourceX = (img.width - img.height) / 2;
            } else {
                sourceHeight = img.width;
                sourceY = (img.height - img.width) / 2;
            }

            // Draw cropped image to canvas
            ctx.drawImage(
                img,
                sourceX,
                sourceY,
                sourceWidth,
                sourceHeight,
                0,
                0,
                size,
                size
            );

            // Export as JPEG with 0.8 quality
            canvas.toBlob(
                (blob) => {
                    if (blob) {
                        resolve(blob);
                    } else {
                        reject(new Error("Canvas to Blob failed"));
                    }
                },
                "image/jpeg",
                0.8
            );
        };

        img.onerror = (err) => {
            URL.revokeObjectURL(url);
            reject(err);
        };

        img.src = url;
    });
};
