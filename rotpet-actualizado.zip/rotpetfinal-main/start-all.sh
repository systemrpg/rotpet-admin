#!/bin/bash

# Load nvm and use Node.js 22
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
nvm use 22

echo "🚀 Starting Rot Pet System..."

# Start Backend
echo "📦 Starting Backend Server (Port 3001)..."
(cd servidor-rotpet && npm run dev) &
BACKEND_PID=$!

# Wait a moment for backend to initialize
sleep 2

# Start Frontend
echo "💻 Starting Frontend (Next.js)..."
npm run dev &
FRONTEND_PID=$!

echo "✅ Both services started!"
echo "   - Backend: http://localhost:3001"
echo "   - Frontend: http://localhost:3000"
echo "Press Ctrl+C to stop both."

# Handle shutdown
trap "kill $BACKEND_PID $FRONTEND_PID; exit" SIGINT

# Wait for both processes
wait $BACKEND_PID $FRONTEND_PID
