"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Save, X } from "lucide-react"

interface PageFormProps {
  id?: string
}

export default function PageForm({ id }: PageFormProps) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    content: "",
    status: "draft" as "published" | "draft",
    meta_title: "",
    meta_description: "",
  })

  useEffect(() => {
    if (id) {
      // Simulamos carga de datos - aquí conectarías con tu API
      const pages = [
        {
          id: "1",
          title: "Sobre Nosotros",
          slug: "sobre-nosotros",
          content: "Contenido de la página sobre nosotros...",
          status: "published" as const,
          meta_title: "Sobre Nosotros - Rot Pet",
          meta_description: "Conoce más sobre Rot Pet Shop",
        },
        {
          id: "2",
          title: "Términos y Condiciones",
          slug: "terminos-condiciones",
          content: "Contenido de términos y condiciones...",
          status: "published" as const,
          meta_title: "Términos y Condiciones",
          meta_description: "Lee nuestros términos y condiciones",
        },
      ]
      const page = pages.find((p) => p.id === id)
      if (page) {
        setFormData(page)
      }
    }
  }, [id])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Aquí conectarías con tu API
      await new Promise((resolve) => setTimeout(resolve, 1000))
      console.log("Guardando página:", formData)
      router.push("/pages")
    } catch (error) {
      console.error("Error saving page:", error)
      alert("Error al guardar la página")
    } finally {
      setLoading(false)
    }
  }

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[áàäâ]/g, "a")
      .replace(/[éèëê]/g, "e")
      .replace(/[íìïî]/g, "i")
      .replace(/[óòöô]/g, "o")
      .replace(/[úùüû]/g, "u")
      .replace(/ñ/g, "n")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
  }

  const handleTitleChange = (title: string) => {
    setFormData({
      ...formData,
      title,
      slug: generateSlug(title),
    })
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Columna principal */}
        <div className="lg:col-span-2 space-y-6">
          {/* Título */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">
              Título de la Página <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
              value={formData.title}
              onChange={(e) => handleTitleChange(e.target.value)}
              placeholder="Ej: Sobre Nosotros"
            />
          </div>

          {/* Slug */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">
              Slug (URL amigable) <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
              value={formData.slug}
              onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
              placeholder="sobre-nosotros"
            />
            <p className="text-xs text-gray-500">
              URL: rot.pet/{formData.slug || "slug-de-la-pagina"}
            </p>
          </div>

          {/* Contenido */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">
              Contenido <span className="text-red-500">*</span>
            </label>
            <textarea
              required
              rows={12}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 font-mono text-sm"
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              placeholder="Escribe el contenido de la página aquí. Puedes usar HTML o Markdown."
            />
            <p className="text-xs text-gray-500">
              Puedes usar HTML básico para formatear el contenido
            </p>
          </div>

          {/* SEO Meta Tags */}
          <div className="border-t pt-6 space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">SEO</h3>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Meta Título</label>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                value={formData.meta_title}
                onChange={(e) => setFormData({ ...formData, meta_title: e.target.value })}
                placeholder="Título para motores de búsqueda"
                maxLength={60}
              />
              <p className="text-xs text-gray-500">
                {formData.meta_title.length}/60 caracteres recomendados
              </p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Meta Descripción</label>
              <textarea
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                value={formData.meta_description}
                onChange={(e) => setFormData({ ...formData, meta_description: e.target.value })}
                placeholder="Descripción breve para motores de búsqueda"
                maxLength={160}
              />
              <p className="text-xs text-gray-500">
                {formData.meta_description.length}/160 caracteres recomendados
              </p>
            </div>
          </div>
        </div>

        {/* Columna lateral */}
        <div className="space-y-6">
          {/* Estado */}
          <div className="bg-gray-50 rounded-lg border border-gray-200 p-4 space-y-4">
            <h3 className="font-semibold text-gray-900">Publicación</h3>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Estado</label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                value={formData.status}
                onChange={(e) =>
                  setFormData({ ...formData, status: e.target.value as "published" | "draft" })
                }
              >
                <option value="draft">Borrador</option>
                <option value="published">Publicada</option>
              </select>
            </div>

            <div className="pt-4 border-t space-y-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full tf-button flex items-center justify-center gap-2"
              >
                <Save size={18} />
                {loading ? "Guardando..." : id ? "Actualizar" : "Guardar"}
              </button>

              <button
                type="button"
                onClick={() => router.push("/pages")}
                className="w-full bg-gray-100 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
              >
                <X size={18} />
                Cancelar
              </button>
            </div>
          </div>

          {/* Ayuda */}
          <div className="bg-blue-50 rounded-lg border border-blue-200 p-4">
            <h4 className="font-semibold text-blue-900 mb-2">💡 Consejos</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Usa títulos descriptivos</li>
              <li>• El slug debe ser único</li>
              <li>• Optimiza para SEO</li>
              <li>• Revisa antes de publicar</li>
            </ul>
          </div>
        </div>
      </div>
    </form>
  )
}
