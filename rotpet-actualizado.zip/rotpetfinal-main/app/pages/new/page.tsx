"use client"

import Layout from "@/components/layout"
import PageForm from "../page-form"

export default function NewPagePage() {
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Nueva Página</h1>
        <p className="text-gray-600 mt-1">Crea una nueva página de contenido</p>
      </div>

      <PageForm />
    </Layout>
  )
}
