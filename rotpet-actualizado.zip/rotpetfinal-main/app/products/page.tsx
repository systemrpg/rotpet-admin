import Layout from "@/components/layout"
import { Plus } from "lucide-react"
import Link from "next/link"
import ProductList from "./product-list"

export default function ProductsPage() {
  return (
    <Layout>
      {/* Page Header */}
      <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Productos</h1>
              <p className="text-gray-600 mt-1">Gestiona tu catálogo de productos para Rot Pet</p>
            </div>
            <Link href="/products/new" className="tf-button flex items-center gap-2">
              <Plus size={20} />
              Agregar Producto
            </Link>
          </div>

      {/* Products List Component */}
      <ProductList />
    </Layout>
  )
}
