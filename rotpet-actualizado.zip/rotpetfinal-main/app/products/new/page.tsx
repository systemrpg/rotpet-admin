import Layout from "@/components/layout"
import ProductForm from "../product-form"

export default function NewProductPage() {
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Agregar Producto</h1>
        <p className="text-gray-600 mt-1">Crea un nuevo producto para Rot Pet</p>
      </div>

      <ProductForm />
    </Layout>
  )
}
