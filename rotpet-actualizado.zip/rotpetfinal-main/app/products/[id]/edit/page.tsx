import Layout from "@/components/layout"
import ProductForm from "../../product-form"

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Editar Producto</h1>
        <p className="text-gray-600 mt-1">Modifica los detalles del producto</p>
      </div>

      <ProductForm id={id} />
    </Layout>
  )
}
