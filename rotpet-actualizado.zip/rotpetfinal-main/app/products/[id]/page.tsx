"use client"

import { useState, useEffect, use } from "react"
import { useRouter } from "next/navigation"
import { ArrowLeft, Edit } from "lucide-react"
import Link from "next/link"
import Layout from "@/components/layout"

interface Variant {
    sku: string
    price: number
    stock: number
    attributes: Record<string, string>
    status: string
}

interface Product {
    id: string
    name: string
    sku: string
    price: number
    quantity: number
    status: string
    category_id: string
    image_url: string
    description: string
    category?: { name: string }
    variants: Variant[]
}

export default function ProductDetailPage({ params }: { params: Promise<{ id: string }> }) {
    const router = useRouter()
    const { id } = use(params)
    const [product, setProduct] = useState<Product | null>(null)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        fetchProduct()
    }, [id])

    const fetchProduct = async () => {
        try {
            const response = await fetch(`http://localhost:3001/api/products/${id}`)
            if (response.ok) {
                const data = await response.json()
                setProduct(data)
            }
        } catch (error) {
            console.error("Error fetching product:", error)
        } finally {
            setLoading(false)
        }
    }

    if (loading) return <Layout><div className="p-8 text-center">Cargando producto...</div></Layout>
    if (!product) return <Layout><div className="p-8 text-center">Producto no encontrado</div></Layout>

    return (
        <Layout>
                    <div className="space-y-6">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <button
                                    onClick={() => router.back()}
                                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                                >
                                    <ArrowLeft size={20} className="text-gray-600" />
                                </button>
                                <h1 className="text-2xl font-bold text-gray-900">{product.name}</h1>
                            </div>
                            <Link
                                href={`/products/${product.id}/edit`}
                                className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 flex items-center gap-2"
                            >
                                <Edit size={20} />
                                Editar Producto
                            </Link>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {/* Main Info */}
                            <div className="md:col-span-2 space-y-6">
                                <div className="bg-white rounded-lg border border-gray-200 p-6">
                                    <h2 className="text-lg font-semibold text-gray-900 mb-4">Información General</h2>
                                    <div className="grid grid-cols-2 gap-6">
                                        <div>
                                            <label className="text-sm font-medium text-gray-500">SKU Base</label>
                                            <p className="text-gray-900 font-medium">{product.sku}</p>
                                        </div>
                                        <div>
                                            <label className="text-sm font-medium text-gray-500">Categoría</label>
                                            <p className="text-gray-900 font-medium">{product.category?.name || "Sin categoría"}</p>
                                        </div>
                                        <div>
                                            <label className="text-sm font-medium text-gray-500">Precio Base</label>
                                            <p className="text-gray-900 font-medium">${product.price}</p>
                                        </div>
                                        <div>
                                            <label className="text-sm font-medium text-gray-500">Stock Total</label>
                                            <p className="text-gray-900 font-medium">
                                                {product.variants && product.variants.length > 0
                                                    ? product.variants.reduce((acc, v) => acc + (v.stock || 0), 0)
                                                    : product.quantity}
                                            </p>
                                        </div>
                                        <div>
                                            <label className="text-sm font-medium text-gray-500">Estado</label>
                                            <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${product.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                                {product.status === 'active' ? 'Activo' : 'Inactivo'}
                                            </span>
                                        </div>
                                    </div>
                                    {product.description && (
                                        <div className="mt-6">
                                            <label className="text-sm font-medium text-gray-500">Descripción</label>
                                            <p className="text-gray-700 mt-1">{product.description}</p>
                                        </div>
                                    )}
                                </div>

                                {/* Variants Table */}
                                {product.variants && product.variants.length > 0 && (
                                    <div className="bg-white rounded-lg border border-gray-200 p-6">
                                        <h2 className="text-lg font-semibold text-gray-900 mb-4">Variantes ({product.variants.length})</h2>
                                        <div className="overflow-x-auto">
                                            <table className="w-full text-sm text-left">
                                                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                                    <tr>
                                                        <th className="px-4 py-3">Variante</th>
                                                        <th className="px-4 py-3">SKU</th>
                                                        <th className="px-4 py-3">Precio</th>
                                                        <th className="px-4 py-3">Stock</th>
                                                        <th className="px-4 py-3">Estado</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="divide-y divide-gray-200">
                                                    {product.variants.map((variant, idx) => (
                                                        <tr key={idx}>
                                                            <td className="px-4 py-3 font-medium text-gray-900">
                                                                {Object.entries(variant.attributes).map(([k, v]) => `${k}: ${v}`).join(", ")}
                                                            </td>
                                                            <td className="px-4 py-3 text-gray-600">{variant.sku}</td>
                                                            <td className="px-4 py-3 text-gray-900">${variant.price || product.price}</td>
                                                            <td className="px-4 py-3 text-gray-900">{variant.stock}</td>
                                                            <td className="px-4 py-3">
                                                                <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${variant.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                                                                    {variant.status}
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* Sidebar Info (Image, etc) */}
                            <div className="space-y-6">
                                <div className="bg-white rounded-lg border border-gray-200 p-6">
                                    <h2 className="text-lg font-semibold text-gray-900 mb-4">Imagen</h2>
                                    {product.image_url ? (
                                        <div className="aspect-square rounded-lg overflow-hidden bg-gray-100 border border-gray-200">
                                            <img
                                                src={product.image_url}
                                                alt={product.name}
                                                className="w-full h-full object-cover"
                                            />
                                        </div>
                                    ) : (
                                        <div className="aspect-square rounded-lg bg-gray-100 flex items-center justify-center text-gray-400">
                                            Sin imagen
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </Layout>
    )
}
