import { use } from "react"
import Layout from "@/components/layout"
import CouponForm from "../../coupon-form"

export default function EditCouponPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = use(params)
    return (
        <Layout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Editar Cupón</h1>
                <p className="text-gray-600 mt-1">Modifica el código promocional</p>
            </div>
            <CouponForm couponId={id} />
        </Layout>
    )
}
