import Layout from "@/components/layout"
import { Plus } from "lucide-react"
import Link from "next/link"
import CouponList from "./coupon-list"

export default function CouponsPage() {
    return (
        <Layout>
            <div className="flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Cupones y Descuentos</h1>
                    <p className="text-gray-600 mt-1">Gestiona los códigos promocionales</p>
                </div>
                <Link href="/coupons/new" className="tf-button flex items-center gap-2">
                    <Plus size={20} />
                    Nuevo Cupón
                </Link>
            </div>

            <CouponList />
        </Layout>
    )
}
