"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Edit, Trash2, Plus, Search, Ticket } from "lucide-react"
import { toast } from "sonner"
import { ConfirmModal } from "@/components/confirm-modal"

interface Coupon {
    id: string
    code: string
    discount_type: 'percentage' | 'fixed'
    discount_value: number
    min_purchase: number | null
    expiration_date: string | null
    usage_limit: number | null
    used_count: number
    status: 'active' | 'inactive'
    created_at: string
}

export default function CouponList() {
    const [coupons, setCoupons] = useState<Coupon[]>([])
    const [loading, setLoading] = useState(true)
    const [searchTerm, setSearchTerm] = useState("")
    const [deleteId, setDeleteId] = useState<string | null>(null)

    const fetchCoupons = async () => {
        try {
            const response = await fetch("http://localhost:3001/api/coupons")
            if (!response.ok) throw new Error("Failed to fetch coupons")
            const data = await response.json()
            setCoupons(data)
        } catch (error) {
            console.error("Error fetching coupons:", error)
            toast.error("Error al cargar los cupones")
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchCoupons()
    }, [])

    const handleDelete = async () => {
        if (!deleteId) return

        try {
            const response = await fetch(`http://localhost:3001/api/coupons/${deleteId}`, {
                method: "DELETE",
            })

            if (response.ok) {
                toast.success("Cupón eliminado correctamente")
                fetchCoupons()
            } else {
                const data = await response.json()
                toast.error("Error al eliminar el cupón", {
                    description: data.error || "Ocurrió un error inesperado"
                })
            }
        } catch (error) {
            console.error("Error deleting coupon:", error)
            toast.error("Error al eliminar el cupón")
        } finally {
            setDeleteId(null)
        }
    }

    const filteredCoupons = coupons.filter((coupon) =>
        coupon.code.toLowerCase().includes(searchTerm.toLowerCase())
    )

    if (loading) {
        return <div className="p-8 text-center text-gray-500">Cargando cupones...</div>
    }

    return (
        <div className="space-y-6">
            <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <input
                    type="text"
                    placeholder="Buscar cupones..."
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Código</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Descuento</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Estado</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Usos</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Expira</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Acciones</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {filteredCoupons.length === 0 ? (
                                <tr>
                                    <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                                        No se encontraron cupones
                                    </td>
                                </tr>
                            ) : (
                                filteredCoupons.map((coupon) => (
                                    <tr key={coupon.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center gap-2">
                                                <Ticket size={16} className="text-orange-600" />
                                                <span className="font-medium text-gray-900">{coupon.code}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                            {coupon.discount_type === 'percentage' ? `${coupon.discount_value}%` : `$${coupon.discount_value}`}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${coupon.status === 'active'
                                                    ? 'bg-green-100 text-green-800'
                                                    : 'bg-red-100 text-red-800'
                                                }`}>
                                                {coupon.status === 'active' ? 'Activo' : 'Inactivo'}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                            {coupon.used_count} / {coupon.usage_limit || '∞'}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                                            {coupon.expiration_date
                                                ? new Date(coupon.expiration_date).toLocaleDateString()
                                                : 'Sin fecha'}
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                                            <div className="flex items-center gap-2">
                                                <Link
                                                    href={`/coupons/${coupon.id}/edit`}
                                                    className="p-2 hover:bg-blue-50 rounded transition-colors"
                                                    title="Editar"
                                                >
                                                    <Edit size={16} className="text-blue-600" />
                                                </Link>
                                                <button
                                                    onClick={() => setDeleteId(coupon.id)}
                                                    className="p-2 hover:bg-red-50 rounded transition-colors"
                                                    title="Eliminar"
                                                >
                                                    <Trash2 size={16} className="text-red-600" />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <ConfirmModal
                isOpen={!!deleteId}
                onClose={() => setDeleteId(null)}
                onConfirm={handleDelete}
                title="Eliminar Cupón"
                description="¿Estás seguro de que deseas eliminar este cupón? Esta acción no se puede deshacer."
                confirmText="Eliminar"
                variant="danger"
            />
        </div>
    )
}
