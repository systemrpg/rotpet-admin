import Layout from "@/components/layout"
import CouponForm from "../coupon-form"

export default function NewCouponPage() {
    return (
        <Layout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Nuevo Cupón</h1>
                <p className="text-gray-600 mt-1">Crea un código promocional</p>
            </div>
            <CouponForm />
        </Layout>
    )
}
