import Layout from "@/components/layout"
import RoleForm from "../role-form"

export default function NewRolePage() {
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Crear Rol</h1>
        <p className="text-gray-600 mt-1">Define un nuevo rol y sus permisos</p>
      </div>

      <RoleForm />
    </Layout>
  )
}
