"use client"

import { useState, useEffect } from "react"
import { Edit, Trash2, Shield, Plus, Eye } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { ConfirmModal } from "@/components/confirm-modal"

interface Role {
    id: string
    name: string
    permissions: string[] | null
    created_at: string
}

export default function RoleList() {
    const [roles, setRoles] = useState<Role[]>([])
    const [loading, setLoading] = useState(true)
    const [deleteId, setDeleteId] = useState<string | null>(null)
    const router = useRouter()

    const fetchRoles = async () => {
        try {
            const response = await fetch("http://localhost:3001/api/roles")
            if (!response.ok) throw new Error("Failed to fetch roles")
            const data = await response.json()
            setRoles(data)
        } catch (error) {
            console.error("Error fetching roles:", error)
            toast.error("Error al cargar los roles")
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchRoles()
    }, [])

    const handleDelete = async () => {
        if (!deleteId) return

        try {
            const response = await fetch(`http://localhost:3001/api/roles/${deleteId}`, {
                method: "DELETE",
            })

            if (response.ok) {
                toast.success("Rol eliminado correctamente")
                fetchRoles()
            } else {
                const data = await response.json()
                toast.error("Error al eliminar el rol", {
                    description: data.error || "Ocurrió un error inesperado"
                })
            }
        } catch (error) {
            console.error("Error deleting role:", error)
            toast.error("Error al eliminar el rol")
        } finally {
            setDeleteId(null)
        }
    }

    const formatPermissions = (permissions: string[] | null) => {
        if (!permissions || permissions.length === 0) return "Sin permisos"
        if (permissions.includes("all")) return "Acceso Total (Admin)"

        const count = permissions.length
        if (count <= 3) return permissions.join(", ")
        return `${count} permisos asignados`
    }

    if (loading) {
        return <div className="p-8 text-center text-gray-500">Cargando roles...</div>
    }

    return (
        <>
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Rol</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Permisos</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Fecha de Creación</th>
                                <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Acciones</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {roles.length === 0 ? (
                                <tr>
                                    <td colSpan={4} className="px-6 py-8 text-center text-gray-500">
                                        No hay roles definidos
                                    </td>
                                </tr>
                            ) : (
                                roles.map((role) => (
                                    <tr key={role.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 text-sm font-medium text-gray-900">
                                            <div className="flex items-center gap-2">
                                                <Shield size={16} className="text-orange-600" />
                                                <span className="capitalize">{role.name}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-sm text-gray-600 max-w-md truncate" title={Array.isArray(role.permissions) ? role.permissions.join(", ") : ""}>
                                            {formatPermissions(role.permissions)}
                                        </td>
                                        <td className="px-6 py-4 text-sm text-gray-600">
                                            {new Date(role.created_at).toLocaleDateString()}
                                        </td>
                                        <td className="px-6 py-4 text-sm">
                                            <div className="flex items-center gap-2">
                                                <Link
                                                    href={`/roles/${role.id}`}
                                                    className="p-2 hover:bg-blue-50 rounded transition-colors"
                                                    title="Ver detalles"
                                                >
                                                    <Eye size={16} className="text-blue-600" />
                                                </Link>
                                                <Link
                                                    href={`/roles/${role.id}/edit`}
                                                    className="p-2 hover:bg-gray-100 rounded transition-colors"
                                                    title="Editar"
                                                >
                                                    <Edit size={16} className="text-gray-600" />
                                                </Link>
                                                <button
                                                    onClick={() => setDeleteId(role.id)}
                                                    className="p-2 hover:bg-red-50 rounded transition-colors"
                                                    title="Eliminar"
                                                >
                                                    <Trash2 size={16} className="text-red-600" />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <ConfirmModal
                isOpen={!!deleteId}
                onClose={() => setDeleteId(null)}
                onConfirm={handleDelete}
                title="Eliminar Rol"
                description="¿Estás seguro de que deseas eliminar este rol? Esta acción no se puede deshacer."
                confirmText="Eliminar"
                variant="danger"
            />
        </>
    )
}
