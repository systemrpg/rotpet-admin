import Layout from "@/components/layout"
import { Plus } from "lucide-react"
import Link from "next/link"
import RoleList from "./role-list"

export default function RolesPage() {
    return (
        <Layout>
            <div className="flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Roles</h1>
                    <p className="text-gray-600 mt-1">Gestiona los roles y permisos</p>
                </div>
                <Link href="/roles/new" className="tf-button flex items-center gap-2">
                    <Plus size={20} />
                    Nuevo Rol
                </Link>
            </div>

            <RoleList />
        </Layout>
    )
}
