import Layout from "@/components/layout"
import CategoryForm from "../category-form"

export default function NewCategoryPage() {
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Nueva Categoría</h1>
        <p className="text-gray-600 mt-1">Crea una nueva categoría de productos</p>
      </div>

      <CategoryForm />
    </Layout>
  )
}
