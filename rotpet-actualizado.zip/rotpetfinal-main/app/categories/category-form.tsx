"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Save, X } from "lucide-react"

interface CategoryFormProps {
    id?: string // If present, we are editing
}

export default function CategoryForm({ id }: CategoryFormProps) {
    const router = useRouter()
    const [loading, setLoading] = useState(false)
    const [formData, setFormData] = useState({
        name: "",
        slug: "",
        status: "active",
        image_url: "",
    })

    useEffect(() => {
        if (id) {
            fetchCategory(id)
        }
    }, [id])

    const fetchCategory = async (categoryId: string) => {
        try {
            const response = await fetch(`http://localhost:3001/api/categories/${categoryId}`)
            if (response.ok) {
                const data = await response.json()
                setFormData({
                    name: data.name,
                    slug: data.slug,
                    status: data.status,
                    image_url: data.image_url || "",
                })
            }
        } catch (error) {
            console.error("Error fetching category:", error)
        }
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()
        setLoading(true)

        try {
            const url = id
                ? `http://localhost:3001/api/categories/${id}`
                : "http://localhost:3001/api/categories"

            const method = id ? "PUT" : "POST"

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(formData),
            })

            if (response.ok) {
                router.push("/categories")
                router.refresh()
            } else {
                const errorData = await response.json()
                alert(`Error al guardar la categoría: ${errorData.error || "Error desconocido"}`)
            }
        } catch (error) {
            console.error("Error saving category:", error)
            alert("Error al guardar la categoría: Error de red o servidor")
        } finally {
            setLoading(false)
        }
    }

    return (
        <form onSubmit={handleSubmit} className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="grid grid-cols-1 gap-6">
                <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Nombre de la Categoría</label>
                    <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                </div>

                <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Slug (URL amigable)</label>
                    <input
                        type="text"
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        value={formData.slug}
                        onChange={(e) => setFormData({ ...formData, slug: e.target.value })}
                    />
                </div>

                <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">Estado</label>
                    <select
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        value={formData.status}
                        onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    >
                        <option value="active">Activa</option>
                        <option value="inactive">Inactiva</option>
                    </select>
                </div>

                <div className="space-y-2">
                    <label className="text-sm font-medium text-gray-700">URL de Imagen (Opcional)</label>
                    <input
                        type="url"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                        value={formData.image_url}
                        onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                    />
                </div>
            </div>

            <div className="mt-8 flex justify-end gap-4">
                <button
                    type="button"
                    onClick={() => router.back()}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                >
                    <X size={20} />
                    Cancelar
                </button>
                <button
                    type="submit"
                    disabled={loading}
                    className="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 flex items-center gap-2 disabled:opacity-50"
                >
                    <Save size={20} />
                    {loading ? "Guardando..." : "Guardar Categoría"}
                </button>
            </div>
        </form>
    )
}
