import Layout from "@/components/layout"
import { Plus } from "lucide-react"
import Link from "next/link"
import CategoryList from "./category-list"

export default function CategoriesPage() {
  return (
    <Layout>
      {/* Page Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Categorías</h1>
          <p className="text-gray-600 mt-1">Gestiona las categorías de productos</p>
        </div>
        <Link href="/categories/new" className="tf-button flex items-center gap-2">
          <Plus size={20} />
          Nueva Categoría
        </Link>
      </div>

      {/* Categories List Component */}
      <CategoryList />
    </Layout>
  )
}
