"use client"

import { useState, useEffect } from "react"
import { Edit, Trash2 } from "lucide-react"
import Link from "next/link"

interface Category {
    id: string
    name: string
    slug: string
    status: string
    product_count: number
}

export default function CategoryList() {
    const [categories, setCategories] = useState<Category[]>([])
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        fetchCategories()
    }, [])

    const fetchCategories = async () => {
        try {
            const response = await fetch("http://localhost:3001/api/categories")
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}))
                throw new Error(errorData.error || "Failed to fetch categories")
            }
            const data = await response.json()
            setCategories(data)
        } catch (error: any) {
            console.error("Error fetching categories:", error)
            // Optional: Set an error state to display in UI
        } finally {
            setLoading(false)
        }
    }

    const handleDelete = async (id: string) => {
        if (!confirm("¿Estás seguro de que deseas eliminar esta categoría?")) return

        try {
            const response = await fetch(`http://localhost:3001/api/categories/${id}`, {
                method: "DELETE",
            })

            if (response.ok) {
                setCategories(categories.filter((c) => c.id !== id))
            } else {
                alert("Error al eliminar la categoría")
            }
        } catch (error) {
            console.error("Error deleting category:", error)
            alert("Error al eliminar la categoría")
        }
    }

    if (loading) {
        return <div className="p-8 text-center">Cargando categorías...</div>
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.length === 0 ? (
                <div className="col-span-full text-center py-10 text-gray-500">
                    No hay categorías registradas.
                </div>
            ) : (
                categories.map((category) => (
                    <div
                        key={category.id}
                        className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow"
                    >
                        <div className="flex items-start justify-between mb-4">
                            <h3 className="text-lg font-semibold text-gray-900">{category.name}</h3>
                            <div className="flex gap-2">
                                <Link
                                    href={`/categories/${category.id}/edit`}
                                    className="p-2 hover:bg-gray-100 rounded transition-colors"
                                >
                                    <Edit size={16} className="text-gray-600" />
                                </Link>
                                <button
                                    onClick={() => handleDelete(category.id)}
                                    className="p-2 hover:bg-red-50 rounded transition-colors"
                                >
                                    <Trash2 size={16} className="text-red-600" />
                                </button>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <p className="text-sm text-gray-600">
                                <span className="font-medium">{category.product_count}</span> productos
                            </p>
                            <span
                                className={`inline-block px-3 py-1 rounded text-xs font-medium ${category.status === "active" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                                    }`}
                            >
                                {category.status === "active" ? "Activa" : "Inactiva"}
                            </span>
                        </div>
                    </div>
                ))
            )}
        </div>
    )
}
