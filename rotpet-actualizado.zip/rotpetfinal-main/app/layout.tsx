import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import "./globals.css"

const _geist = Geist({ subsets: ["latin"] })
const _geistMono = Geist_Mono({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Rot Pet - Panel Administrativo",
  description: "Panel de administración para Rot Pet Shop. Diseñado por Calupoh Media",
  generator: "v0.app",
  icons: {
    icon: [
      {
        url: "/logo-icon.png",
        media: "(prefers-color-scheme: light)",
      },
      {
        url: "/logo-icon.png",
        media: "(prefers-color-scheme: dark)",
      },
      {
        url: "/logo-icon.png",
        type: "image/svg+xml",
      },
    ],
    apple: "/logo-icon.png",
  },
}

import { Toaster } from "sonner"
import { SidebarProvider } from "@/contexts/SidebarContext"

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es">
      <body className={`font-sans antialiased`}>
        <SidebarProvider>
          {children}
        </SidebarProvider>
        <Toaster richColors position="top-right" />
      </body>
    </html>
  )
}
