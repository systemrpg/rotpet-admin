import Layout from "@/components/layout"

export default function StatesPage() {
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Ubicación - Estados</h1>
        <p className="text-gray-600 mt-1">Gestiona estados</p>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-8">
        <p className="text-sm text-gray-600">Página de estados (placeholder).</p>
      </div>
    </Layout>
  )
}
