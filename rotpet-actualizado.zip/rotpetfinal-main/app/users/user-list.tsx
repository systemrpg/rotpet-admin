"use client"

import { useState, useEffect } from "react"
import { Edit, Trash2, Plus, Search, Eye, Shield } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { toast } from "sonner"
import { ConfirmModal } from "@/components/confirm-modal"

interface User {
    id: string
    full_name: string
    email: string
    role_id: string
    status: string
    created_at: string
    roles?: {
        name: string
    }
}

export default function UserList() {
    const [users, setUsers] = useState<User[]>([])
    const [loading, setLoading] = useState(true)
    const [deleteId, setDeleteId] = useState<string | null>(null)
    const router = useRouter()

    const fetchUsers = async () => {
        try {
            const response = await fetch("http://localhost:3001/api/users")
            if (!response.ok) throw new Error("Failed to fetch users")
            const data = await response.json()
            setUsers(data)
        } catch (error) {
            console.error("Error fetching users:", error)
            toast.error("Error al cargar usuarios")
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchUsers()
    }, [])

    const handleDelete = async () => {
        if (!deleteId) return

        try {
            const response = await fetch(`http://localhost:3001/api/users/${deleteId}`, {
                method: "DELETE",
            })

            if (response.ok) {
                toast.success("Usuario eliminado correctamente")
                fetchUsers()
            } else {
                toast.error("Error al eliminar el usuario")
            }
        } catch (error) {
            console.error("Error deleting user:", error)
            toast.error("Error al eliminar el usuario")
        } finally {
            setDeleteId(null)
        }
    }

    if (loading) {
        return <div className="p-8 text-center text-gray-500">Cargando usuarios...</div>
    }

    return (
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="overflow-x-auto">
                <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Nombre</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Email</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Rol</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Estado</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Fecha de Registro</th>
                            <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">Acciones</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                        {users.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                                    No hay usuarios registrados
                                </td>
                            </tr>
                        ) : (
                            users.map((user) => (
                                <tr key={user.id} className="hover:bg-gray-50">
                                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{user.full_name || "Sin nombre"}</td>
                                    <td className="px-6 py-4 text-sm text-gray-600">{user.email}</td>
                                    <td className="px-6 py-4 text-sm">
                                        <div className="flex items-center gap-2">
                                            <Shield size={14} className="text-orange-600" />
                                            <span className="text-gray-900 capitalize">
                                                {user.roles?.name || "Sin rol"}
                                            </span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-sm">
                                        <span
                                            className={`inline-block px-3 py-1 rounded text-xs font-medium ${user.status === "active"
                                                ? "bg-green-100 text-green-700"
                                                : "bg-red-100 text-red-700"
                                                }`}
                                        >
                                            {user.status === "active" ? "Activo" : "Inactivo"}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 text-sm text-gray-600">
                                        {new Date(user.created_at).toLocaleDateString()}
                                    </td>
                                    <td className="px-6 py-4 text-sm">
                                        <div className="flex items-center gap-2">
                                            <Link
                                                href={`/users/${user.id}`}
                                                className="p-2 hover:bg-gray-100 rounded transition-colors"
                                                title="Ver Perfil"
                                            >
                                                <Eye size={16} className="text-blue-600" />
                                            </Link>
                                            <Link
                                                href={`/users/${user.id}/edit`}
                                                className="p-2 hover:bg-gray-100 rounded transition-colors"
                                            >
                                                <Edit size={16} className="text-gray-600" />
                                            </Link>
                                            <button
                                                onClick={() => setDeleteId(user.id)}
                                                className="p-2 hover:bg-red-50 rounded transition-colors"
                                            >
                                                <Trash2 size={16} className="text-red-600" />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            <ConfirmModal
                isOpen={!!deleteId}
                onClose={() => setDeleteId(null)}
                onConfirm={handleDelete}
                title="Eliminar Usuario"
                description="¿Estás seguro de que deseas eliminar este usuario? Esta acción no se puede deshacer."
                confirmText="Eliminar"
                variant="danger"
            />
        </div>
    )
}
