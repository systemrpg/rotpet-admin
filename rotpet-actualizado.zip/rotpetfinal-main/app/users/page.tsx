import Layout from "@/components/layout"
import { Plus } from "lucide-react"
import Link from "next/link"
import UserList from "./user-list"

export default function UsersPage() {
  return (
    <Layout>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Usuarios</h1>
          <p className="text-gray-600 mt-1">Gestiona los usuarios del sistema</p>
        </div>
        <Link href="/users/new" className="tf-button flex items-center gap-2">
          <Plus size={20} />
          Agregar Usuario
        </Link>
      </div>

      <UserList />
    </Layout>
  )
}
