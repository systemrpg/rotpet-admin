import Layout from "@/components/layout"
import UserForm from "../user-form"

export default function NewUserPage() {
  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Agregar Usuario</h1>
        <p className="text-gray-600 mt-1">Crea una nueva cuenta de usuario</p>
      </div>

      <UserForm />
    </Layout>
  )
}
