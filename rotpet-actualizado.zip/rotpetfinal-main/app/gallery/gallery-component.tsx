"use client"

import { useState, useEffect, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { Upload, X, Trash2, Image as ImageIcon, Loader2 } from "lucide-react"
import { toast } from "sonner"
import { ConfirmModal } from "@/components/confirm-modal"

interface GalleryImage {
    name: string
    url: string
    created_at: string
}

export default function GalleryComponent() {
    const [images, setImages] = useState<GalleryImage[]>([])
    const [loading, setLoading] = useState(true)
    const [uploading, setUploading] = useState(false)
    const [deleteImageName, setDeleteImageName] = useState<string | null>(null)

    const fetchImages = async () => {
        try {
            const response = await fetch("http://localhost:3001/api/gallery")
            if (!response.ok) throw new Error("Failed to fetch images")
            const data = await response.json()
            setImages(data)
        } catch (error) {
            console.error("Error fetching images:", error)
            toast.error("Error al cargar las imágenes")
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        fetchImages()
    }, [])

    const onDrop = useCallback(async (acceptedFiles: File[]) => {
        setUploading(true)
        let successCount = 0
        let errorCount = 0

        for (const file of acceptedFiles) {
            try {
                const formData = new FormData()
                formData.append("file", file)

                const response = await fetch("http://localhost:3001/api/gallery?folder=gallery", {
                    method: "POST",
                    body: formData,
                })

                if (!response.ok) throw new Error("Upload failed")
                successCount++
            } catch (error) {
                console.error("Error uploading file:", error)
                errorCount++
            }
        }

        if (successCount > 0) {
            toast.success(`${successCount} imagen(es) subida(s) correctamente`)
            fetchImages()
        }
        if (errorCount > 0) {
            toast.error(`Error al subir ${errorCount} imagen(es)`)
        }
        setUploading(false)
    }, [])

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: {
            "image/*": [".png", ".jpg", ".jpeg", ".gif", ".webp"],
        },
    })

    const handleDelete = async () => {
        if (!deleteImageName) return

        try {
            const response = await fetch(`http://localhost:3001/api/gallery/${deleteImageName}`, {
                method: "DELETE",
            })

            if (!response.ok) throw new Error("Delete failed")

            toast.success("Imagen eliminada correctamente")
            setImages((prev) => prev.filter((img) => img.name !== deleteImageName))
        } catch (error) {
            console.error("Error deleting image:", error)
            toast.error("Error al eliminar la imagen")
        } finally {
            setDeleteImageName(null)
        }
    }

    const copyToClipboard = (url: string) => {
        navigator.clipboard.writeText(url)
        toast.success("URL copiada al portapapeles")
    }

    return (
        <div className="space-y-6">
            {/* Upload Area */}
            <div
                {...getRootProps()}
                className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${isDragActive
                    ? "border-orange-500 bg-orange-50"
                    : "border-gray-300 hover:border-orange-400 hover:bg-gray-50"
                    }`}
            >
                <input {...getInputProps()} />
                <div className="flex flex-col items-center gap-3">
                    <div className="p-3 bg-orange-100 rounded-full text-orange-600">
                        {uploading ? <Loader2 className="animate-spin" size={24} /> : <Upload size={24} />}
                    </div>
                    <div>
                        <p className="text-lg font-medium text-gray-900">
                            {uploading ? "Subiendo..." : "Arrastra imágenes aquí o haz clic para seleccionar"}
                        </p>
                        <p className="text-sm text-gray-500 mt-1">
                            Soporta PNG, JPG, GIF, WEBP (Máx 5MB)
                        </p>
                    </div>
                </div>
            </div>

            {/* Gallery Grid */}
            {loading ? (
                <div className="text-center py-12">
                    <Loader2 className="animate-spin mx-auto text-orange-600 mb-2" size={32} />
                    <p className="text-gray-500">Cargando galería...</p>
                </div>
            ) : images.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg border border-gray-200">
                    <ImageIcon className="mx-auto text-gray-400 mb-2" size={48} />
                    <p className="text-gray-500">No hay imágenes en la galería</p>
                </div>
            ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {images.map((image) => (
                        <div key={image.name} className="group relative aspect-square bg-gray-100 rounded-lg overflow-hidden border border-gray-200">
                            <img
                                src={image.url}
                                alt={image.name}
                                className="w-full h-full object-cover transition-transform group-hover:scale-105"
                            />

                            {/* Overlay */}
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100 gap-2">
                                <button
                                    onClick={() => copyToClipboard(image.url)}
                                    className="p-2 bg-white text-gray-900 rounded-full hover:bg-gray-100 transition-transform hover:scale-110"
                                    title="Copiar URL"
                                >
                                    <ImageIcon size={18} />
                                </button>
                                <button
                                    onClick={() => setDeleteImageName(image.name)}
                                    className="p-2 bg-white text-red-600 rounded-full hover:bg-red-50 transition-transform hover:scale-110"
                                    title="Eliminar"
                                >
                                    <Trash2 size={18} />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            <ConfirmModal
                isOpen={!!deleteImageName}
                onClose={() => setDeleteImageName(null)}
                onConfirm={handleDelete}
                title="Eliminar Imagen"
                description="¿Estás seguro de que deseas eliminar esta imagen? Esta acción no se puede deshacer."
                confirmText="Eliminar"
                variant="danger"
            />
        </div>
    )
}
