import Layout from "@/components/layout"
import { Plus } from "lucide-react"
import Link from "next/link"
import BrandList from "./brand-list"

export default function BrandsPage() {
    return (
        <Layout>
            <div className="flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Marcas</h1>
                    <p className="text-gray-600 mt-1">Gestiona las marcas de productos</p>
                </div>
                <Link href="/brands/new" className="tf-button flex items-center gap-2">
                    <Plus size={20} />
                    Nueva Marca
                </Link>
            </div>

            <BrandList />
        </Layout>
    )
}
