import Layout from "@/components/layout"
import BrandForm from "../brand-form"

export default function NewBrandPage() {
    return (
        <Layout>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900">Nueva Marca</h1>
                <p className="text-gray-600 mt-1">Registra una nueva marca de productos</p>
            </div>
            <BrandForm />
        </Layout>
    )
}
