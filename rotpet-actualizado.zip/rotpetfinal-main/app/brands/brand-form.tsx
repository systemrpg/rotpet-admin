"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useForm } from "react-hook-form"
import { toast } from "sonner"
import { ArrowLeft, Save, Loader2 } from "lucide-react"
import Link from "next/link"

interface BrandFormProps {
    brandId?: string
}

interface BrandFormData {
    name: string
    slug: string
    logo_url: string
    description: string
}

export default function BrandForm({ brandId }: BrandFormProps) {
    const router = useRouter()
    const [loading, setLoading] = useState(false)
    const [initialLoading, setInitialLoading] = useState(!!brandId)
    const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<BrandFormData>()

    const nameValue = watch("name")

    // Auto-generate slug from name
    useEffect(() => {
        if (nameValue && !brandId) {
            const slug = nameValue
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, "-")
                .replace(/(^-|-$)+/g, "")
            setValue("slug", slug)
        }
    }, [nameValue, brandId, setValue])

    useEffect(() => {
        if (brandId) {
            const fetchBrand = async () => {
                try {
                    const response = await fetch(`http://localhost:3001/api/brands/${brandId}`)
                    if (!response.ok) throw new Error("Failed to fetch brand")
                    const data = await response.json()
                    setValue("name", data.name)
                    setValue("slug", data.slug)
                    setValue("logo_url", data.logo_url || "")
                    setValue("description", data.description || "")
                } catch (error) {
                    console.error("Error fetching brand:", error)
                    toast.error("Error al cargar la marca")
                } finally {
                    setInitialLoading(false)
                }
            }
            fetchBrand()
        }
    }, [brandId, setValue])

    const onSubmit = async (data: BrandFormData) => {
        setLoading(true)
        try {
            const url = brandId
                ? `http://localhost:3001/api/brands/${brandId}`
                : "http://localhost:3001/api/brands"

            const method = brandId ? "PUT" : "POST"

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })

            if (response.ok) {
                toast.success(brandId ? "Marca actualizada correctamente" : "Marca creada correctamente")
                router.push("/brands")
                router.refresh()
            } else {
                const errorData = await response.json()
                toast.error("Error al guardar la marca", {
                    description: errorData.error || "Error desconocido"
                })
            }
        } catch (error) {
            console.error("Error saving brand:", error)
            toast.error("Error al guardar la marca")
        } finally {
            setLoading(false)
        }
    }

    if (initialLoading) {
        return (
            <div className="flex justify-center items-center h-64">
                <Loader2 className="animate-spin text-orange-600" size={32} />
            </div>
        )
    }

    return (
        <div className="max-w-2xl mx-auto">
            <div className="mb-6">
                <Link
                    href="/brands"
                    className="inline-flex items-center text-gray-600 hover:text-gray-900 transition-colors mb-4"
                >
                    <ArrowLeft size={20} className="mr-2" />
                    Volver a Marcas
                </Link>
                <h1 className="text-2xl font-bold text-gray-900">
                    {brandId ? "Editar Marca" : "Nueva Marca"}
                </h1>
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
                <div className="grid grid-cols-1 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Nombre
                        </label>
                        <input
                            {...register("name", { required: "El nombre es obligatorio" })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            placeholder="Ej: Royal Canin"
                        />
                        {errors.name && (
                            <p className="mt-1 text-sm text-red-600">{errors.name.message}</p>
                        )}
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Slug (URL)
                        </label>
                        <input
                            {...register("slug", { required: "El slug es obligatorio" })}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500 bg-gray-50"
                        />
                        {errors.slug && (
                            <p className="mt-1 text-sm text-red-600">{errors.slug.message}</p>
                        )}
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            URL del Logo
                        </label>
                        <input
                            {...register("logo_url")}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            placeholder="https://ejemplo.com/logo.png"
                        />
                        <p className="mt-1 text-xs text-gray-500">
                            Puedes subir la imagen en la Galería y copiar la URL aquí.
                        </p>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Descripción
                        </label>
                        <textarea
                            {...register("description")}
                            rows={4}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500"
                            placeholder="Descripción de la marca..."
                        />
                    </div>
                </div>

                <div className="flex justify-end pt-4">
                    <button
                        type="submit"
                        disabled={loading}
                        className="inline-flex items-center px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50"
                    >
                        {loading ? (
                            <Loader2 className="animate-spin mr-2" size={20} />
                        ) : (
                            <Save className="mr-2" size={20} />
                        )}
                        {brandId ? "Actualizar" : "Guardar"}
                    </button>
                </div>
            </form>
        </div>
    )
}
